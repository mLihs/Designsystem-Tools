var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/exportStyles.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/exportStyles.js":
/*!*****************************!*\
  !*** ./src/exportStyles.js ***!
  \*****************************/
/*! exports provided: checkSwatches, exportLayerStyles, exportTextLayer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "checkSwatches", function() { return checkSwatches; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "exportLayerStyles", function() { return exportLayerStyles; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "exportTextLayer", function() { return exportTextLayer; });
/* harmony import */ var _global_functions_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./global-functions.js */ "./src/global-functions.js");
// documentation: https://developer.sketchapp.com/reference/api/
var FILETYPE = 'html';
var LINKINPUT = "sketch://plugin/com.atomatic.designsystem-tools/";
var LAYERSHOWFUNCTION = "element.show";
var htmlheader = '<!doctype html><html class="no-js" lang=""><head><meta charset="utf-8"><title></title><meta name="description" content=""><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="theme-color"><style>body{display: flex; justify-content:center; font-family: helvetica; font-size: 14px; color: #282D37;} h1 {font-size:40px; margin: 120px 0 17px 0; }h1::after{content: "";width: 56px; height: 6px;background: #ec0016; display: block; margin: 12px 0; border-radius: 3px; overflow: hidden;} .subline{ padding-bottom: 120px; font-size: 24px; font-weight: 100;} .smallText{font-size:10px} .block{display:block;} .table-wrapper{min-width:1088px; max-width: 1288px; margin:0 64px; } table{border-spacing:0; width: 100%;} th, td {padding: 10px 20px; text-align: left; border-bottom: 1px solid #D7DCE1; min-width:50px;} tr:hover{background: #E0EFFB} .ffamily {width: 110px;} .colorWidth{width:150px} .warning{background:#F75F00; color:#fff} .error{background:#EC0016; color:#fff}</style></head><body>';
var htmlEnd = '</body></html>';

function saveToFile(_ref) {
  var filenamePrefix = _ref.filenamePrefix,
      string = _ref.content;
  // Configuring save panel
  var savePanel = NSSavePanel.savePanel();
  savePanel.allowedFileTypes = [FILETYPE];
  savePanel.nameFieldStringValue = "".concat(filenamePrefix); // Launching alert

  var result = savePanel.runModal();

  if (result == NSFileHandlingPanelOKButton) {
    var path = savePanel.URL().path();
    var success = string.writeToFile_atomically_encoding_error(path, true, NSUTF8StringEncoding, null);
    var alert;

    if (success) {
      /* alert = createAlert({
         text: 'The ' + FILETYPE.toUpperCase() + '-file is successfully saved to:\n `' + path + '`',
         buttons: ['OK'],
       });*/
      //alert("Shared Color Palette JSON Exported!", "Styls Exprtet");
    } else {
      /* alert = createAlert({
         text: `The file could not be saved.`,
         buttons: ['OK'],
       });*/
    } //alert("Shared Color Palette JSON Exported!", "Styls Not Exprtet");
    //alert.runModal();

  }
}

function getSystemFonts() {
  var fontManager = NSFontManager.sharedFontManager();
  var fonts = [];
  var sys_fonts = fontManager.availableFonts(); //has to convert them to normal array, as {sys_fonts} is array-like object, and is persistent, so when modified, changes stay between runs of script

  for (var i = 0; i < sys_fonts.length; ++i) {
    fonts.push(sys_fonts[i]);
  }

  return fonts;
}

 //import sketch from 'sketch'

var sketch = __webpack_require__(/*! sketch/dom */ "sketch/dom");

var document = sketch.getSelectedDocument();

var sharedStyle = __webpack_require__(/*! sketch/dom */ "sketch/dom").SharedStyle;

var UI = __webpack_require__(/*! sketch/ui */ "sketch/ui");

var documentSwatches = document.swatches;

function createLink(cmd, uri) {
  // encodeURIComponent(URI)
  return LINKINPUT + cmd + "?msg=" + encodeURIComponent(uri);
}

function createNiceHTMLLink(niceName, link) {
  return '<a href="' + link + '">' + niceName + '</a>';
}

function createNiceHTMLName(name) {
  var lastName = name.split("/");
  lastName = lastName[lastName.length - 1];
  return "<td><span class='block'>" + lastName + "</span><span class='block smallText'>" + name + "</span></td>";
}

function niceColorHexAlpha(color) {
  return "<td>Hex: " + color.hex + " Alpha: " + color.a + "</td>";
}

var checkSwatches = function checkSwatches(context) {
  var docName = context.document.fileURL().lastPathComponent().split(".sketch")[0];
  var wrapperDivStart = "<div class='table-wrapper'>";
  var docHeader = "<h1>Document Color Variables</h1><p class='subline'>" + docName + "</p>";
  var tableStart = "<table>";
  var tableHeader = "<thead><tr><th>Name</th><th>Color</th></tr></thead>";
  var tableBodyStart = "<tbody>";
  var tableBodyEnd = "</tbody>";
  var tableEnd = "</table>";
  var wrapperDivEnd = "</div>";
  var tempOutputArray = new Array();
  var output = htmlheader + wrapperDivStart + docHeader + tableStart + tableHeader + tableBodyStart;
  getAllSwatches();
  output += tableBodyEnd + tableEnd + wrapperDivEnd + htmlEnd;

  function getAllSwatches() {
    documentSwatches.forEach(function (object) {
      var objName = object.name;
      var objColor = _global_functions_js__WEBPACK_IMPORTED_MODULE_0__["hexAtoRgba"](object.color);
      var tempData = "<tr>";
      tempData += createNiceHTMLName(objName);
      tempData += niceColorHexAlpha(objColor);
      tempData += "</tr>";
      tempOutputArray.push({
        "name": objName,
        "data": tempData
      });
    });

    function compare(a, b) {
      // Use toUpperCase() to ignore character casing
      var bandA = a.name.toUpperCase();
      var bandB = b.name.toUpperCase();
      var comparison = 0;

      if (bandA > bandB) {
        comparison = 1;
      } else if (bandA < bandB) {
        comparison = -1;
      }

      return comparison;
    }

    tempOutputArray.sort(compare);
    tempOutputArray.forEach(function (data) {
      output += data.data;
    });
  }

  saveToFile({
    filenamePrefix: docName + "ColorVariables.html",
    content: NSString.stringWithString(output)
  });
};
var exportLayerStyles = function exportLayerStyles(context) {
  var layerStyles = document.sharedLayerStyles;
  var textStyles = document.sharedTextStyles;
  var docName = context.document.fileURL().lastPathComponent().split(".sketch")[0];
  var wrapperDivStart = "<div class='table-wrapper'>";
  var docHeader = "<h1>Document Textstyles</h1><p class='subline'>" + docName + "</p>";
  var tableStart = "<table>";
  var tableHeader = "<thead><tr><th>Name</th><th>Used</th><th class='ffamily'>Family</th><th class='fWeight'>Weight</th><th>Size</th><th>Line</th><th class='colorWidth'>Color</th><th>Color Variable</th><th>Opacity</th></tr></thead>";
  var tableBodyStart = "<tbody>";
  var tableBodyEnd = "</tbody>";
  var tableEnd = "</table>";
  var wrapperDivEnd = "</div>";
  var outputCSV = htmlheader + wrapperDivStart + docHeader + tableStart + tableHeader + tableBodyStart;
  getAllTextStyles();
  outputCSV += tableBodyEnd + tableEnd + wrapperDivEnd + htmlEnd; //console.log(object.fills[0].sketchObject.color().swatchID())
  // console.log(document.sketchObject.documentData())

  function getAllTextStyles() {
    textStyles.forEach(function (object) {
      var objName = object.name;
      var objfamily = object.style.fontFamily;
      var objFontVariant = object.style.sketchObject.textStyle().fontPostscriptName().split("-")[1];
      var objLineheigt = object.style.lineHeight;
      var objFontSize = object.style.fontSize;
      var objFontColor = _global_functions_js__WEBPACK_IMPORTED_MODULE_0__["hexAtoRgba"](object.style.textColor);
      var objAlpha = Math.round(100 * object.style.opacity);
      var objFontColorAlpha = objFontColor.a;
      var objUsed = "<td class='warning'>No</td>";
      var objLastName = objName.split("/");
      objLastName = objLastName[objLastName.length - 1];
      objName = "<span class='block'>" + objLastName + "</span><span class='block smallText'>" + objName + "</span>";

      if (objfamily == "DB Screen Sans" || objfamily == "DB Screen Head") {
        objfamily = "<td>" + objfamily + "</td>";
      } else {
        objfamily = "<td class='error'>" + objfamily + "</td>";
      }

      var regexp = /DB Foundation/i;
      var matchesStandardStyle = objName.match(regexp);

      if (!matchesStandardStyle) {
        var textAdapter = object.getAllInstancesLayers()[0];

        if (textAdapter) {
          objUsed = "<td>Yes</td>";
        }
      } else {
        objUsed = "<td>DB STD</td>";
      }

      var colorVariable = "<td class='warning'>Not assigned</td>";
      var attributes = object.sketchObject.style().primitiveTextStyle().attributes();
      var swatchID = attributes.MSAttributedStringColorAttribute.swatchID();

      if (swatchID) {
        var referenceSwatch = documentSwatches.find(function (x) {
          return x.id == swatchID;
        });

        if (!referenceSwatch) {
          colorVariable = "<td class='error'>Broken</td>";
        } else {
          colorVariable = "<td class='smallText'>" + referenceSwatch.name + "</td>";
        }
      }

      if (objLineheigt == null) {
        objLineheigt = Math.abs(objFontSize) * 1.25;
      } //var link = createLink(LAYERSHOWFUNCTION, object.id)


      var tempArray = ["<tr><td>" + objName + "</td>", objUsed, objfamily, "<td>" + objFontVariant + "</td>", "<td>" + objFontSize + " dp</td>", "<td>" + objLineheigt + " dp</td>", niceColorHexAlpha(objFontColor), colorVariable, "<td>" + objAlpha + "</td></tr>"];
      outputCSV += tempArray.join(" ");
    });
  }

  saveToFile({
    filenamePrefix: docName + " TextStyle.html",
    content: NSString.stringWithString(outputCSV)
  });
};
var exportTextLayer = function exportTextLayer(context) {
  // Change font
  // This plugin changes the font family of the selected text layers (or all the text layers in the document, if there's no selection)
  var docName = context.document.fileURL().lastPathComponent().split(".sketch")[0];
  var wrapperDivStart = "<div class='table-wrapper'>";
  var docHeader = "<h1>Document Textlayer Styles</h1><p class='subline'>" + docName + "</p>";
  var tableStart = "<table>";
  var tableHeader = "<thead><tr><th>Name</th><th class='ffamily'>Family</th><th class='fWeight'>Weight</th><th>Size</th><th>Line</th><th>Color</th><th>Shared Style</th></tr></thead>";
  var tableBodyStart = "<tbody>";
  var tableBodyEnd = "</tbody>";
  var tableEnd = "</table>";
  var wrapperDivEnd = "</div>";
  var outputCSV = htmlheader + wrapperDivStart + docHeader + tableStart + tableHeader + tableBodyStart;
  document.pages.forEach(doSomething);
  outputCSV += tableBodyEnd + tableEnd + wrapperDivEnd + htmlEnd;
  console.log(docName);

  function doSomething(object) {
    if (object.type == "Page") {//console.log(object)
      // object.selected = true;
    }

    if (object.type == "Text") {
      var objfamily = object.style.fontFamily;
      var objFontVariant = object.sketchObject.font().fontName().split("-")[1];
      var objLineheigt = object.style.lineHeight;
      var objFontSize = object.style.fontSize;
      var objName = object.name;
      var objLastName = objName.split("/");
      objLastName = objLastName[objLastName.length - 1];
      var objArtboard = object.getParentArtboard();
      var objArtboardName = "No Artboard";

      if (objArtboard) {
        objArtboardName = objArtboard.name;
      }

      var objsharedStyleId = object.sharedStyleId;
      var objFontColor = object.style.textColor;

      if (objfamily == "DB Screen Sans" || objfamily == "DB Screen Head") {
        objfamily = "<td>" + objfamily + "</td>";
      } else {
        objfamily = "<td class='error'>" + objfamily + "</td>";
      }

      if (objsharedStyleId == null || objsharedStyleId == undefined) {
        objsharedStyleId = "<td class='warning'>none</td>";
      } else {
        var tempsharedStyle = document.getSharedTextStyleWithID(objsharedStyleId);

        if (!tempsharedStyle) {
          objsharedStyleId = "<td class='error'>broken</td>";
        } else {
          objsharedStyleId = "<td class='smallText'>" + document.getSharedTextStyleWithID(objsharedStyleId).name + "</td>";
        }
      }

      if (objLineheigt == null) {
        objLineheigt = Math.abs(objFontSize) * 1.25;
      }

      var link = createLink(LAYERSHOWFUNCTION, object.id);
      objName = "<td><span class='block'>" + createNiceHTMLLink(objLastName, link) + "</span><span class='block smallText'>" + objArtboardName + "</span></td>";
      var tempArray = [objName, objfamily, "<td>" + objFontVariant + "</td>", "<td>" + objFontSize + " dp</td>", "<td>" + objLineheigt + " dp</td>", "<td>" + objFontColor + "</td>", objsharedStyleId + "</tr>"];
      var weight = object;
      outputCSV += tempArray.join(" ");
    }

    if (object.layers && object.layers.length) {
      // iterate through the children
      object.layers.forEach(doSomething);
    }
  } // start the recursion

  /*function replaceTextStyles (){
    var style = document.sharedTextStyles
    style.forEach(function(styling, i){
      var styler = styling.style
      if (styler.styleType == "Text"){
        
      }
    })
  }*/


  saveToFile({
    filenamePrefix: docName + " Textlayer Style.html",
    content: NSString.stringWithString(outputCSV)
  });
};

/***/ }),

/***/ "./src/global-functions.js":
/*!*********************************!*\
  !*** ./src/global-functions.js ***!
  \*********************************/
/*! exports provided: hello, hexAtoRgba */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hello", function() { return hello; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hexAtoRgba", function() { return hexAtoRgba; });
function hello() {
  log("hello");
}
function hexAtoRgba(colorInput) {
  var result = colorInput.match(/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})/i);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16),
    a: Math.round(1 / 255 * parseInt(result[4], 16) * 100) / 100,
    hex: '#' + result[1] + result[2] + result[3]
  } : null;
}

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),

/***/ "sketch/ui":
/*!****************************!*\
  !*** external "sketch/ui" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/ui");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['exportTextLayer'] = __skpm_run.bind(this, 'exportTextLayer');
globalThis['onRun'] = __skpm_run.bind(this, 'default');
globalThis['exportLayerStyles'] = __skpm_run.bind(this, 'exportLayerStyles');
globalThis['checkSwatches'] = __skpm_run.bind(this, 'checkSwatches')

//# sourceMappingURL=exportStyles.js.map