var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/exportStyles.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/brandColors.js":
/*!****************************!*\
  !*** ./src/brandColors.js ***!
  \****************************/
/*! exports provided: colors */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "colors", function() { return colors; });
var colors = [{
  "name": "DB Red",
  "group": "Primary Brand Colors",
  "color": "#ec0016"
}, {
  "name": "DB White",
  "group": "Primary Brand Colors",
  "color": "#ffffff"
}, {
  "name": "DB Yellow 100",
  "group": "Brand Colors",
  "color": "#ffffdc"
}, {
  "name": "DB Yellow 200",
  "group": "Brand Colors",
  "color": "#ffffaf"
}, {
  "name": "DB Yellow 300",
  "group": "Brand Colors",
  "color": "#fff876"
}, {
  "name": "DB Yellow 400",
  "group": "Brand Colors",
  "color": "#fff000"
}, {
  "name": "DB Yellow 500",
  "group": "Brand Colors",
  "color": "#ffd800"
}, {
  "name": "DB Yellow 600",
  "group": "Brand Colors",
  "color": "#ffbb00"
}, {
  "name": "DB Yellow 700",
  "group": "Brand Colors",
  "color": "#ff9b00"
}, {
  "name": "DB Yellow 800",
  "group": "Brand Colors",
  "color": "#ff7a00"
}, {
  "name": "DB Orange 100",
  "group": "Brand Colors",
  "color": "#fff4d8"
}, {
  "name": "DB Orange 200",
  "group": "Brand Colors",
  "color": "#fce3b4"
}, {
  "name": "DB Orange 300",
  "group": "Brand Colors",
  "color": "#faca7f"
}, {
  "name": "DB Orange 400",
  "group": "Brand Colors",
  "color": "#f8ab37"
}, {
  "name": "DB Orange 500",
  "group": "Brand Colors",
  "color": "#f39200"
}, {
  "name": "DB Orange 600",
  "group": "Brand Colors",
  "color": "#d77b00"
}, {
  "name": "DB Orange 700",
  "group": "Brand Colors",
  "color": "#c05e00"
}, {
  "name": "DB Orange 800",
  "group": "Brand Colors",
  "color": "#a24800"
}, {
  "name": "DB Red 100",
  "group": "Brand Colors",
  "color": "#fee6e6"
}, {
  "name": "DB Red 200",
  "group": "Brand Colors",
  "color": "#fcc8c3"
}, {
  "name": "DB Red 300",
  "group": "Brand Colors",
  "color": "#fa9090"
}, {
  "name": "DB Red 400",
  "group": "Brand Colors",
  "color": "#f75056"
}, {
  "name": "DB Red 500",
  "group": "Brand Colors",
  "color": "#ec0016"
}, {
  "name": "DB Red 600 ",
  "group": "Brand Colors",
  "color": "#c50014"
}, {
  "name": "DB Red 700 ",
  "group": "Brand Colors",
  "color": "#9b000e"
}, {
  "name": "DB Red 800",
  "group": "Brand Colors",
  "color": "#740009"
}, {
  "name": "DB Burgundy 100",
  "group": "Brand Colors",
  "color": "#f4e8ed"
}, {
  "name": "DB Burgundy 200",
  "group": "Brand Colors",
  "color": "#edcbd6"
}, {
  "name": "DB Burgundy 300",
  "group": "Brand Colors",
  "color": "#da9aa8"
}, {
  "name": "DB Burgundy 400",
  "group": "Brand Colors",
  "color": "#c0687b"
}, {
  "name": "DB Burgundy 500",
  "group": "Brand Colors",
  "color": "#a9455d"
}, {
  "name": "DB Burgundy 600",
  "group": "Brand Colors",
  "color": "#8c2e46"
}, {
  "name": "DB Burgundy 700",
  "group": "Brand Colors",
  "color": "#641e32"
}, {
  "name": "DB Burgundy 800",
  "group": "Brand Colors",
  "color": "#4d0820"
}, {
  "name": "DB Pink 100",
  "group": "Brand Colors",
  "color": "#fdeef8"
}, {
  "name": "DB Pink 200",
  "group": "Brand Colors",
  "color": "#f9d2e5"
}, {
  "name": "DB Pink 300",
  "group": "Brand Colors",
  "color": "#f4aece"
}, {
  "name": "DB Pink 400",
  "group": "Brand Colors",
  "color": "#ee7bae"
}, {
  "name": "DB Pink 500",
  "group": "Brand Colors",
  "color": "#e93e8f"
}, {
  "name": "DB Pink 600",
  "group": "Brand Colors",
  "color": "#db0078"
}, {
  "name": "DB Pink 700",
  "group": "Brand Colors",
  "color": "#b80065"
}, {
  "name": "DB Pink 800",
  "group": "Brand Colors",
  "color": "#970052"
}, {
  "name": "DB Violett 100",
  "group": "Brand Colors",
  "color": "#f4eefa"
}, {
  "name": "DB Violett 200",
  "group": "Brand Colors",
  "color": "#e0cde4"
}, {
  "name": "DB Violett 300",
  "group": "Brand Colors",
  "color": "#c2a1c7"
}, {
  "name": "DB Violett 400",
  "group": "Brand Colors",
  "color": "#9a6ca6"
}, {
  "name": "DB Violett 500",
  "group": "Brand Colors",
  "color": "#814997"
}, {
  "name": "DB Violett 600",
  "group": "Brand Colors",
  "color": "#6e368c"
}, {
  "name": "DB Violett 700",
  "group": "Brand Colors",
  "color": "#581d70"
}, {
  "name": "DB Violett 800",
  "group": "Brand Colors",
  "color": "#421857"
}, {
  "name": "DB Blue 100",
  "group": "Brand Colors",
  "color": "#e0effb"
}, {
  "name": "DB Blue 200",
  "group": "Brand Colors",
  "color": "#b4d5f6"
}, {
  "name": "DB Blue 300",
  "group": "Brand Colors",
  "color": "#73aef4"
}, {
  "name": "DB Blue 400",
  "group": "Brand Colors",
  "color": "#347de0"
}, {
  "name": "DB Blue 500",
  "group": "Brand Colors",
  "color": "#1455c0"
}, {
  "name": "DB Blue 600",
  "group": "Brand Colors",
  "color": "#0c3992"
}, {
  "name": "DB Blue 700",
  "group": "Brand Colors",
  "color": "#0a1e6e"
}, {
  "name": "DB Blue 800",
  "group": "Brand Colors",
  "color": "#061350"
}, {
  "name": "DB Cyan 100",
  "group": "Brand Colors",
  "color": "#e5faff"
}, {
  "name": "DB Cyan 200",
  "group": "Brand Colors",
  "color": "#bbe6f8"
}, {
  "name": "DB Cyan 300",
  "group": "Brand Colors",
  "color": "#84cfef"
}, {
  "name": "DB Cyan 400",
  "group": "Brand Colors",
  "color": "#55b9e6"
}, {
  "name": "DB Cyan 500",
  "group": "Brand Colors",
  "color": "#309fd1"
}, {
  "name": "DB Cyan 600",
  "group": "Brand Colors",
  "color": "#0087b9"
}, {
  "name": "DB Cyan 700",
  "group": "Brand Colors",
  "color": "#006a96"
}, {
  "name": "DB Cyan 800",
  "group": "Brand Colors",
  "color": "#004b6d"
}, {
  "name": "DB Turquoise 100",
  "group": "Brand Colors",
  "color": "#e3f5f4"
}, {
  "name": "DB Turquoise 200",
  "group": "Brand Colors",
  "color": "#bee2e5"
}, {
  "name": "DB Turquoise 300",
  "group": "Brand Colors",
  "color": "#83caca"
}, {
  "name": "DB Turquoise 400",
  "group": "Brand Colors",
  "color": "#3cb5ae"
}, {
  "name": "DB Turquoise 500",
  "group": "Brand Colors",
  "color": "#00a099"
}, {
  "name": "DB Turquoise 600",
  "group": "Brand Colors",
  "color": "#008984"
}, {
  "name": "DB Turquoise 700",
  "group": "Brand Colors",
  "color": "#006e6b"
}, {
  "name": "DB Turquoise 800",
  "group": "Brand Colors",
  "color": "#005752"
}, {
  "name": "DB Green 100",
  "group": "Brand Colors",
  "color": "#e2f3e5"
}, {
  "name": "DB Green 200",
  "group": "Brand Colors",
  "color": "#bddbb9"
}, {
  "name": "DB Green 300",
  "group": "Brand Colors",
  "color": "#8cbc80"
}, {
  "name": "DB Green 400",
  "group": "Brand Colors",
  "color": "#66a558"
}, {
  "name": "DB Green 500",
  "group": "Brand Colors",
  "color": "#408335"
}, {
  "name": "DB Green 600",
  "group": "Brand Colors",
  "color": "#2a7230"
}, {
  "name": "DB Green 700",
  "group": "Brand Colors",
  "color": "#165c27"
}, {
  "name": "DB Green 800",
  "group": "Brand Colors",
  "color": "#154a26"
}, {
  "name": "DB Light Green 100",
  "group": "Brand Colors",
  "color": "#ebf7dd"
}, {
  "name": "DB Light Green 200",
  "group": "Brand Colors",
  "color": "#c9eb9e"
}, {
  "name": "DB Light Green 300",
  "group": "Brand Colors",
  "color": "#9fd45f"
}, {
  "name": "DB Light Green 400",
  "group": "Brand Colors",
  "color": "#78be14"
}, {
  "name": "DB Light Green 500",
  "group": "Brand Colors",
  "color": "#63a615"
}, {
  "name": "DB Light Green 600",
  "group": "Brand Colors",
  "color": "#508b1b"
}, {
  "name": "DB Light Green 700",
  "group": "Brand Colors",
  "color": "#44741a"
}, {
  "name": "DB Light Green 800",
  "group": "Brand Colors",
  "color": "#375f15"
}, {
  "name": "DB Cool Gray 100",
  "group": "Brand Colors",
  "color": "#f0f3f5"
}, {
  "name": "DB Cool Gray 200",
  "group": "Brand Colors",
  "color": "#d7dce1"
}, {
  "name": "DB Cool Gray 300",
  "group": "Brand Colors",
  "color": "#afb4bb"
}, {
  "name": "DB Cool Gray 400",
  "group": "Brand Colors",
  "color": "#878c96"
}, {
  "name": "DB Cool Gray 500",
  "group": "Brand Colors",
  "color": "#646973"
}, {
  "name": "DB Cool Gray 600",
  "group": "Brand Colors",
  "color": "#3c414b"
}, {
  "name": "DB Cool Gray 700",
  "group": "Brand Colors",
  "color": "#282d37"
}, {
  "name": "DB Cool Gray 800",
  "group": "Brand Colors",
  "color": "#131821"
}, {
  "name": "ICE",
  "group": "Transportation",
  "color": "#282d37"
}, {
  "name": "IC - EC",
  "group": "Transportation",
  "color": "#646973"
}, {
  "name": "RE - RB",
  "group": "Transportation",
  "color": "#afb4bb"
}, {
  "name": "S-Bahn",
  "group": "Transportation",
  "color": "#2a7230"
}, {
  "name": "U-Bahn",
  "group": "Transportation",
  "color": "#1455c0"
}, {
  "name": "Tram",
  "group": "Transportation",
  "color": "#a9455d"
}, {
  "name": "Fernbus",
  "group": "Transportation",
  "color": "#e93e8f"
}, {
  "name": "Bus",
  "group": "Transportation",
  "color": "#814997"
}, {
  "name": "Schiff",
  "group": "Transportation",
  "color": "#309fd1"
}, {
  "name": "Schnellboot",
  "group": "Transportation",
  "color": "#0087b9"
}, {
  "name": "Flugzeug",
  "group": "Transportation",
  "color": "#00a099"
}, {
  "name": "Taxi",
  "group": "Transportation",
  "color": "#ffd800"
}, {
  "name": "Carsharing",
  "group": "Transportation",
  "color": "#f39200"
}, {
  "name": "Auto",
  "group": "Transportation",
  "color": "#878c96"
}, {
  "name": "E-Auto",
  "group": "Transportation",
  "color": "#408335"
}, {
  "name": "Food Walk",
  "group": "Transportation",
  "color": "#d7dce1"
}, {
  "name": "Fahrrad",
  "group": "Transportation",
  "color": "#63a615"
}, {
  "name": "Bikesharing",
  "group": "Transportation",
  "color": "#c50014"
}, {
  "name": "Fahrrad-Anhänger",
  "group": "Transportation",
  "color": "#878c96"
}, {
  "name": "Roller",
  "group": "Transportation",
  "color": "#878c96"
}, {
  "name": "Electric Scooter",
  "group": "Transportation",
  "color": "#878c96"
}, {
  "name": "Essen & Trinken",
  "group": "Point of Interest",
  "color": "#f39200"
}, {
  "name": "Einkaufen",
  "group": "Point of Interest",
  "color": "#814997"
}, {
  "name": "Gesundheit",
  "group": "Point of Interest",
  "color": "#a9455d"
}, {
  "name": "Kunst & Kultur",
  "group": "Point of Interest",
  "color": "#e93e8f"
}, {
  "name": "Wissenswertes",
  "group": "Point of Interest",
  "color": "#858379"
}, {
  "name": "Freizeit",
  "group": "Point of Interest",
  "color": "#408335"
}, {
  "name": "Zivile & reli. Einrichtungen",
  "group": "Point of Interest",
  "color": "#00a099"
}, {
  "name": "Dienstleistungen",
  "group": "Point of Interest",
  "color": "#309fd1"
}, {
  "name": "DB Services & Einrichtung",
  "group": "Point of Interest",
  "color": "#0c3992"
}, {
  "name": "Wegeleitung",
  "group": "Point of Interest",
  "color": "#3c414b"
}, {
  "name": "Accessibiliy Blue",
  "group": "Functional Colors",
  "color": "#b2e1f5"
}, {
  "name": "DB Success",
  "group": "Functional Colors",
  "color": "#508b1b"
}, {
  "name": "DB Success Small Fontsize",
  "group": "Functional Colors",
  "color": "#467a18"
}, {
  "name": "DB Error",
  "group": "Functional Colors",
  "color": "#ec0016"
}, {
  "name": "DB Error Small Fontsize",
  "group": "Functional Colors",
  "color": "#db0014"
}, {
  "name": "DB Warning",
  "group": "Functional Colors",
  "color": "#f75f00"
}, {
  "name": "DB Warning Small Fontsize",
  "group": "Functional Colors",
  "color": "#cc4e00"
}];


/***/ }),

/***/ "./src/exportStyles.js":
/*!*****************************!*\
  !*** ./src/exportStyles.js ***!
  \*****************************/
/*! exports provided: checkSwatches, checkSymbolPatern, exportSketchLayer, exportLayerStyles, exportTextLayer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "checkSwatches", function() { return checkSwatches; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "checkSymbolPatern", function() { return checkSymbolPatern; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "exportSketchLayer", function() { return exportSketchLayer; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "exportLayerStyles", function() { return exportLayerStyles; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "exportTextLayer", function() { return exportTextLayer; });
/* harmony import */ var _global_functions_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./global-functions.js */ "./src/global-functions.js");
// documentation: https://developer.sketchapp.com/reference/api/
//openssl base64 -in /Users/martinlihs/Downloads/DB-Type\ 060721\ 2/DB\ Type\ Print_Screen/Screen/DB\ Screen-WEB/DB\ Screen\ Sans-WEB/DBScreenSans-Bold.woff2  -out /Users/martinlihs/Downloads/DB-Type\ 060721\ 2/base.css
//openssl base64 -in /Users/martinlihs/Downloads/DB-Type\ 060721\ 2/DB\ Type\ Print_Screen/Screen/DB\ Screen-WEB/DB\ Screen\ Head-WEB/DBScreenHead-Light.woff2  -out /Users/martinlihs/Downloads/DB-Type\ 060721\ 2/base.css
//openssl base64 -in /Users/martinlihs/Downloads/DB\ Logo\ file.svg  -out /Users/martinlihs/Downloads/DB-Type\ 060721\ 2/base.css
var FILETYPE = 'html';
var LINKINPUT = "sketch://plugin/com.atomatic.designsystem-tools/";
var LAYERSHOWFUNCTION = "element.show";

var htmlheader = "\n<!doctype html>\n  <html class=\"no-js\" lang=\"\">\n    <head>\n      <meta charset=\"utf-8\">\n      <title>DB Design System Helper</title>\n      <meta name=\"description\" content=\"\">\n      <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n      <meta name=\"theme-color\">\n      <style>\n\n        @font-face {\n            font-family: DBScreenHeadBlack;\n            font-style: normal;\n            font-weight: 900;\n            src: url(data:application/x-font-woff2;charset=utf-8;base64,d09GMgABAAAAAF3IABAAAAAAz5AAAF1mAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGhwcqyYGYACJfgiDXgmMIREQCoKWKIHlJQuHDAABNgIkA44UBCAFjUIHlXEMhk0bYbI1sjnOzMptAyio6Fnz53wmUtg4cMYEFo8MBBsHbMAX3Oz/PyE5GUOYHTbVsuokEpzOoPooOVDNNal3n5zIQGmITNN0wimaWroEQ1QDvXanQpG9hMxbSElDZKnuEvLpVEKuVuF1IJsz6Ul86GSqSIpX2I9wpN+ZwcJ7Jf5F23GKFv7XHH1QUp43ncEX9I6Xb2yZxX+2aarpCRbZOmprRW6XmqXoUWQShnA2i7XDLbV+h52BbSN/kpPXf57f5rnv//c/IhYGrMoqlsYiKkx00QjLcNnKUt3amQkDsE0xZwBiIYqBoCAGqKhoU4KCpAkmYmJVzJpRs7apKxfac6EL5yK/fV998fci/zenJYiTjqRvF2aZb3siuBHIlhN3mqRJ0ctDdv4lfXtrFk5ARyDqIEv2IPDw//v9/+aSvc/9hngikT0ktyomifcjMjqVkEmEwk94pFkyjZz9o92bT5dIJb9LSoxStql7O2yAkrtfkQLZ3ZtaZJopQhUUJWqdEBL00C/u7T8ESjGXgkMwXZQURRMkIWdz/0815QLYwk6t/0jputJbWsOCk3hGSA+ha+slYxvGDGPGbFum8Qbn5TzhYgP8tIZGjgqUwqnO7LnsNZO2oZqzRUoXux9pAn+fy/K//78+StxSS60GNRho1R72kDrgohD0yQGyb1vjss/h89J9IOGumQV7DWEveDEOsSfhoXUlV3KFyG2/IWKpxm5rBg/HtrUjhG4xQxaVFxVw3+/KHlSbrhak929xKER5da/Qh+xaely0KdgAxsYmNYLbyqcEIJxGQf5QZ54egFyQenUKfgY3lh5RLsoJb5kKPKvbcv6Sf+s04tphLg//3af2t3uGBiOUDMEzDNC60NIClaTqBS7lDBVsE69jRfv3plql/dHdUoPS7BIjrdGs5WyxSlpnU4LaPeNseNH5/9/77f5Hk40GIAJNYgSC1BxAcfYggJoiqalZGEoFUeIUpfOOe96CFOWoceSM11lvImOzC2162QXhBekFmbEuyLKLLPHPXz/dsbtAax7YyYro87dde5y1oFGkEYURBRyAZuU0aez1pjV53jjwCZOZ4DEsK1W+VMAaQA9Q2DlVYZ6gfyyzioLU9g5NzWUMVcbHa397jKn/ORxkdixeaqkiIl4QEdGMP2d8c35s1R/mRs/bc7ctxiaEFoxfAeV0FOroMDkrCJ3Gu08yBgKoeqxYeCtbfiwO6EtO/LOU2fAAS/6G29pLT+/Is9pzP9Nl26u9Mme8OfIAWK0AYKcqPCqeUFI5KrUZNEsFPXB5CZkrvZ/Yq8YaDV+YBLmqtBsyJ/t9xkF1NjwJhEuUp1qHYUcMfRaBIwO26HxFSJKvRqcRRzlTvvYxD4XMOy+h0oW8gsZX8B7a3u5eg17vd68DYJ/7DLC2acnysrMKRKiP+URODGEQMPgRS1agVpdRx6S1AU7NiBk7rrz4i5SiUJ1uY+ZpncQZApY9N94CSKQqUu+gcQtGamQujJlzwBQoSppiDXpMWCQ1Cq6QiNyxBImWrkSjXpOOb+tsuEGx4MiDD6EYGUo16XPYiahOScOEJSckbCKxMpVp1m/KyegRW1qmrDjjCBYnS7kWA6adWjxTrZA+RqUKNBwXFFwh4mWr0OqQGac5xZXHuXZVwbMgYaJIpcpWqFytZp1l3xMmTarDJs1ZtGTFlituuOORZ69ff5QQufrH8CkjWUBQCObsuPMiEDL7qAFGHKXKVqxas26D5eQLpkjQUSectWbbrpvu+cVzb/w1+eGFl0ONvmUsSwmYFr0V4nK3GA0s2XLkjoaJJ0CISHGn5JfpgjNBvlLVGrXrMWjcjHmnyvMvW2HwhkuuueWBp1565x+fhh+ZyJcqM18qEgIBpQ/JDI4dZyR0PgTroB8XZBImilSqbIXK1WrWqc9wOfm6MntkzqIlK7ZcccMdjzzz2h+T/73+epct+ZJrAIqANMAYMmHOmgPXkvJ6keU1Lxx+RCLESJQuV7FK9WXrG6ZIat0GjJpy1Alnrdm266Z70/8LH0IIUK2Jx+B/JYggioz9FRCDHu84TSLJpJJOZm/9HUAMCYhMmVKljm+a+LaJ75r4volfm/ihiV+a+LGJnrQOEP+cZIzGh58Q1eYtWfPYa2ap/sqpBIAO5AgGwYw1RyReAoSJkSxbqVqtyQAo+oIeEYtK8aNHXZ+jNgCTFOlhSXWi0zk5GZnZWZ8xeS4f5qfMUWL3i88qJriVebmXoGIqv5orvi7V0/pWeS2JVdv6R8wOgZnqW/VrepKWdwmvrXfXl247hfSHullP0t/rb/XX+kv9uf5UPrb+miLPmpDUEy3ISL5E76wflL8VJ5ksytVzGdmTDHpvv6/BZHf1laIM5ahAJSywAkTkwkxWgaEAhSBZac0mZ4AoHTeH5hLIh3qpaBHrvq9KWRvzMj/NMtfy4cyTnufmQ7uXx8yk3DwTLc/5s1v/HD0nrc/us93sDJkiIek+6YJTPd27mi+5ZbbWW8fTp38TeNK45SfBtbop7szqE9ffhjND7+HtZ/zg2CpqB8TWjoXxB2MzR1T8TnVo/NJYx1EaPzHWcHjF943VHlrxXWMq7hvXdIdYMgLjVbGfbY6vrr6OV8RutDEe3Sc69ZmLGbG9fSHeHFvZr/veLwni454qBplGpVj/Xtx87mJJPEWACiHGqkIJFzW5RyUxQxV1+1zpXtWFFclFwGCLirVqepChhMNfmTD5ndd1ig5/lJG3jwYSz1RwcdQhyVDgVFzoQzLzV4JDRv3Nehb8ibn/hFi8f11Thyq6grx+jqBKpvzZW6nX7Q3DoPEMv/4ZvuczeNXXWv50++2QzYcpL3VJYp25+0mjeku/QmTVc/JYTujhh2iUrNlYxqfVnEXnnLdsxZp1m7Z2yYQ+uRxBAcAj5sjUvhFlltuHiONXxxYP+ua5Lus5JsT+ZWm4CKHEIkng+2r9MwtMDuRInQZNWrRB6UQ/Bks2/TMLRpceOH0GDBlBMF58JCWbEhyTI5E4SSSTgmxISbakovGiRIsVJ94PO6LIhwHsFaK2F434Voi/sQQEBTnZMMsnVhOdyURSKhSJOWAUIZAtQGeRW8qhhUijOXPBW7SYfuesZBCyZHW4e7N6j4ZZ7DyZaOhmiyGSA1WxKMxE3XyJkyO9TsweViY1fcsPqyBnBlYe1oZcGFp7WImcwJ1/WFtyg7D5sEpyZWR9V4HsSWtOCqEWFeajDh1bOcFAQuLLzAA3xn2k1M91+B6dVLVUbRUqq2rK6pQs9shR171rGwuh/IT4VHJPRoldwhiwVEPVSEWo9dvdFZ+/Z5GGCER2uQeFpRIjSQIqGqE1Mc9kQk+1HBuvX743TpUpAL9msxtwiO7CPoefaOUTSsbZ6zSiPtk/zhArYHHOfvsbaE3tbyl8/j+Cu/5hcARgDwAg3rfdC/hxoMe+P3ZdnCQak+/0Pz3sVkqRGp6TLHmK02LKgg0id17YomUq1u6afa/AVpDVEpPEPJ+P8kl+LeeCF7qKq6bu9IdLa975BhJxAnEh3IA7wOAhdMEITMAcREAq5EEd3OxodTxkZeREno08j11mN9gd9ozNMi8WwaLZhQaGB6+Vay3LunioLVCI+Y79CbcwD6uwC6cgh0/wQhrZ0R4v4l38joLUJtoe8vC5mkutvif8Yc+Bq3ALYPPwc8+EUnJu3+t6lI7cJ0Kmt4596xuilnhlNeMP8fz9yfJsuQbAss5SvC/8r1ReV+ZXsO9D0l4CkNYDd+dJE9MeSNNJLf78llr+eYI+t21PNaVOTQ1IKU1ZkJIC71sJQsrQFF4KJQWX4gh8O/r54+cbABumhN0AA1DdME+NtE7bdE5SMjMoRVmZB4Edi/J5BgG+KSRZjH9/1+epNOYFkGYRYPPebqZu/5crjHxCELYREdFRoY4vR05sJMBwh0ZgBitdijRWapNjz4ErXSgmzFmy48CRG3dUbFw8fkRCxYqTIFFqruy4yUNzqHxVqjVq1avPsFFzjllwymnnbXvsiRfeS/Y/Z61c5AhiKUykcBJtGvRr7D8cuTw0mdAiix64QWXq4U3S7X9cJlBM4VIikqjIbNlRQ9BjwJANKzh4UBQMNJ5Y6CXFFClMBLEkHPtWKFCkQrFylep0a9Oh07Rxkw5rcs6am1ZsuV1ym74w++Szvx5JZ2MlBUupWAWihqZ6Whqoq6WjGUwLYwfBGemC1ENfO4xDTPXDGmJmkIURtmZMIJhlbYy9o4jmOVnk4gRnx7k6ycMSsrNIzvC2oaN1XV3QyxV97OptRz/XDLRngBv6u26oO4a4baxfjHDfeL8Z47Fxnpkk2e9mSPPOHH+Y7b25nnA3QOimBZ5a6NdGDRhz2LghAQIJ0TFQkZBRePLB5oWJxVu7DtZKJHJQKlNGf8orv5xyA8C/qQoxRsEDAax/ft3v7kbpTjVw4II82xLmpc48AGXldwPQh+rrUiBVWk/Ix9kPDPW8CwHoclrUHwo+FUDjN86TiN39xYY+6qyrAYnTZrOIQ4E85PFwGloCOXKRzoBETePuR+Ncv2zvHHU51/I0iyZGxW6hlzzCgeq2jd0ldwuM7qnNhhxvGZ24zYrEMdHWm9ToPE3WHPuHEbJOPdZRGqVnx1s3zHnfjpY7tabPTk+Ojw4P9vd2d7a3NjfWlQzSD/y11ZXlpcWF+bnZmbHRkeG7Kfc23ro50NPZ0Q6ifr32ORJdqx2uG07uhmpSuLk5wicxor5RzhDnedrL6VWa23n4ivj9jdf8zX4Fg/BlcE0Or1F15osbzRN6yNerss0JR5kJareUmEqIXVIIM6XsQElyRzIIRevPS1YZqUxnC7RpFhXkm5YdsKCa3WY8dH4UKzG7u8riQtVdtfgJQQkOOY2qXRXl6DDUKOkIEeZTQMV5yDwO5usDXrZ33dCQxb4/NjcuQSDSeC1RqFz0WFN19IfOVlD1tmZe3SMvlJJ9/beDgsrT8ObBijyUQzvHjX+jsHnkdiC3hRIwqH8ZOT1SMD3DK3SP9xFmm6ICzPPAAK4FQthR/pSQIHIzTiv5eqUgVnAuQRrzQqoywk13urTPNpXadUODYpgyyjxUPi8N0MpIXg6TmAListosTkLKZLIlNiXKW5TSZ2U/Tb68ZvzIzVEVj49Zk5G5iPg+cI6qtWNYoR5Mx/BOcP8Pl090dbPOwdQTEERkY+oCJW2a5Moa2TrAcZDWvAKCNTW1485nHdhBKCtWuAWaqlPh7uhcgW4aJ0fcFLh2BLUMiUVC1PkwQD52sPNTgbtEqAFuNVO0YnA6K7sNh8UqeLUwUGyX5OufLKaXPdtqEgSTPmnLvRkc6F+9n1LYN2DAbVFwg81iIdSjy7gjQnE31/Z4TqLUblaQmj6cm5hbu0iNypdiucrL1jU26NUCR5qLjaLKD2bCzKJhKAc2i5UKDay8tOwGPIDOAHQAj2vMY4ilNWx5qN0CP2Noa3dOcOfooQ60OUHaTzlLNjAvtvZZYgHnaN3jeqpu2LG6WQdkC6GaWwXunFhUDxMHytU7EfA1+cht065pWmJ01LoZnMhtpIOv2yj5r2Vjkm8rypQWMbL1tnIydqKXnbZNHOt3zuu4Ug0sxvJLz3cnZkCJkdVuxz6r3X2oY0Bs7KvjKjYjnPbFgRLunOdCxXP9UvU2LFkTjupyWoG+aTpMMw91wvzAa5hCVlIZ96gX5W9EXUWRRVsiOwUpfrJBWSVDoKA0ktpaBAB0JgDCBwHokwA1JgB8HgD5uyD+GzS3u2fKFufwp3aSdjqV7BmjRlVB7xt4W72NSy1RS9LMtOSpeW/jtX5uahDAoi0VAFo7+jxyDPPzsS1h/Qlcy0SwNI+sszrfLTWjrZ1uvgPBAHs0nVHIUuMZK3fLjpySFO45URkHW6X5vn/Sma1lMTttvLPM2BrzC2jzCdTi5hcsynOyDDHweVDMqdTazuYumXdzcrK1TwWjf/w6CNWmgzbfm8f18MSZM63hlUAEaopF4lBrF9xYKmvctPWfX65+RiMfFvqkH/JNPrearlQTrKnDT2w+NTeFFoXkQluNFlORjjpXQwyPhm1uc6P0/P07NU/I5ML5qh+jLmvQMt//kCeTOH/ItgjuImuqJI7vMi2Me5ZdwCR2l3QDY8/UskkcPmUYEg7MPUMbIYJ8gpRammlZlgYGiy1mlU3gs1YaL3l6dg5ASUmRmEoICrC+u/B20iYvhavW9qAnxI96bo2AsgRRVaG8ToK+mwrcTK8PuCeKNmZNVXhy1IkOufO/IgT7k7kz88Oo4yopPlUM7HIAyboTIpfchlpK5vcxcMtWNu7eZdKJUWTrgVt+r4kIuWqoWGEMObGCa4uCIrw2ooBipVhCLLJWoTEY5e9LY8wngdxl1puFwMfgbfXDtXP3OyK9ODnP5EChkMUyUcyadxY7MWdOclIos7RecjoqOGhpSimSQ2YhVkkRvR2qKEcItIc1sPlpWge2V5UDWJ0iqipE73uCS69w6zwz5EecYj1+VrIX49HWD40Mv6aDuIvtTc6n1lbcVBh2oARLlmCgq8eN84DgQeWklUnRFUYEQH06VMCDXHko3ziIg5ySCEi4YJlCefGtW6+mQfi38cDlbl4qVBvvg7XN5VJY1WjEw6WhhJvartRhLRZgjmP2S5mjWK7NCqxuoqu9i8GBdCp0BBzUVmlvUVCi5dRidmFJnxYUDnJQEybFYUrtLhkZu0M6M9Yy0c20EGlofjapomDxKA0cKXjlQToF6hCLeXVJaSGoMKiex7EH7EnBuafIY5sq5BwLqsTrAiIpA8XxtLSyghTDCesj8vKDbz1tivO1u83bGz/2IwSaQURRmZxT9ytE4YlgOHAXJ8lfNvFAa6ZwAXIMx7YLplJDRHohBeS9A0MhWjx7AUzGmBpSy5o1qPYrEGAzdKNokxzl0Lugf0B8VRZX0CIqDiMdkKke4Phndp5MQD2B8fr3ypVdhfMwtS3N5gpTHqsor6eAWfQTHMmCiIdK0XWnNF+Ql5TmCkV5JTKmqc3euET4qs/coZpyXntfI8EgDj7FPN+V7JLeohxZLQRit4Q0b60no7b6FzfwnpuCQj0TnnCosDSyUrIbBwmi5q2IExYRVic4YMc85LoBaG6JYFdkKV68M4XPKmMhJu7etYZhluUqsk9YoTo628mhMi9pxiMkgEu2Rc1tZdhV0iHaHSKnzx+6kdodQBePTxbxlZvRiJM6zODGY5UgVRRoSSWRRAzVVsBTkd/swUUwSXwnbiMlDsphhv8ZQCWFjEsaEie45n1CFoU4M8zm3uQZoeCSZKOyZL85nyRNiKqa+YJfKyz1m2pn/6s8rdMHimdsxQdiLGanCDP97iVwRJmt27LHZf0iM5fYIh5wl0kJJdOcQ06BnRyZyltwQCHLZMOoRUKC3FvK8/jzPNM67+jg42um60DjLlnMO8SbDrMMXmMAqCnx/sSDa8XQbf01H/s1qjPQnVMN/Wk04cZzU5lhuqq8UQiCnHMlxNFjSSOikuTb2OdxIOnNYf3nOjaDL/yTirunb/rO9aFZ8F79SSO1M7PRmf+US2kb6/5LQd49PWYpdcbSXfU8cDLR6mUks2rzgpxCbJBIW0LHEU9SgIDXeYoqydzT6mTSr3H8pg3k8xwNvXtnuoAKjoDhquMXWj2odRy4gKpiNOzLnhudkW9laRb8bDev9Q3px13EYNz3QVVbsLMsr+R67zdsr+7DhBqJ625nB8UjIu7IlNrws25KoUu9Ig0FNxKBAekosH6Cm+2Ps12IFRVKFXGn0g9My3HqdYZSDsR6Lbg+qVjS34uWm4Y7u6IpB9Da3bFKSV2Zo1uRFJ4C2TBNFR8hrZr6R8aC8lmIAm8NEuvXlLioSFupe0fFAZVDefxU3/D19ymIIrAHLlgPHsnVss01+U6I4Eu226JpG9IZzYdp0aoJ13i7KfAKVBGHiAP2QHkwo86k++KmSWrxH8hmBEkhDiHhWgnJJJKizo9VeJm/CqyQRNzlGB1k0+kZsT8mhWCFU3yBn0MW9AV3bSTDJWuad2BoZJieoaUGNDvHiaAde1MaruXFAT7E/L2ujpGeSIfyxn5RMMV9ipAB7zCJI7Gvr9BN81v2Xt+Sk50BygmhV+xFEdB0mYnGIO77QKKIYK5mZf8HgleQT4vnavEuZXLPCeKRABNFW2JB2tDJCd7ty8R2pNG58ZCF1tmgFxg6rTeOK5YsEDff5pcsr2IIBqM9h8iMHmMlCS+FWituTGYzybFblGs9rEvMcgCGI6SQj5Kh7eR1vAxOsQqvdWM07qZhgp2EnTaQNcaNL/MmZuNnMtLXUUOpHuU8pJPlhihZqEk8ysZr8u7NOy3Rsot4+1r/6v0fGbgRomtAiQ1cj3IjbVJQQjyC1yzUlKGbiDLLBCYeZxl6RZPidKB8INhnUtyyfSmHLxOfSq5pR1YCn95SGiqlgOKkkMm9Wj5MSXff6k+yAehRsxQi6dDZsAVf0RS6khoiiSDNQCu9RVpx+qRuQCQyg8uwaQ0cDv7zJfrE5kAr5dDZ8cv5GMuzKlUmWLkLZLLyAGe5j3+Ercf0XuRDHMhnhG8oecAVZtWfsQxENRkCBIGBpeGZxES7LoiRow/2WXti9iFVm0k/j+/5C87gogbgFwjNP0WyKs2TkkZFIEPT26cMAz8t1lg8vmHCcxov+mMj9lDn2re7jQDOWYI+LdtEwVT2RbJHG4Ro8nGeHM16Gj37PsludfbemUHBQpEqvHldsoOnr0iVIXTSqnre5teTKxgtNO9i4UFw1Iw9w24nox5kWBC0740Q5sAVucK1RNVQiwwlrsw4oM/CyffqToZTCvmgAfg+B8SoDBROfqDZ/bEQ62iDk+nilGg0TxeBdZXoqDNpwgbEJmy1dWoEl4mMTzEm9LZYJD4PdKENmOht/d8AMlzdLzglf5CrDSmsu4szYL0HMCGC0+4Gb0Gr8gWL5HDq5HKiZCtLZkwVGrb+R0w2ugepkvkyqT5fhijNkG9fLwou32RKDyNCZjlBT0zQ4c7JfAyYyjH3OaDimJsnMqz24L34IhkuQHKrGmQJ9QQKRpNP8dMuS4AiMuT1Ibb9caHYqHW9a7C4rho0CX4+3spYJQ2ot4/GnDJOwLiUCB5xsX86JqgsdyTA+cgRRXy74zm30eKj/hnmjn9qSgLDkn24HyYO2cz9nmLWfNe8qwXL0PCMjjaEdEyE1oqmUDtyTwHcOsm2J2CauroOjLOCxHYS9EEh0sLsFG7t46GHAmucQzNdUhw0jLWNU4cEl+YIOLtRrQuZGhstB7ljOViDVDUJMMUCg5wAT9rE8lsyU1xR1Gx77vg7lnKAmTlWTFOfk1DmSO0NDYJFcRnLfULL6FTLqQMyJWZQ/o7WF5FvT7EawPFg865J8m6GeJjLmdtWCut0lCwH3gMpSsNXRE93o5lpMzUTdg0XCgvNGyKxsi4Tkq8nNYoHJtSSKQ3M15ERem3GX36Jr31RtfgnrJnAb25laZ/pm7TTJjKDsIqS4abJGTHY3cFGbjruHEuSqEk+x8wBDfAdcaSiuMJYpTD3RcAdLjz6sTUuX2KvnL7j9sLJEteO09ht59bbVp6pN7WJxcFVnX6cYis0X4h2XsNfG0h+jcHJ6kdo1n2OhsuNeBu4ZROS+fySuYcRO/U5P+jd0EUIeQ97Wc5GeTrPx5g/N0sUX+QeTp0xUxOCQx0D1mbb+q2jotBkcvVo3GF6l4cth+uL+ZPUtPC2452uUxeRu6fyxbLjgCjwny/GR75xxmcSkrWvSUfit08vE9hkrXhRVE6bZ72VcT2hGOR40Ch6lYFd5cmPkUB1P4GaV1UKlr0OGyNW/UqATplT4apwRm/yl5m3IoRg+IpZ/zE7WPJpEF3vWpnrgU7hFd9TA7F96MtzNx5H50EiIqbpCmNMTezxioqIwNkKKr8wwJR3MOdhRKN2DKyDByJz827VsE0RHkFoIuSTYd2JiES/bI0vzQi21lFf5lEioCCWi9YG7G9XR5v5cBE4zAfLspyIB1t4YcRHyDZTYBF9aC4okQM/LDE7BnYC5zr53iOrP0bMn88AEUzwthaJDI1cKPK1tulRqATu6z1xIEoZK8rLBbbGaZVIumzLPP/EzRWVX21MbVxEwZYXewnEx6lwIq0F4M7hvLhneCVCXTWNBFktkj0RVQ0ZGpRaW0pSCLkZxJHCpotyUe6dR1z0gNxujNt4FGBjgtBpW36EX5RLyEY48rpix8UiGJk5msDItAmoN5Lh5YNhErESZ8cQkVbrQQFRGFP7i0hD1hy7JtG7amSY3nHhyFb81bwt0AkLx0Hj14K7P3imjmDn8wObGtfmCT/Yy5Mn88EC1H8prS1hlc5XZvY6nidHiVftD9AbvBN8nZg0MYmX+WhEa+9xURN7m2Hy/wTLB1vIrfcesdMJW5t/468pcXYKhIjj2CajcEEEJVGaMjFVndmCs+WFIHGZ5fi7oFH5AsuAKVTYrZBvsu3a+5fV/EnOQQ4E1ySTcynmT0MBfC8NVFmU3FKND9OIs5nzEw7wuRY1xOZTDUHnEiL8woMCWbEX1bQXOuoam8nMC0vei7S5k027coqccJZoamTNzXqC+zA9WQfjUfxYcgT+1LU77P3b2GH6bY63shSsyfxbjO9kbB0guNSNBfSYxrBaE5xPWNVdKNJKI5p/aD0er6gyJQ7pPU87iknCPgpHtR+LAHwv6u6zsbdnzrQZ+nUJB4/Tkh2Df6f4gAYaatsh8sFBHcQOSrT0qrNtvwXqx1/jiw27EbSwmUHFN0T0bcAd8c7XE8D3PFgtn+Qd5EEmlTKcc/FHdYsVgRdizOvzLU7eM01H9H2RtnD9+abPRHhWiR3UQcfXf5G153P9SXDMBmaqdcnID1eUb0aHxhqUpS89fWmX/g8wCnpyBPuDlH0lfAzVqZdvUDl6N8v9ktSEzzlQATSxDQxCGpsn/EFg5SAkqmuP4M0PJpUDr4awOKlVnulRuxA3N3ZMHIcTG6sO8DJMyGdou9XzGsqlexFn+UEo0psAzcgRs3yZJumIa7KSSCQB8MLfp5R8yiv35vzNgtj29Jpde/DxoQW5eZQc4pOudxrbwOdDwUdSpRoiD7DBTXfev/8cIPKsbZQB88OSmmFFpIwkMlR2Yu8R+TPz84vbZXKpj5/qGVKDg8WnopT573/sMzxcx9b/v8IEOMyr6nPw7I9IoNBMa3d0uQtZfVGRHU3/NCs6efni4ygcoS8WLrz3qxorlhLSeqjsrlygIhM0VHsQYhz8ACpODFI+E3HyyqXHkvfHYqU1X64qhCQK5I5HnLrS95Hw9Gh4/sBb6asUBr2C8CBRL+z+o3IO40mUt3POYNOt96WGDUfCh6APJLWoyZHovnSuOle9TMjZ3du8yGpMwQHjg32xVtQCfH0sPPjBQxQvisxvxJ+VwkV3fysCh2sW1uabD81HSdmNGu5egZY3mGIyaXjymaHMP3SlKunXQFzcsoPQ18gZnHNYs1Jh/vf9q6zcjDB/4cng5K+hUlBVPAXonxAsjEe5qGVM6ga1lqu/URBD6nRmgu3YJsZpS4Zl4iYpfca5+WE4MMhMe3dkuQtZdUmxc8NDLnS24Ol3gQ6PpUvThnu6e4of+AuHYPyaLce1I+0R5Q1UWJKRbRpqTslCAd5kz+P8KXauNuHsgbhAdmiwgJ4A+937pmT9z3IS3dR3mBhrUuC5Ep+y/Lghv73MgM1SSQHnY1nbvEHLzAJIMNrj5cQF2oADyztRuvO6fEUvBknxEETvjfe+ZE1fMSGOUdpq5JFh6NOdDC7YtsEbPchwTD0St5n8jLLL12C6vMHQHAR13a63VRGyftX6zOesqer5arU0u4GTvTUNToKO/NSCymPZ/U8E5b3/9M22fvTKh6TZ95f8b+TksFM9cSEzxqfwELen3ibWvwdoSZycAiCRcey4sIAlxTTshOtBBZhNOktLszoa+WKPi4ze24Z6lgPXVHkohb1jUMK9fNZPoj/MItyC8yw+LwmqeS8adWFPiLzzHfO93VBOaenSW5W1v9c6ZnYNK+T/0rOuaIWRSgxRU9h5A8TmiZsgPp+lw9w0Mc+ILNNhNqHNfSO0/7YaTFu93z872+/5ynLcwCIAeFPRms8khbLaoUMm2OceG54UxQfQwGxW9MbZGv3NUrkvcLqbppGyT6SvV01ZcZ7qjXgTqBn5estZOVh/tnJ0rviaXXCZx4JEs1+IJw5k37NqH7zooXeDeXHprZATJQiiY5LdGvsCeaoWuSKrWKMNM0uJ2jUZWwHLI4JZqz1hin3pscUgKdVrKneQL1bKgXZsCYZoFc9Izt5ZlEK2k9Db4icFFShsswLwrSeKXqQwv77FDTEH8yjpaCxYpH/q4bVJt8JS/axUfM0bpkOAYbenumPjgIM7aGFQ27Ya6cYnQVuYJ3MS4ZuE0EFm2aNgkAB5rS+uI+of33SNfIRdioUERiM+oEMci5qpQmVRPDfVM1lH874+wbVuhDdlHpKQ16CBbmvt6jCv/F9Wp1uG63jWhOYeTYEnW/pke6boRCChGc7aLDQQUAVa2dbymTcTXcq6qMiU9pSOm7jJXO3YwGu/KDJIGpl/fvDH+UTzGo8xCjV7OoKQprf23dnzuzYh0T7uNX+ctGXOT2Lqj2bQHgJaDbRdjgssHXBLtqjU6z9W1a2g09hUUnYD66Ara8k3VA9nNR3vuYYOjIpgtpwhmgG3tUx/f5Ju449MwUlTMNvjH1bdFt1Cn8uTKRETFYsVJzHWDlXl6l9MiEuUzludytVWrLBZTkVcJKs7NHbBJ6+Bl6ydeFreE0Y/Gdx+6IKH3i5zV9QynFdrGAIWmD09n1LFXVeYuY+Rz3YRerMZYSbUdZpemLE3+IU9N/S7Qel8TH3IffSl6gxPDz60u9xmgUI9apG26HCsp7P0Q7i/Ns/vnngG/w+c3oEejHy2s5DJpodZqRBoFaoV6rsJKUlp9y7DHMyFPm4M7CPVR7QazYQuLEpHDOab99rViYqiQFzLS5h1ZGixXaJzimmHfmKWX23s8ZMFMUWx7+tSMPwbxtYzCi5XWiVF/jcSvGv5RHykWSa1+6OzlVYYuKQs4MD+jF5AggGN7W97hEGyZUYgLJQljm9rpuWnUNL0zj7+XCHCptiQG6tUs1BU5B2Eh7+rwT5XoJLDNncsuBk2FZh5hoTqYREe4xrhIUhN0XxbNqCikppc/q75maKPHK0RvwfEcjmA/mrMy8GPcrEvUmmMH761k360USgHOfTYr4x1DXNPchnW1XAKHeyMBkuZ4u1t2ui7OkT2CFDnTqUXme85o9Wm6oHr8zFr7g7pyluafjIoiNf9R3QKGilSWeHCAQnlRFb4P5J8YNgLqVHq+sfKtd6L24TBMWaAgWB5d81q9qaTgVLdYmEMi2UuV7NQFM3yMceqnenm4Z3bDj9C4NEL1R6+ufqY5znxIp0z+HWj52bDXT1NijoYG2Pj+ZP0YJMC0OJ9LKaib/ocxi/e7HGMWWWXu6F82D8l2qrBZ59VHwQKwTz09ZHkJvHd2DAoGfKvMHH/6K2Cnp8YzYs4WUGLK3mjb5+3HGRp0G1V3gJWSm61SGznWHFfJPCGHnJXPYOWeFUivpan4KF4+kDOZ5+OgUseeteZl0a3vCkB/w9ksI8KfbXP4aMGhA2PsFN9nbX/VZziWZwzuTJpVdszfhUTEId+H2feMth9DuN3bxejkOMU5M2hh1m/OVQD4Bc7/JF+pmfxwr3IeV6zTLpGNOb+kFjoUOjonAwNDZh5w3QIFFux0KTTji6KQt8AnjalGlkvLUdeLj/gexe3uGTdL5JN+FTWtl0YBPe1rjyP2vJu/lsCDDS8ViWN4R8kNdEhUiqZbt1kCuDvq89+4Fn5GmRRIc4NLc7WimJBkC8UeQc5QF8c7rVuXgWF3gQ1mKiRTDW2vQ4HeiOw6JuOdfpHTA9ODXjcc//S6FoVr1JgDDvp3uzrZYBSdarNaDJoMuC5SDnni548w5UqE7l1/Z49KmU4jSzsQYMIDMFf2UXNezKyUv+oaffhBr4S3bKSVHKMdU67NS5+SzpHfmt13vBtzW41dtKW0XbFf7+c6YXlVXCYlPRwofVXqMH3aGqwW4xLQMWsNDwp8lFXgIFcoJ5faaBpi6dlMiMGR/Y3n9yxpHsGjV9G2jGcPY7+r034Fasbie58vHLsyq91qhoCoYsGxbjQ4NtX269H+dOPvPUoW9pODpN+cUfC4m1npfppJxrfVyP7BO9a2SyW5ZtlTKjvTCyrkLZPrk7/cT6k3/22zZIj0ydZK8uKAHFb9zHmvQnUFLtgT9XP8T5l+hkqd6ksuAnXGH6L26dOeEbf8tTVNuF29rucd/1/0bXbxUFri4vUIoVshUik9r6wk9P2Q/YSulqG+wmI939cjP17wa+f4b7/9tyxumsF9FhXUrr84jfxSaXOVy/CDS6e3z6yXRUyIzq3dRJTsDh1ubkjgMcae+yZ1Kfh5FwI5DjXSl32SN2gtq8GqUitAn3mGIemUeqIFWBcJtddDnhfq6+zQeFM/oWzR9E3Ndl88yHTWOKEVPQUP1XxAPDrNR+7cDHfhtf2PRRkTBZVFxpr0qoBkzN9lThFknZhqAVKUx/wV4SY7WbBDXQLc0cvnNUSRjprayxxQ8p7ih+DSAB+reZjFf5g99hA/OIzzGXvpze6LGTwdBXFn0gvqKSSsrYttmQtaM8E6ScIssccpn6KE3lBx7N56p7FBct9OTI/K+n2l9EkI6PbO34MzQ6znn83IZ3FmVGrezk5xSVyyp0lGZKVt7oH+LrxNR1qUDJF7wBPV1rpqC0fZsVU/7n0rwXbH1b9Yy7XiMBk1jCSlfaUkhk1TA2PisvY1tlj173s/CXky2atc8eueaeE695zfMq0t97HT4f3SxHbDSg9/HREX1x8RD/EDfDrV/6Lf8O/F6Fn3wDyzD7+/xPzNSknNj3odAySrdu0IGi3yiM5J7tt2FT684HFbn2BELpR5fbXeyeeG501N9GvMEtDRUYJYAHa/t26I+NZmuCnqEamP8wfyuxquyWxKra/ZVXqw1DmWRrTiMkZITk29eqeFiQzpzyxwTMllL+68rhyr/KXP7CaDw5hJMcp/B5K5zhUdWKPbWCvbvSNoy16nCiNjV4RQfleqs2SFPgt2H0lvLZuJSYTGRnKMqpDBH1EpwkVIqB6xr52TSV71x88uyM33TJUre0xdY4nMk5H5a2UaGVg3271H6k1IqRovVUhnNdYxzEs6JYeZSrEdlVPvYEqK3WGyVG0TYGXPTMYSv/vFaLy1VVTv4odGNtWQ3wm05XjJxkN1KPjSzuYXaxfPrRx58VXXFUts5YEVS7ulIjYuU+XckfE8mpToo2460Ut/SkmJJSDr8fSR8KDDHghh21WNYcfXXQOoUpCKRh3punHBP1I021UEtGI8GyoueTGq5QWQcKyUMPLduWwuDvgYXo8/LFT/FnhgMYZ1g9fydxuEKPL0EqZkATpCKFbkMpUHG2uQB3LzCTxw51hBH77eYwzoh8mVvsxtU7YXSa9+2bUOt1x5PNnoelvUmcV8DOULpbJEBcng58jd/qwKF0Q+tqLF89f2Lmr5Jgce6q6o2W4+bv2l/DE2Ez2ZDzSRyuzB3eaA5rjOK0l/vnxVj59RRDLCts9e9mQJcGBdCvNck3iY/jFM3rPbsVoaFxHVnH8PXiOIeiseLU5L4urET/+yBNlC6dIMG2aNDzeMg1ypNV7CXKjrMo33d+IyZfPlS+Rr36BfK6VZEz986dpsXNErhbEc5JkYK9k9IMFFTEpIH1Xsu3r2mqOgO4KwuvCy7BSpDCE4+O2X99SZ6jr8QFkj4Smhlva1ChmpOZNeJT8R4sSafDRYxWRVVHbkOZlqtDjx6lKjTSzt/OHcqQeUWpjNY4n7JqprjbRhYVbLU5kKCNqERUNPYYZPzWv6ysDcdy3SiE6kAWSuac9Ga1Jn0syDTvNOOHewnoqEVd2niJ2+sVTfPBuR1J9zG+RwZoWZERUWP0etC7GQkANOaPBQyuHwlP972rLRdQZMojIQph/iiuF7GpadYttr9MRZrMIXLam2ZJwzjXKRUkF027uhUiPDI+04yoj1bXpT0QC6A4x7DJrWLZLK994s6n12HGBU4iazn6D8op9K93dWlKKZ6hER2prHNS2fjFJmpj8l9Q1qYzDF3dw/UMkM8Mn5weK21fnnHYfksIzxsdTOr3dzTVfbMD/Y/Byt8BytC6NjAaPjotnnNdhqceDIGcqRn1Wskj2Mb4u5By/XsvdCvyIq8MLo6spZIZjstefWslr9yBLDtYEsVF3ueRglZavsbEq4xsjtId4odF6eLg7PFbCtSFrEhmkoRpSAPaFmeqNkqWBWAW1sG/DQy8MllkTrBL10ddI2GU2KOCwpfq1+jAa016e8E7x4lG5u04Witr/l4tjIWrsFU87iVngIeMLDsv60XHWfNNUJ+Z/No5S6/pqH+9n1MtKV0ZUmknovVBThq0FzwHHsAAtjIIf0ZNynDtJA9r3elVz+zas/RmkUFItyNcLHKMVHhXgbMM4J3BLec8e749JsoX/JethphYiYpnj9UBeNPCCD8bOhIVz0s2kge0NyWjoOSOKXfT7Lx4ycPZ0QKGz6F9bGz6IhN0GMTINryldmlcao1rcDMF42WrrDHO08cNeaDXZf78v8zsnFmxJ7UhuJqeDLczd1S07kjfdG7CUU4CXdipG2MtZZIfkzKY0YorRbjV+0IX+AkEr9dBNa/fVTtPP3KpB7nTjaupoT7WWAGGs4vXOy/A3unIa9kKz9aC9aTwoKtQPM/yVRNYiMkg+Q0jKCf4Y1B8Iu74TiHGIiv3J5KvwtIVV9xmD6bowz9WI1vOGxEBsP2/w6Hhy+X5k9I2wElFNP55BS46rWd3WTPZiOmOTrQLva5vdIDFRAte0d4kh594VHGwAvV/4/KUPBl9R+OY7sl0MBj2KvDEsE0+wF0H0eDcXF2PUT421EtYAa0bHos72p3iTcnz7Jvg3bHiNT6c5Z7ipGgcuZP/p/s8IybtqONZ7swgcIVmobjCZVPCcLNnp103HF5sWBupVDqK73benTptrlOdmAA/5uuROToZMef5zBZ8JnxIjmwpcRA85mozdCJEyKPiIKVIMNaD2F2Vr8A2lKYub/mI3kt1Io8vm0d9+X4PVDliAaJVPEIYUGbjU93s0LTAnW01L8it9QyhU3Gz82aAuOsbBmCnH7lHrqMdIteTmuEW4m817t2RJluHrLRCT/NJTHdMUCP9sKaD+UdfqUpBOevgG9gemJUHAuWcKevLtefnEgBxAuTkkiHxyk7h+rpZkN8pRaVzpBMc6w3rOJC1KpNVmfHCzvyvt8NEkITGm76YVN9b9QM9UGBVCH63rb2fnJpZ17CFhXfQy22RZz6C6Dka+KbG7IMiWyVktTUJh5x7LfCNY6kXFpX68BeVmK6El/1Nr/VDig2EuSGSYvwMTF0zt8UdFHIws8vULDlEy3vwryMQy2GT/bvNHNZKae8uHmw+yrKXI5Htzmj9A3NVJLR+VIZWImycNfnMKeT/IY6tcr8HFvQK/b/yfLvEA2V64BJxjcQaWRMfaErMYUlQCFF7s/Y+hZFlT/dr8tbKFr3009jT5uCC0+TAHhkUTgi5Pw5Uy1QD7Bk4Ac/phx3kkI+oba1lJ1gEr81dXhCa60hylH7/G0gN+pn1KwdmllvEt5cM5RS+SHJRxgpqSpJjdhTzsh0RV9VxQQFDKyIPi2LpUD5yyQ2KgOK+1PK4Z+DM7nE3fnV3X6gmhSW8n19lpJCUgKBd0OmCAMGXhYXFMfar7Yr3D5fEtQLtUqvISQM5aUnYFcImG5R3sJnZG2e00bsoaKF8PUzlT5ZdH96QSwA/Byv6S1x36F4CahcHF3T4s7B6NI7yT1kvjPBDd7+I/7NcVh1ixYb7ROZWpo1dvnTcq7cIrCnxYAz5Lgz7VSup+d9YPHFIr2ZcVO85QZD9rfa/ePwsDPu9dp7WS2n/L64qDqPp+k/Xc4TgU9UuKJv/urT/fm2XZn9Lxn4m3X7NA+vrHk+UX3RzLjgYqH6VUpVJJSdJu7u47yBOrAfDbOU7FI3sm+q0JoqLpkLadB12PL5jfzfWkKOYAYxAeYy69VhMCoH/kgZDI7bicuO0oUFZRTHndWSc023TfPO7/6ai9QhQxazvNjPICxrzsRIZ579lC5NAjoQdqbKDtzFOoyAPrYqX1ZMt4Y6ZHABOdgEkctp1t669EuvsfcJ/SkXtyUXdeUemgbQT4kA1TSWBoBSkqaW4tr+BXjk8ITXSleYeykFMiPx2KBsMGztHUWlbBq5gQanmrU7DUk9tU+xNOSciZRVWUjL3+JCmDL03JkYTFXUtKTM7TIHlOspIIOTp88zUSm5QfdyvayB8RdKgiHVGIOgto8eqi5/cUrWgr715mm7qAOO7Esmc7IJgmgiy2BsP1NYISpzMF8Gq7aHNMoK59fJL8aQoWZ7ZVf5b0UazMt3fUifyBnnOpAc7q7jqd2+i1yDIMDuACI2CL68AXSqgHLZocFadiTCm4tHc/s6C938beL0852syuHJdrZuoJ5MTz84RgIUZev1k+03VbNaLt5sWVyyuZEW2K2y6ZLtsuHvMertsIRpdP/Y9SfE+eKgsuHXNJ/7s3XbJ2mVudfYQmF5uPDHUItkd74QIr/sM/ZAPa8jUmPE07yNytw6tax9ftsJsPuSTxUjCc5zS2Tss1bwSXmQ+v2Z5hgLU0G6hywaq+Hi6Wt1rnyJ9CFdn2zpZ3VYGa0LyVErXQ/0wLYoMHG3CEf9NUwlBu9U4VOQn+EGnYSmRG5EqYql8nkdOXdYiIbvNZPqIY7xP1HpsHKSxayTONVK8ATurfdTy2dAR12wb5MhaqXg9bvwH898DmfLXGPa8iYFH3b81FLcUHTje72JRZFuKIJLCbRBjJA/JAHw1d/nItMG79P8N2RSageGtzcXsxPrAYcIuQQVghOE442q4YniA3sLOU6Av2TXRIFIAFiernpwJtpGbFXqEP19/d0X85hisV6vydHbgTAPdoqIVHgEuoq8A+z9+Cm4av5CcnKRC45svVrMv49nV++fOREsAPwZrUsc+yk7LO4p7xGw6+E0HvqpdVCL9ygu1SeEmWynWCU8ZwskRyiLnGwrtgARBmnWO+dUX7bKgFQN8yIScWb6dT/wZnglUQVJSHchSKi+9n7vgZ+IJ9CfaE8S4aCOjgh2DY+3+zT/rFTIniqZF6wTBHoreup0XWKUGxVoKlg+I3IYyIgjr5Hc0+VWGHlCyB95h8UOETOkRPBSeQIvREug5YYBq/fw7d/jGHC5afOt/RFqKpctqd3pcdFL6LYNfPb1INIIFgkuEQ/YcqOjPntoF1fA4xLsdazX79Cy/4lG/ONXGqf+QYDWxcmuQRYNuUe0IgCOYHnxTkitg6sYjMpaox/0hx6lVucx1Kx1oA8aL621rYknxc9HJPFZnon02RqxVCBHSKn42VbuGvQhf1I8xGtzfZH0V3+uSjbqbvtQv15MXP9en1pNMD7cc4FODrjM9sdYy+1yNU4r7gw3vT6EH2h2ogn/Y0f189ZVOJyvT5tFN7vghenqP/p2PH1sHLWkEQrtlqVcnvmnuQV6mO8Q+O/Skq9c+bZJyKQhNziTnnmMoUw6cnAk5qQy/s/TDy3AsHwPVvDHgfqkaFglk8IKmAL33ATvOCeTI9c8Jfa8hm+dH5w4D26wHScJuQt6T9gwXhVfcYfujpvmeToZvf+hSe7TIBgjyHVdYA+P6vlW7lMC/a3WGyeEhdoxpYfXewcCuyH9FpUN0fARYituvTBst/h/3e2J3Wa2kqLr5qRv+kedRR8smV3WJUWtq3ggmURHi3nLM3U+WPHNjEHy5uP+k2Xo/0MtYaq+aiU4Ilp88nREvC/pz2EiKpeBySKvxg4PCl37+6uv2wifUyb2j9PEqjo5bDa33YVKkCU033vst1Z9x8v2+eaeQSoHrl6qvQNmRcrIqQZSvdFU84EoX51CAUzUobHKtNHn3ruS1vRMe3d0b1qh+mZSdlYegYpKWc80N2Ff8TFRz+03bGG8C/cFBx/VVZ2jaYVtBcbu1rNws1JQZp+XKp0mfM/UQDdesxoshB7JIw/KShbmQIjFxfv7LDxkcYGRUtfki3byiFqdn1LbcvQot/fF9Veowy7HqqpgAhT69fyRl7ihrpyElaepJubAHHGmOmb3ZqN+uBLCetQaNKhpR59lrCf5Rr9Ac6krbqTteMg81D2THlKS8uFvNbQw+TA/VZpem5jnvvD3MtJVbRvifLjWi2Pwg4HY1/zhO4iEQ7nXwNQ6xZ0A8Tb/KV+/riTOJZqgXHJT88MguPZZvStfcB0owrgB+7fGURAy6pzSh4yoPQ0GP9omrOVaDTQmxs5Djlu5fe2PYMw3CZ225Z7Q+mQosnaCh/vW6cr/FyLn8oMboy1SwhaioQzsQVlLoWOJ90jREp55sajbvUozXjgJ4g11ovk1DdZ+4s+wzewdT4hluJeaYiLQ+NkMQiZKzBO1ukdvK/cK92yg7bsuXarRs7bDWqYUUqS8oYtjhJOVB5O8CIF0ryz0fhFWgMV7aPKuHm7UO8PWnincAjl+qxxezfl+tXGjRuTPJ2Jam/BM7dXAuci1iZjV1I+C93pMB5PSR0i9xw7EvH8RMP7OxOPOg4LivbsXjyAVxbSz8S15gdqMEePqSojg9LMOWfVlfNd0EYGSjIo+CAPMZlESZ2KLo6KDhc0kS/L0LHjsRVBgnFkgYy8TndiFPsF0f19uYkOfznacgt4SVTGSyOoUxWqHJGS2YJq5f1kKvwpUx15bTPdd/ry6v9skEP+HDdiR02SU9sljojpQgxUombHyGeTX73ETCb1BgRERfbfRo1G4hJ8fQTkpHnAjFJdF+RukEADyAPesoySoZZe2EpYdB/M/gOg23HDN/WvMXr+2jE1MRYstVHdmOs2FaOJGvpiFt+E1OP0XP99ZpMbOfiDH+7EaI/HUg6oGRut7dBNwigK8l+gB2Z0idPvXxNj+A7CuvGhUrqd/C/AvwWOxp9cPul346gGFhdAN1Ak3AHtvFd1p+uiXoJq6LDfel/YUcBXRuh4Fma8eGhJ/E8+UGTWK3zSveffssyICrVoC+gIB4PGPRFoZzBlSROdJ+Z00Iojjg88dITZHGxJ2DMcv9A+58MmG8uP5JMYnql1+goVLHxDlY4tI01Whu8tZs+4BKYx+ITg/TYOnh4tC46lJPG+xwDwlVWRlOXdMkgh1B908o2T+d/P9nNLq8RXbK044WggC7CT7IpY7To24nloJab83TZT9j26aaJd+/kZrXP1AFxs05dVKMST7wMbtr5IIUiNwMCim2o86cZKCEUz5Smf3hAc8QlH4CIA7APb4BKTRlqPy8Bgbc90g+5BOSx+GjiBxFbB4dB7aUPJI/1Yr22ndg6Vmg/DdeIFy8OvvjprpxjcuQpcEdt2hmrO+wMCbFxaHqD83oo6lVDJQ3Op/39/FEKJNxtWKcZ+NGUEEoQ4nUvPUE2x/wEzLs8IND+p5euIJcX21qVXKOjWOVjTdov1DZo8P7a71MM9AX1Q3CienG/ebUAdITrtJb49tPtpTkd2d+3jeQkOJBeOSbHJC6GXzzleVBPo06HCS3GpHrwHIWY6HjwEW+L6xHfXucGFghnSTAtmjQ8ztJPVYwsD/bpAl0vq/RN9TOm/yqfK18sX/ECuaWVaKz55zfTor31+6pqT7pHFRA3W/gwIVksOWPzqq6CncAyUcYraHZYS1FBp0qjGsOAm00NFBp9nOPNZ1pu9onjm5qs5LYNsodqp4sSCTUH8lLyJjxS/qVFyXW31Fe+Auw84i3yVFgt00jB/H1qOCfWRaJ2vPa4PUZxse5wosWRBHW1WzTOOimmSvJbxxpE/e7vZ/wo0MbNRTj+Qhf33OtMqot+9rI8tCT4vPND07QubgrRgcKXzO7Yf2b+9PWgtCFilUbEldWo+1r4UkPPaHDRysHwdP24XX+CYjCdJkEVwvyT4TEsnXDTnnW+o056mM088Cze05qMc6lXLkosmHZxL0R5pLunHVcerqlN/0XEh+4QQ/fld3RqFSAunT/OW3azwXzFrtXTDS/ppiVdATjdkeelecOFkOQAQlxlFoDbJY0UpIF8P1Ge7dH0ks70GtAENXkVQiZAW4PSshy3wYM32nv1QHd+tSvQGVuL4K9IQ5MysePyds/l2c67S83AZG7EAJnATxqIu8t9jfbDT80JzEdLKNeVkTSs7c3b9T8/uxrCS2qng5Y6GMZrdUS3OdddNPbM4vInVfdwwJLuVo/Iy8yciRqo8iqyNDDtJ8qzjKdXxPYSRHRYN7zzoJKnZ0lyE28qvw1mftsg4RsY3ruXZxXhYJYi9GioSxbPSSOYNID6idFBKDAUOgx9h6DXCOKkYdS4xNGORHkVqDP0NRqGrKb6CX8y1f5F3G1glQsu5DUUAFWc1zf12RSfqIAArvVOHNysFq8xirklC+LvDvR3BZEP2GiRParqH85HIK83tBZjG66NszLh5+e2w8l2FmUN53GnRdXROQni3qZ+gNt34ErqNEdpEP1IPoo+RjhmnsmCuAcO9beuCHSgfdCEWN+i+lMV0Tg8j1lU0sYvszr6ehm9NN3Rhf1zllJOgKeIRl9iAsgnHO0wuYNlTeAiyh2XZYyLMs76NqLnppDUb/FGtSXC4L452vqRRfQbyjLWyuLoaaE7Yi2eFDE/kb24z0ayGFXHFwrmMhLEXUx9Usb7+Lwq08FuYTqXxFivyY5gJ5KL+BezQP+CH+lH21jVfBSw+P+4uzxTSVhEPb3FYf1jA9bgD/Qp2418Fv+DmLuDuHscjR8HRD3knTV/2+JR0q9Z2Tfmf/4ydfr/gvHd5bT+Fb8OHX/6+nfcHVwLePq2hc23iu8vVpt4ycGxcq3WK60TanMh4pFbPr/lgNxTLNNXNRXpsf2dEROxkmN3D2d9thg7pEdBZJoib5RNBjMm1xvnmfmeZtscP9KUeD/mgW3iur0L8m5pze43/ujCSBwgwIKpFVHgYPBDFgBQsID7wJiKZuR4Yok+Ua7V9d5h6u/IvuMMyR7hmzNjfzk6/tPAStxJA4JW0o2x3IT5yvi4oXrQ4qYdIDSgOOk5MOhhANc3AtNICHFtAt7cVDAx7dDYtnGZGVL3XHrEoJXS4ROmg3SdefDkkvFJH+lW18KoDwjbSqZG/Q6iSM+gVxIk/Wn0gGYqpxklq3Sv7qppB/1pdO35eq4sAHHXtsVYHlupua/BXdHTYwKmL/8DoAxH8rpHjE9duz+1PsYOfXGqMCXcsp1ivuhv8QneiH8AyxB3cWaq5tt6VoQuG33LZLpGD+hHmxklRDjpJoXOIPuy8+ms4h2K1Wkm1p9KAA59NMb+ctmej61/PX1Wq5vPdB8sH1dKL7ByooN0HR3fD8wO3YAOhsl7bnDgCNnyWA9ZOdM1BwbQgVDhOOiaj8hwzy49LSnDVKjrGAlU4Kgo/Jnpbs8NRNXxsCNq1y0t4l2MjvnKLahzuaFBL3iGlIY13zCbzxuYCP86JEpROPJm8pg8WqLVHuJukiXd5OmEvjgEP0QpvDv9TLqXkuvpn9J/reZpCv6CJ7IFwEizsHRl9UDu+kx3uifVokMWU+JIVMiRezTd7alk0SeUZYukHG0zeUFX25ELQgTarGeDETRSSBdo4lpgLZiiUYbyglHmLg3vOHjxWE3h2yXkC8iAR43rBjYMkPNakHk7KYIpx6+jeElduLvhTSIn0GZXl6yhCNiQ/ZwuXEfuWOlaAMFvIA8hDG2yOEzsryTSB9yDGwg+LUH+/JECQkALLgyMzF6u/xvi8iZgIgo6OzuhGFSpJSv+Dz4eqKIUuxaIEg2K3FPTDewCwCJCWXJJ4GyWZISAElzQZv3yzDncJvOtBUJvbNvN5+Um+ZXVsyXRgoIpmI7TO3ruBCSZOXSnvm/KcB8R12CKrRW141ZC06H9QKp0nxc6OY165Zm8IuOhqAzDJJj3MCxjk84+lck8EgZ+7/h37J2p0hXBgq6Gnu6xOwDVVqMClQUCrIkXHiqz/YCkY/t84mAbVjHN0kI5Eo6oa4OHYORV2iBbZZrEYFxONx4QdO0Kb3xKnJ+SEwm3Wng+Gwdjng9H8pi8K1t0pcIoIQdz3GKyJaPddIVjBPvs0RgODTCABAKlYmnwbrykiUsVZ+AJW5hY4NDbfT3dVhwoxVq8DAPXRckto1XgNTSSVOCnCIbnKXYb9D6ZulX1RBPWm19s4vc3P9HEzQ1/QcK4hG/JV+W/Zd2SIOWosx9y1F3DKNao8KU6NnNLV65EqdNn460p1dwdrqpHp2F6Q16Q8JQEXyKC6413z8G5GP1Db46L4DALn9iXnZHGSD7y6ZFHRv458v+4rRh51wge2Z/ixYUfXMAXYm2bJ/hrbWf2kY5tQczOYnPg6bxX9HCvj/lpii2p/dDSfvbdTPP0DOFZR6iGombcN0rc1c0B5wQFmISsVc6cFO9dNiDRwOFEn1lO4w80B1LpI70AlLWDKGzEAxczkzf6TCOlakEk7zTRjzp1HmkD5aQelHWnFcTNZuQcvMM8PxioW9Sq8Alfm0owhX6KUZ5ELoMw3yLB0Gv1OsvTIsVpP+RsoPWoE0sjXXhj8mKSqYmh106dmsini2k83c84RhPXSLNdjUZR+0zFC+0ESnMvdADlPCTOBh81rSBjXdZjhPUvoeQyD/P39+0me3cBxf0G752EkxrlfZiVPP901RnWcxar5Bs8VLbye5IRZXB9tqF6DJhD+CUHJqyzWcAbNis79DAd1ql4GBdbOUzRlgodKbXrlFvLTXNUrCx7GnTIOSCUOyJDiwNLVjS1MCizlFSMLczx7m+QWwoVA/LopgRGqVLUPEo2EGVJ3TR4U1VUoMoDm9e7ATaKo1tGjCA5ix14Bi8pS3mldkeXUUlfun0kNSLrEv4Nd+PhylBKa6P9UFu1vuDnse+X6nC/zfN+oh1LvHb5MrEGvs4vFBfwhT4Zv0zM77rO7EXD5VbSN0Lu6Zbxxsk2qqLkpj7QD0JwlPPjnG+Hks/KUTsZIG9m8nYfaxQBPfZtayU6QgJ+COsj6qzCo9m5DIPKIhp/lQDpD+tBDHHfm5RYUtaNdaeXem591GdUZv2EI9knGgYdmDGHK6jTfda8WdXsHO1NVZotPeZYojzAUTl/aS8IN2CXVMA8BxHFnAGZHmU0T0Un3c3KrpLM6VMls2zWtRkzgDBQyAlZSZlKKs4oA3aDglatlVAGw18gyjzLL4Bgle4sAPAP2N3FUMQfoEy9lSVAbeM9J1NVVXJblfpqDKY0UO753l5SYSDeYFjxo9WxTlaNVUm5avyUzTUnEOzfFcbHZmZkplviN8rp6uTYULOmEhUKZd4ynKeGauF0MD0d8nkl+iA4EQeiCO2gOijpVGXf4kmtLLcMID6H55tNMpy7hYvdm+FcUycotwP2gHW9dmVXeruISER7UXPT1C3wbx7tVUc1OPBX9xHlrzprOL/2rThtisnDozQfKUiUGc7mFyBoknw6wS52IxsjnItOXEkDCMpjzxgcgEdetqxo2aAfORXxYXgYcA4FvAsI9IJoHl5QJjUYRUUcyPFOr+yF12+RhChwK1D5ZNVUX/GoSQyrV05uiT+UKVArcdVxIFquUlhGujDhY8Uebg8v9BI2qIWRiQrkhXssiCs3AOCTDeotu2ZlhUnYJrOeVsfLZdpakdbECs5jOCyZCZ0iFGGQuRueaMJQF7rNM8MrFevMiqLOG5eZ90lXlhOzvWLSNqp3smVXxsv4mW0uAfGCUhgLu/3yAYls6rkxxJ+sqDsefaU5bbFSrlgWBMuVC4hy0qDMzkQBX7GLatWk1Fm242hTvkJrxZdjKwKWUfcyB4t3WEJwJj3dHD23UqGjK8I/RZpOQ8vZ0IpPJ49weDfvu2IDiA6urj+wogeGpUymoazeFnBHMVXK6T9bivtWeK9slb/y6lmb/oMyQznqwvoksE0AD/Tqb4EtVzLKFXZl211qb5iyjUVx1jbYJKina4cnGneCiTuensinylp7Km/IluQNEztT20MsicltYXFzCWJ0AcukIRFQvpeI+w5pIzFj7FYzRceKKZQepMQmJY4cLj7WRSiPXlgSGclQx+y7MZhWGZnK7pTIFCERMZixU31Dd7gm3CVFHVnXdt32vSEV3U9tZQqm7gAz6cv2Jct+ObhTOyp4SS2t3tdWTGAii5453YUz9VXFqTPnL/Yuq3xaoTKAgZ66kZKKH/Cs7XAkFvdXnNsKalq2hnJ2XX7wdtZMfKHwx6pizxzuXjpdErIpfbluE6Qzd+BRCtSWpC92uHSDz1GwQvzoQPusotGjC9RHpbnubiNE0JM5UTQC+CGUfKY3yFRd2BDYI/SW1yMNSBuhqlWuWWCVncBT3FPK5i++GKmw5ByGqtP0M0AQc4afwSgIN8gL5DPbbYHjyDMKwW5BurjZqIlalNn6gKyuzNV2yCoYqxw4ygUZvhkGbDJgGPVrDS9P4eo2eIHs3zI4EISApi3bCp820DiNwIBML6kBrzBvypuaUwSIzj5pYfaef4Yi0qhs1hbHBBuAXFXoheB2IdRY1vST91R+yAEbDKvfaMnh+JcR+L8cz0pQGo2sdca6yhd/pZZWBtR73zC3SdukQ9nwoM59NrC03zRrZ3S9lq3rGrWt7fKdQGfm5YdKbAznw5224URjnm2hwg97fBjJbhmc6kkDO4FlO6kmcj2/MlS36opUVo3Y/4YWLNSKKAMdXAGvqcgsvebPYzbDZEsG8p/6serU5tBvauw3Zo2bMvPQN03UjgZpWWAFpgbjtfWWHMW2ZrIUOeuiBzjfKZHO4H4dLA2w3ZKvG1CGC+Y3eLU4QyX6RswJ+LFamEbK4d4qOxT4l9NSfqkomPH6G4v0nbYNyfUqAZQPR4CqyTFgPHYuBasekt7Y76AcS+9OcIMYNzjNcDWaNSjAOQJP3nBsjXLbS4bQSI/DTfF7E31Ue31X9LS16qi+sOj87lDt9lTzdjKm6e1Q3EbOj/1HYw6/58K5u2M7I1aqD9/CTfx7DkNhNpiB63Tpe7d3xL/0p+DMn6qTfyKdP1kBt3iVkNy0IdXRoUMOW05TvnFbIbutCJQiMSkYh2D/FkUY+5Coew5mf6HyL5oKEkrRNpA6yA+9stptpcTvGTh14shXKUpbWe5lFOXA0yvIjpX+KeSWRF+DIzfeqN9eO3t5bUK2VIblWjVcQwQV+XNb6QjiPa3x4bW39dfeXNQPOLvWrq7J4L9NWmch8ua2zHBrasDQOtRMMV9Ju2I9NtdpCW5IvU2zkGCAB85Y4y22rG+cjq4W78CdjbH5zPmnjcJGlY063zjfjtq5ZpLHcoafunzTIacGWB5j8MVyB3YZEnnttRxZWnjTqTGmJ251iL4lqwgFgzgVWKX47pj0N/Xp79aQgwTy16G9M3udBKb2UiIcH+U+g75DJDeNK3m2iSUGY4fjH/4xKchfVOxd06u6dBURKRHXx3hoMcKBKAFsWQoGlkBcjSE6rbbACTyONZFGATwfFi1MjYhzyyBNIOOfmxetvO3E6MMSJMr14AG6kSNVDLxWcjBgp3opwkjq1ycFAId8mGBSC44BBnFswZjuhTo78G0/+zDDLIVukxScgEQe4rCcMhDZddSHFVZl1/H4zmj046Dy4xjpfh7LpNcDcR05zocd7Ny5eNiYKBuest/33cVSoTlY0lh2ZNn3RPsn3BWJGDiecJMRQ49jEc9GwwrlU3jaHYtej9R15Kqw3PZcIUFD2rq/1hQ2QYR7LAbT9Ejox37yY3UbPLBcN4Twk2XVkCC/4tJ1KXc+v3LclliJrERr8JcTN7hVHL54bJp6TmDsGSSREryH6WzFlSP+8CmcGBWLT8sfSCIS8nNetpudwWwszzwXEvGSd5I35BEAtvLT7o9eFQ+d7fpfTVDgYfyrzY2HsrXN71Y8tmTYMA8QgAwGMELA/wEgaTOuorjgW0N4NXoQGQCXL27JBrW+Sg/RK3lstqZztT5da8pjzfTmlhnD7vABUT+vBVpfNv2c3D8T1UVXuvf4s2sFxFwp61q3LxtW0LPUidPfMt5SFVMfmoPnayczggHj8H9xxDgBFNhKbtcHL2pHC3nQCPDg+f+n9Ee+Q++wSvPyTpga4zj23PoaAdZAM6AXDIOfpcaUFhx0+irdsJoMbWMbqcXJGDpG/8jMM+8LXAWv6MKq3U3rc3eGqF1WVvYSaiK6XhOT2FHEHPlH8shLLym43NRPRV2Wodqp+plVV9gQWO7ZZYsApj1XIFRZcRsXhj8EgN++SiKA8vLluIrrH/fkMKmXorEmAWZv6AdCANAaYCCzwTd0kCwtc0ZMptuT5NNz86fbZfwCsb1TvkSHo0LfUV81E43UE9j4EdZXl2Xs0bJ+xWp/ZXHsKhiT3ehwiPcx1QfVHwJ9a7m/r/LypJYEEx9iRjie33dCmckKo/28oIIAIBNIY+JBtMSP+BJ/Uvs68YCB7kZlgrWOrOpZljE4+RpxrCxvzoMmQM/U+qSF8Kmu6auhq5UplZn1cUU4J1/LrJimZVchPjvlnrHKo26SX+4lXfQA1uPkQddaAO+8WbAiijF8iIbwBooWmZFa+D0Xa931zGenbru2q3OGpIo55Fj0AYD/54u6h78rOECsFNgst56rjLtOQFVx70Gt+9aqLN0CIEHEizwlIQllPDPygFeReZ2AnGofA1Ds5QRks7N4LhlQLzDmLgxE13TXOZGPCjEqbKbZ5Lt1LNotIFnLH8t0ALmatjNBX6kcWCff+Y8Z+Svz5rpaBM0yxm9xD52bCSIDFmmD/y8Ko3JY2jIu3KniqwhMSFJIIklkmBsN+ib3RElAFpEnzLqHwmmW5nuyorhbWNOGJgD/wNpjwqDNuXkSMbkc3m22GWeZtip6yipsXcJp1DZoWJfWv2nlRgTmp/dFAD0QiWDkP257aE0SgLHepfsBbaAzgfdLoJdgD20vA4d7r4AafHpFuOjYy2GHob0S1Cb1ygizpFdJwOUH2kJFlSpoYpMcR0WbfGA8AL0Ez1TpZbBnwb0CQpLULlb3clTN/F4J9bOzV8bCXOpVMgiBV9pCO0CvCv7Dq9dR9ZE94UTJd2t1NGeS+laTQOGxAfLi3MxgLRCzgIUVqnpw/V29o3ARx6XCN2z5YjV5K+EyrZ346fDuxqmC6tCeGN0Anv6mpyFGkDs8QRhZP9LBUGac4UnHY8ofvKAvGe74NC2T9YlOVlGyhm6AeeBQPWkQVJG29XFxioV/NpbNYj3ACYUowrpusGAgBNuxCDLR5kcD1rAiyx5kWUDwcJehhT0UuYrwPF6PQEGaqm20o3H5tqSCkwvFv4EyaI0HYnZtZdGcGbdPhVgpRW5HF+NErDVN9VjbznCk4M9n9fDXSCCdUP0g9wZ4wGlIrbTvC/K61sopqRmbHLbm4VhaniQHLEEiI951AFvYuX1nwqmTiQNuu3yjzrDnofxLMXI4RoHIekgixzvgOs4vwGVgSHKTnpC6NnlzMXPjHNalRgiV/Txm1420ww2S7CEFbVXAM3AyUgDbwoLwL1vlc39IYca1qlBKLMhIJCMPxkIK1dB2N7u56Y1M5JZxr0rjjjfDEWnNyMJGcBr8ITMFjuSB23KSDjgKtrpFVWqJNwdbakQxndZ7wpvrb9vDHAW2wDN25TzoJpG7AEAdwEsDyz3Pre7nCCIQHb63xYJ7lmLzWDcDGfjbFqG7GO7GMPBp7gV+mevErZ/eqTLuXjZrNeYiW5/L6EwAI6jvcrJ4ZLQjyZGIMY5qZQrte1Z0UyAJHn7vACngKTplUuKxp6niWUCygxdzn+Zb5GfBK2Zp1wsvlfVq9kV+VuyHYz88QxT07LLCyYewGLZueGOC/QwY1uaYeQTvNWQ/w6L/vOMQsufKoZhEzBQ6R7fCdNtEdzKDZc4iJ85ZssqFq7fhOsctfC+zZsMWgR17DtHERyxBImmOnEqWZJgnuh8AmJEzlxje5EoGHaXmVrqM3EvLAylvTJ+RUVDRYuWZj7vmRi9bToyy8uIdOyZWnHzixsbB7Tc98ePhE5RLIE+BQvn58mtEkQW+/tCXf/4CBBZQUC9UEBJVJ7BgIQUpLrRSZUoKEy6CWCSJqIREgoV4V3RnhRbTq2LFiSdtzV3RBkuQWD9NWrRB6YDRpQdOvyTJUqRKky5DpizZcuTKk69AoSLFSpQqU65CpSrVatSqU6+h8/6rsKKcqKnB0Cx5hyGN2rQBiETNo0ZNmlOlMlwEdySQWlp0vFZtUWrXobMtD1xw0imnTZuxYpUCZezT7aAevfr0G3DIYJWWHXBMle6GDBsxasy4icCy5XQFQgtjRrp06nCY2DiydgNNOlyfXhNN1UPJw6Y700woyjaq1qBeowrhXltto1lzjjjqmHkLNXukjSZPmKX57KuPPvkmtUXHnXDSKactOePsHJfkKhUb9La6YNtFl1x2xY5dV30erk1y6/MhnCcg+eYi0CTSGZy+3jZFX+4H68sqWvKRSF0Frut0FOOQG9iXosMzSfSox4Ihn1TJEIKkkRRm0kWUNXgWchnVJaqDaSymvMwT2po4KZX1ShakeeE7+cWGTcH2JLOvWZr+WfHsREWhSDSvpImFnMauWl93zIM8wcmod7ilKot8pbFQCjp/YjNo2AvarQUBCuahuohGSE9fj4SSn+ugRTQRpHB6yEV+2od4iHRdtvVa5j8tSRzo0vC7+52mLIx6pmd9iz6FViaqwPWp9EqvtKb/5rnYaPq0Kdy1Iqx3wdVkXvVyZ5V0zWkdt/rNNzz9kG4HjXHj9qI5bn7u8S36ou1x+3bQ0f/x3Dad242u+Eu/+IB4reflACgwh1q9+nxp/A/q5r9Qrvcqg6tI6rr5eScL/Pk45anuuOanCn8x8nXPeSCQjeuANamgM4S1syG1rypbHOpwmBXtxWa4ztmLzWJWxja+HBLPAbO05K2HFzMKlcZJZxBczc7Aeuvi3EA9B4IgCIKwOWL9m/WsF17tLrT7qPFl25bBtW4i8tZzR8TH7Gf3C57HzaujxVnk5kVLl5pdVYU66AKwNBoyDPBWox7z3iZayhBNLMwvLFQ/EShBLTN7ONG8Pl6r76HMEj5CrVOrjDj700hHb70oGfK/wSuSMnVz60UzadH+oeRFP6q+TacV/DSx1fXEiGaxLbXvZaK6aTmh8czpfHrdrle7ZJv1mQiKKvxO2eFUiyvHfRrELN+XPhr/AUKnVoDgMZVFvmrxJd0OyKoFgqQoxzTH1snj+d+uC/isdKWwcbpJmuOnzeIGPyIDBE6qoOqebEPngWnZPD4sTjQ29ho2FgzV8YVr76Febq4mHi0WZJRol2kJOm5sDNhYULv0c21jBst40cw0jIbUjCOI6u0ZPQbpmO7raE9zRpdcmCg6xpymEghKqX2NW+2CNqONa7FatOanMRVvQI96aSTUUTR1TrRxLVaL1vw0pubteRVIiI3dql4QY041Fai6S02pRFqWtq+Na0zVu2rrffSiew5FyShbSsBVToe9trRazHpdtaVRq6pMhVwmlVRcIqGg/ORxOQy6VJEEXixRBC50wJ+e3LY92zJnm2o2E7MNNlunszU8W0WzFRGLSJSEL1xhC1MoIQQTVGCBBCAAJAEjgUbXCCF/KXDvrFPsMgnBQsRYS/X/dxQ1HAbrmLGf76hrB1in6SuQoafff1CYwQ5dP9FkrodXH0cw+MMNKKE3b5122d9J74HqHll8Sf7xy7gpzlcg4P9y9XG++poQzDP+BIPHD9OMFaa44U+bzYF9ra+jspq0BISxvspSlUIQ/LRIJBBmqCvQTsIgIqmBSExmavYwvLKdkZrkETxaDHgdywwP+/hfvDsAAAA=) format(\"woff2\"), url(../fonts/dbscreenhead-black.woff) format(\"woff\")\n        }\n\n        @font-face {\n            font-family: DBScreenHeadLight;\n            font-style: normal;\n            font-weight: 300;\n            src: url(data:application/x-font-woff2;charset=utf-8;base64,d09GMgABAAAAAFxcABAAAAAAzcgAAFv9AAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGhwcqnQGYACJdgiDBAmMIREQCoKWFIHncQuHDAABNgIkA44UBCAFjUIHlXQMhDQbA7I1bFOw7LverAqh2M3/WY9CssL3NxIhbBzA3MO3ZP//9wQZY2x77QYKEqXhBMVR61drt9GHdWtN0VRTa8rggWaP0W1FXRRL/fBsqaD+csLm97PdfduIL5v5oxhnUCzj6KWF3ygCFBFhEUExiojEokAUyzfV5C4fjsWoJz6EbngtxSj2EAeHvhWf97fmOL5y8aMEW4LEg+fc17azRfGGNSmn/6vtOfD6Gdg28ic5ee15/tKfc/HeKtoIhTYFkdIplIJOf+HA3cTVblyQu+mHUvINwDZlzjndEAuswEgUq0GREgxKMQEBBQEDEBUrMSKna+1NF+lcuXJVX7jIfxW/T2fvrOBgRmvZP+EKqQPilVa2DHi6O31gwYTY//d5PWPLIAhTG/7Bbu/fusVQ1pJAgyQgSiH+eTjkd8/7c9MqXdPW5DAQCTgKOKDoU2vN/5qbu3zBNGkeF0rYBmePzsLaQq1TKimalWohks381badpXt+/pqf7B7IEugi2iKaaG77P53WH9lxJuw4YQW+NGsvOIssGsdZBdZ0NzocmZ7TpToGHVQVfR16u8Pyih7L2/LqwH/9we/svXf3/ckSbCazIkoiSDzGLPxvL+cs8Cc35UpCDtDtJkyASizNfL/pGGNInl9pHVURDuEwol6zfqcL7FMcwh3C5S+bvXX36+me5iGWVkAL8z8bQZZDGkPo+qtzuKD4gvCCyLWlYOtHB2gO4gtDL63tVSBXEqSLiGV8gk74vzktpHQpIP8R58Z59XknZHTJyTGFLiM52cm5ChkhZ+Ka6jMCpQJNrnXto3IDjdqOIBs2tw8Mq2hVWP6UOCfRpVWhQEjisRqERpUu7BtP1R5j+T9TrdIuNpoEZN4SksYZzi7eo9bZFKDWmcO9jc7Y7LLzVb+60F1VaLLRDZBw0oCgDADOvANBaR4GHMMGSB1AGX/OWIKUZjgcD+mct9Ga7JyL913sswsvCC8Knc+ci9KL4/Pprf+136/CP3+RxeSETGn3th9vi4jvW6TSmG5W8X0k8QahEaJJSKTCdJtOLLRATfixn/7nGZghBVPkIikqEpj4Svtsu77zs9wnb0nxXGneK2IQRhihCMf4Sv34TBnW1GoqmnTf7EycCChTQUEh6vV1Vu+fc1/uoIAoqtuHZAIIgKkdS0xueu0TRnv0tFluLQOrv6GfcvuXso0M72tuUdAzZw2qeaO1R3spA4CmIQG4IICLUFES8clUaDFoj22gfk9sgIPq9gRXBIJDiZYkXa5KrYbsrX08gxuCuApDkkwgT5U2w/Y5PROHOxNu0MgYhPJVazdiPz9qbd4ygITNtON4yc444+MHEY6fOXvK17+8eipAwL5vSCB4pEXSnJsSUJzp3RoQ8GDKljsMCiYRuRodRk1VH+pCwsyMHQ8BsKhYMhSo1WnM9OFhCjyZs+cpEA5NikyFFLqMm3F5iAovFhx4wYvBlqVInW47zNJDdPAG5S1IuFgc2YrV6zFhLj9MDx+WHPkIRkDHJVaiQa9J8+lhBviy4sQXAlGcVBKlGvXZaSHdxQg/1mD8RIiXRqpMk367LG7OBNoYvY0J/mw48xciUgKeHOWaDdjtAFHkpzAFEmXStVhJ2Pgy5ShQpkaj9rKXLcoQKg+bsNesg4467bwrbrrvydWXfyVEl/L7ju9dW5QA6TLnwEMQLJKEub8aYIi5JVOOIlUadRosJwQiqXDLfvOWHXfGRdfc9tAzr31s/irISBFs+d2lokQVCJjhkvnhJFvFBpy48REEBS8KTQKWtC1RBu+oSCBfiSr1WnUbNG63aYvl4YxstkjlpLMuue6uxza89Z/vHX+7tiqX2zJFUuFWTbqMQdlx5sEPAhoBaTn2a0HX1iRsfJlyFChTo1G7XsPlhJgn4m7da9ZBR5123hU33ffES++bP4vFcLetP7tUAVQAadNnyooDOC8BZYhYmilWxYpAEYeBSyBbriIVFGWzRCQVqnbqN2qn/eYtO+6Mi665PfkfakOCNmqT+F8XAKDwbo+AoX3W+CH9FClTpW43fwcsOIFQJJZI62dRP4/6RdQvo/4o6ldRv4v6ddRuJBjQShZQCCgSVJl20HFnXXHbYy999CWQjtzpM2cHzgcCFk0SLpEcJWo0twkAUT9k1EBMKu9jrtd+J9302t/mySwb+SlCLOVIweLYEXZed/VRNdXf/b2VuI8dHGSSuc53I0/iufyyH/q/KCIg8C/Mi4S5fUZmYd7vfNcjy2aPXDKUAcrz+TDv5928nTfzel7NyysXw18W8tUAFPPYCHtKdcqw3Lfyl/KCqUINWu2pFtqomn97JbUy+qz88M13P/z0i0Ygol685FvEvzrwIWEdfPARKb/2NZuBW1Lihgh+FtYKjf97dsondN984bxAp6Ovz3uUE12o/IWem1Z4gda94juUy9HLZhHNip40ChQWPWB60aLotlOFxkfXnAhUMzpg/FDlaEWpq5jfSfluGra9UvL5QNOb5eVInEfg7qoom+KekLv8JQlyF57lIuUKqR0UXNCCyMjg2I6NXKP2ipwRbN6SyGFBSwdEdg56tWpk6yBk2Yjql4nStopE8GEuRrqjs9EkfgQPiZTID8EYcTfSGdwg0iKvBufkdHh+iYtiMTL4QV5VMCwTA9ZPK4k4cJjQFDYCBnhhik1VQFB5fuDrrVovuxo8QYFMlbPNGAItSzH3iyom+Ydr9ZR69EvGTleqVLEqCZ82EjXZBB0kTPDCGCh2fATHfpJ4W4YO8xqMv5NgEu+nD0P8SwPn/q2AMO50VUb9ab179A85H/1FDU//9k931zNjD/t+b5RYYdve6hLEhkxuKnv1kJaBlNQUuW8lduDHKZX+f40S2xW44xYddsRRx5xw0rJTS6LN2/iMEHuZSlqh8PAVZcbmDMFFRgRHjk//EIK3pk+ab+C/ZEOMwjEkYmJJSYk1zy4QuZE7Ldp0gEHo0qNLNMhHgg4/ldFLielgSZ8BQ0aMmTBlxpwFLjFgLvXxlWGREt1Ns80kSJJCKulITwYykonGY+NIlYbXZjA663Sb6PptEUDZISYoi1CuyCKKb9hKZE2JGmlvE6UEBNG2NMCgECcjQK7kkxr5MU+7RYsZtWw54w47mYlNYFjksE0gqtcmCBLkRv4W2wRG5fclSe4M1fT+EVUyM3b0EXXkycSxR9STF1MnHlEhD0aOPKKRfJhbfkQDeTNzcntOruTnuODzJcKJpvdTAo+oAtCm3KmUZJkUNDfQFT70NRMQF7dUr4JViKqLFlnUG6+s3MqIl8fitW1uycagHwtoV01Vs3bz6gvjSr6II9ZtuKS20UgpAQs+oq5BS5tyFjVs9Q0pi7Kc2gLIem/w8f1lO3a13vG1bORMsss5REJKrx/D/ECbNftfHuA481/Tef39HcDf85hc5AB2AgAieOlqAHyps9iHK/ciSYegsnjxf4/blFCBOxe+pPIUBWbNkStvQbCIOCSKtLpk3QufkShQtvLWqs7pgXVsZBsXuZqfzA2dXCEb7+EYTuACruIG2ljCC3gL72GAGo/wZfwYv7Bsq2Qbds6esQv2gr1qb9hl27ertrZ79u/FnGI8v+/Wr9UWQFlwfnLkG06XAxgPvpAIovDlaLVm3YbP8hub8Z4zc25uL2iHUa+j9RF3PWaPw+MZaGiTaEnZEvQa7q+xNfBLAU1rvbW1IwK/kpRVxJXn3Tu/rroLW/N36RU/b/289rPxD+iL+JINoKSnmvTdxT+fJXrOb87nzu/OtOs3tkbnjFPgpDlKHDJHBvD8C+AY5ohyhDicHZoAPD/w5M6TYpYHANjwNmEbALIAqCy70RzngY/PBA12aBM7ZdMZgKUckrPb6xTMGjnB4shMqF460zO/4JxkUWRwa0dRf/vHK4yqIXHDUK4WmQ9frtLZCmLDnR172TJkgalpM1zhBm8GLFlx4MSDFx+BgoQiihSFIk6iVGnSCWQWwEOgPCj95atUpV6zHr2GjdpryoxFBxx2xlnnrLnuljf5aeZPJpaTJCzJUrSo06u+z/WQK1iDcU2kDBkZUErBxQ4GfaknK5asOacKAQUmqDDCBWbmDJkw5QrGmQtdITBQwoRDJwyPJQkDk1CEdcXkCpUrUqZCrU4t2rTbZdyESQ0OOe6Io047lqhT7rvtrnteWvWaGlbYgiW2YSVN1XQogNXRUkNPI31NLHQxYqYDVDdjrWwNsNbH3hA7gxyNcLPbDu72gBvjaT9v03zN8jfPz5wAC4IdhLQMYQnOSVgnEKyIdh7ZRSQXUF0S66oYV9BcluCmeDewPZTsDq6nUjzA8QSPyCsZsrwl9l62dyQesdGP7hqZx3L904g+oyaMGUQTgw4NIxQCUogwBERYeOFwWrWBKybgpYSEuA/+894bbwGQtzIg/2JyNYD292//C99yUyhwYJlO9TL3BpFiOEBLWFAtHAB2apFMOP8NtJXDvL5Tl8nscvUUODqVKxQlYJjXpkQeogRonkzY9q5uaYRqNcqRJU2RDoZ0jnTOfdVqNuq1hwf7e7vhg53qdkUGvuc69+/dvXP71s0b169dPX/u7NapUvGEsDeX52fzM1MT42P8/xG6nhQVjVTSlC2JavUsT4iYw+OMJnRLVOr4CC1kbKJCzkh9nzPgVLE83oE7ycRaN6Q/RoFD9lRNPZXPzCjKx1D33GwpD0BTCctSY04vDwJnM32ro8oLg0TqoFDP0olxX/i98f4ySOUEn7BzaSWOUnbqHrttNE7JW6kBfKvNOsoUZdylhzJLBqZlRVkXfDIPpZxPow4esvug4ZNxuvVTUj/MQ1uXJ7uiGz+jKBO/sXySkUnyIc2W6bQIQvqVfy0oyB5tTa6VVBbBRFjH/qPCaKSYF5j8j7AWj//LaLGSwzv4AP6YjOCzPy4AcV8BojmWxUb5k6ED7cluequmTgquYH4DzvlyRIYu7P9pw0Kr/y2jaVYLq59SUv+sfmGwTG+1Mc9RthShIqk1IGVKut0ZvO4X9xIRBCorNxU5wTHlxGJOyvTCeW0i1gdxKAOzVp19XhzRvPBiuBCo/txhQ9VnTQ6keZ9Ad2JMjgxYugFlogPqgIwpeN1HcPnYmXqg+e1luAJRULNq0VeUKcmnRnX7tKnNLqHuozItciJicSRULxogW+Sd+WcBXuIRAojVDDIWg9Dp0SJfLRpmJhooskhg5SMtvDuGTH05GEyc4ZaLmQn4XevPSnj3kIDnYqboV/NFphl+7DatyHpZKD2WCZSRAY6yYSN6FwujC2XVkfdoj7IXUOfFaI1EjNACWBSGGhggasH7crSar2SwEJh8i1H09Qmay1gGHqISPRGJwTPrPFR9wZjpbGeHDRHWnlKTZk+QjiZjtbEbMrtNk+G7DFXKbv5B3Ta2qOqBukNQiwkXYSMxtcTOhLxuh6CmyBH3/I3ClaXEKqKiBzM2veSxksTDY2gnqeMkR1IPblmkxU43TDXUHfNXq9TV6+Yr2+oChCxsevdPTWqAlwr2US112EeNp1QK+FFTpQbzoqd9cXkgwte5rMTu76XmtWiQ6OhRXYZFMopDHSMm7gERt07KjNwkjYueRxPCk/ru++73NU1RVGy/3HwKxiZw6GDASNw0zQsA0DkA8E0AnQQh7wDU+ADURUA8BT6/ONvINFeufSqCg4hhq8AUapIctfNwQ9/mqiG1onFyZguAnRt2ra+bOgKMQysFc2rO3kkG65Sul2IZaQTOmpiB0Wh0+1yBARnQvENqdmjddYsFfI1L2g1j7BwyyXfIDp5K8qSTynQYmua3I5PGjKZYMfZNzpiP0bA0N1uCHwy2NA+Ul1BrYMGux8TKq2RoWdoplje1HhfjzP6vJtDxd0bnfGghgFiKyVxqG9hAT+RYU+doJRWzRkZxFDvXcNEmkU3sOM7NxQM/OeORFrJVD1VvZRqVdRZOsyykXdiqx6p4GoQZs4w5x2xjpZWWMWrnWRrXSs4TWUZ5EDl9evZhnqy40b487+1Fa6sTHQcB9FbqKFL1mevKgI+jcGYSrcYXrh1rPonDRtLQqmLj6trwxuhahVY1a1e3P2xaDJcq6tYlm1mX74k3Kfs7W7ZR1FCYtvQBZdl66fsUg2mcPjRO0oSDAm/7FDxaqmUwlzxt84VZK7+Pu9xqqp3rdwWgTGrTmubUE+NNHE0eUdBaJU2WhJGjv4thSFPC6U9ce/UugldMVySRiELfRFZsnTBt2XHuq0k9Nn6TkUFP7dgubUW5zp6Eyrn23KQT2eHHRqu9U0UBMmXY2Sz7PA++ABjGKKFXgb/ya1taK79Pp/GwZkECWCukZclrMim9Vj5tZ3bX7GgqlRY0LPfXWqppjqXtOiznFICnPaNK7/Y5D2C3Jef4qxas2FhyLx8R4QUKNEQmYqbWtVQoqSoUAKow4FxHymwKMKyqx30jQLMoq6FoqW7vv0GAzZdupKkgEPF5iuz0BxmnszG2JDhWxYRqCnN8q8FZa/7HY+somXpIBiH+vB+WO0Ja4gk+AlQ9WS2bMrQ5HAHLPxBkC5P6jEDU+E1RiX9FsJzQzl34TZOMxJVtJfQiWRMYGpyiwwnexdKpb/mBzCF+bRAAxxBVgjEzeqAzv8pAppigd7BbfI3DXxHA9cK+MwWrUAN6mlT5NRBbUZA95ApNQESY0JybzYRFFEBV7jcCYO2YkLzMh9wHbJBmy4blHP4YGSAVBCmtCgCMKhdVuDT2KTJSBWC85RL1gX2CD9v/RIi1TAYZv7h/j+Xl75f508abLag7hA7YG3bjGq5XFTYWn6wTTt0I7AE02MmJ6PoPtCWlZaLkAE9JYJ6ps+tffVWhhWLKRAsCJslrqMBlR+8DTsa0cNt80vkLyxuuCNkf7eGTWOAipjtJcytFjwK3XuAUc2SZV//WDfrUDqnbAy6YSVbH67QW02r2vNxCO1+H1QbBTd2CtOUXVwlCabS1jtisSipRy3WIRuaL1vzNn1MSCqM9TI3Y3k30gTJqjNLApbx63bwSIgt3KBVLRNIdQje85DQTuQuYhFN7kq3BzBsATGO2Hbk+t2dB1OoXGYE+IuowtLXrz3w5oP1IAMhJ53OIX/K41rotnzn1G+igVlm3KfNtGFGgJECdX2J4KDRXqIQa9F4CCzC8hHWUIqkHJrAS6jWfr1CaDgrpYoAhOxkuXn2QgACXsNHSh/oHQuM2Djg5ycWRgplMxUa1Qd23Rj1H9J3E9x0+aAdCx7+3GzGnE2TC+RZeabs2MuAsYITRHhDHJoQckXIZbRjwR7jxpqER1uVgXBNxLg1sWMkRkrdRLi/RvVDupnfUQluLxELvOmQhzyii0ePyTHbskXWK9SwrXLjbaomo0qGX3HEnQ00Fokbp6Xz9XVTS4royDHxOxTSVif6nNqQAB9oW4gPSoBbQVqKhZRXoOCDCszKdGq1rFI3LfKh12DJJUyse97RBj1SR8vRYA4JgpRk83Mt4VkPg7lgdOcRIooRZajoqdyBl3gUictAfJ6rZ2JQzQePACesKzBZcOIWGmNZkSb91KEogyWRor1ozikAEmeo+ZRseLKkW4nOKwUzBFJlrTTrARhPGAiOUn+GstHtulbc0RL4JqQKJyzJM4PWW2V+eqYmrUyBOGUZP9mrr4ue4AXmyXoOzL6kCjqC51vg5isrxcE3gn5i3PZNap1WcNHO9cMbnt3ZRL2VbmiZz9ewv2SvUNZpivEKziKZruCrD0u8JNHFDuJCynLwp9RwQi7+8YxsFDmOa1x6hw1lxHtcvPTSZKAttCCrMRpCNhfez914BLnBNRrbJEWxQa/RdmPjzy1u21+oTPGDbkc0oRSJexGEbPc9aescPsafy8V7wb4gFjAqaaQGm+MAvcv+NAArGnskMMEnWGGMPYMx8y9AQcnkoJpS1mvSnVvd1sKfd6mHQ9NA9UvwaQolcC65NfGboM75gSzpjYuuWl0P28lPLbAim1LW1RYAGNwLWE6JRFkNhdPx9ucmQG8PeCHfcf9urwi93w3/d26hjARKX/41CMGHxtNfvlfx4dUPwQ9UthhIZd2IzfHQ+8V/lbpxQfzD9sScs2XvmJorKiILPVHmLxd0KFxCgzs7ey2+XoZiWggAQ3KbZvHOs5SV3KHXOmD+Tn7KPdS6AQAHuGVMme96rjnE93ulAwYHx5onc8mxw6mEBwJphA7dxpqkRGQBS5qNyhtMafsoc40knRgdS4/FXl2BEzDPMr+K+rA+rlekajUeXhQuMNaqIFgDgFIylxnwpZAIKgvZkOK1gWhCGRJm4veskBztU2QKOoJUItmW3Ier9FzFGgHSeuPzVQbLBNu27NGXKlgNWItZp7vNCZOyImFbJ1AYBQuKoVytt8LxjBNA155Mh4THHxLOZG1m867EVTiuCkuJhBu4gAMkqxo52d8iLumDdUsZahgUPxqKzelNO7odvIkEW9E1eG8tSArCKYV7n3LcizBTlCAjVhDFKJOY9sgjq8Q2aJKco3IMR4qeSLW7W+jFC+TiSd/gJEO7sRgMDFtK1jkCLLOa9qW605cqhdZp8XSIV9eCoqBVa52TOuKEtavzQZ9pc+nSjvtZrUi0HZ6djgfrxKFiCIZo0P1z3LFLDgm1xhu3PEJmIMGiYcJHOMA5PAnNkSXmjJ1hSvMWCgQSVLxHgmp2NTns+PpvJqrmNofL1dbjXoUB7qhiHKEJW+msj4EYME8JNoGy6A/FWQBPhw44kmtyGmz9g7/xU0Nl28mumMkpwSONY2zB3E7grnj7Tol7nMg0MyDG3+QYLnPBeT8XtDy0CquL+T6QrDlpbYIbOA7hBgHWE5aCyCRyWa+xS5gjJYVMCQYammsOntSlCWay6zdME81dc42KSdY5y9NmgJcx+DIV6VH4lYuc/YirvzkkOG01LMrFoB2zkQftUWA7FtW4xaOOKiKj994niKYYdmo06Bzll7mJfBnhlQ3nwpgCEZJWaufBbGcqzTQ6Y6hlwIFxfUufrJ+w7cV8pZxuBLMZlM3iddJF6eVvulPTllQW9gt89cvIj65QbvRgpfz0DRirrkIucdTO2lVfRF7g4X0ka10HZGWpPfwIOdmGgE1S6ftebUDx5f9ANqOxp9Ujgno0iNn1ZGxu0XuOW4KSY025u5EwWwEhWITTEmN4hHCH3VayU51kGmo7YJiIAGmWL8f06RqcbEbY+JPdX9Cc+/ciszKOgoJdhBSAUV04UkbqXezaVWC/M23w9/PMT5fG0v5UJhA+Lu29iLnxLVpQmGRV0bK25MvWjFT2LvOlsx9y4eL3tWgOg/JyEGXwVs2c28tITX7OUv4THPkRzGVKxY7uIt41UdgZPLMMXHp6O0ciJfDFg+cvtbnSYByxTp3zu5I29JWFvWUKGPl7tFGNaQ46M8KvTC+ZyV9aDfS5esVn4Q9vjb6IPPGi/t0cIepxti7e7qzk8p2N1veIcnEreqQqsD0mriOcnkPOlD/YNr1eTGVbJEt2mRcz2zekquJYpyzlPpYBH2GHtlqUs9gHMkBtheU6xj0L22IWJgXlrSonThbnelhtZp/6mDdjaKe6Ato73gcAzqE0+zV7xXTX06/rYg++eJnQGedMn0rbl0Ilio/l7m6fI8WCLD3WtlKV5sroWC3azoR1dcV9FXa2p+6DE+KYyVwz2jw+Q/iwpfvLhLe4lz0aGDAeHWGndopMndUaJGroD6q6avZj3UZDS3usf++xc8t6qUa7f0usjmac09CoddIzWMeZGjut5E5owKtu7I9ANxp6bsZuBnPo1SzEDYw9fwPed7eE7m4CMxvywCJA2UJuZZ1LcbFVY6fCpCsszO2oScTfGNKPZDvPRchclog70n5A1Ahbgs+EJ2w3ShQe62LW2dF61QLwim3i4BDSiAMN967SB5t0wDIibxbQBaPakhXYW9mxadvSYTy7xa96Syjb9zpS2o3u1FhyRY0jbtvALDRf8PVBzX6y2jR2mANH6pFDcZ5B1js0UU7HZSIjTlgV68VvG+g4QlQW2yln5dX/YtNGLf3UyscqrE5izZrsBd2zbsR+l3STaManwTQCoBUAAaow1owMTCwOMQqsEGNNMhHnX3SDgouj3ykUmm21tYMrIGzSn2T4Cta2eO31PYBHqd1vNvZLWGwALjDvIKH71Nf4h3YeooWgAFojEwJQs2qOgd/OjE/1+lyVF32wMUD9oXP30OO6jVGkAkxO/hgdjfwRirXBI6WN8Sr959pu9hye+HR32v5B9mp/P/MaCr9926ZlUe+rq0YIhybEhaTfC3j3/6yZs6FtjyIlDsE3xtzZU3qcE5RVhRnAFw1/HOlxO+OTjQH8cFhNkKgdj0kca/yPT7MlLu5ctvs+vugp3upgITeJfaQjYrzoKOrttpt8B5NV/D10/vtvvpDZGwODb1OlGYsVpy2/H+fkRjs9yQ8fofqteOYlIVnSRdtQ2w45oL4Sj1BjDOCFfpN9kTXzLnSGLgEmaRaIHJOxQg8rqBEae7jxilULGas04xCyim0Ez3s8QFPnoT/5eJ80fOkxMo4x4Ub88j8dMtnzY7K0/Sp5NfoZl+8r3UCDtVwHy6npIRG66fsLOcUcYlf3NXam8FRMR/Gz/B78GvnIaRInsOdhf3q3l6plBhwGX7oxuukptUT8+nQxepKhpIVAgB8irIcIFmLXQOtGwc/3s/H5uF5A8CNAIVzD8Z6zjVMInbwf6R9XPhGBtIpeWG3QFknAlMHyp6GFWhuU5bn2W/N+lPWW93ALNdLMLatce7yhzvmUrXKx8HP84ev/xiQMF1QdOTx/2OGQaeeo04lTDsMfwa/G0PoQjPm8yb/02lVStMb6mvFKgMtqPDCJvlhoLDzw0Gs5iwOHYJkfc+YMxOuZT6TUGrojzfICi2wBQtm2ibI+8crXFHh4NPBzf8+z1m8OayCghSBAKkEVFtgYScbas3lRi/lRScMOnS9/lwwV91YA8+60k+V2udOPqvAk40/RZ5jJsNyUzVFqWIZi9vl65qOR5PJudfftUsfWct7zOjDFcR96TObAHzuxadw3f+QPFDvw+lXD20z4XPgGptc9lR6BxeOFwwdCLvwXHuIOeKaoRxn8b5BIuBPH0GQvS+45lYBd/GxrFwyrPp24jW0L29Y80/8iINUw3iydUzpYf/UsW4jYfZA+c2bnu+u9Y/eD1iSYY+WJB0YUn3Tpes9dh5LXCisu4UC0y3V7PtvwKYP4XlCTGvyJuxX/nbUJKmNIhsuLEnnehuzeKSLUfgzTpc+cXrVI7EqG15kO671b1YS7gTUh0Qfezu4WN2Gjkl0PP3evTLZ2i+uTz9vn5DNa8Z2tmqFSdmlUTa5liNzWYBT5KkWu1mR6KYHiFtPskABntqUV6kQLhEKZ8Y+u/CDtdKT7Jt+nTTi3iLWHnKWVa9fGnpSO10CCyxVa0tO2kA8ZxA1toVnhar1Ryf3WCK4GNA8OfR9eC7+c5TN4/oyg4qwmKc0/c7lBnoDfRR0Bq7XXZEWgSXjhSMLSB5zyfohop69899E8B5NXLixkYvAuqS7InhfEn2y1Zkw7DZfGdd4ZvwovZSG7nQYBkB8P6iNhOCzbNNU2d3ptcru+xo1ee6t5lRw8qHLKZD4DJuDRF5KqYjC/P2bsnlyvnPbh5PLV4NffKbFRUSEhmIMIIUcLbzdqXEobhpHUhbK0zrsq7h9zs4qWYI1tnklVa3ou6hENH+s6n7mOHoTm8rr0FyZkxC0MzkS09S6BTjymxI1HwGPd89ZRwUwCavaImUBUenwifUszC1crxn/G1BYdR3v67G3ZfC09PrgX07az1w79Ic49NNrCeDiia0PUEr1FkZFzVdkKYEZx1XH/GakyXObqNvwrwPqBjg5NS0zo2n0WjcBUN+sSOq9Ab9xjQjnudxuP/Gbf/p+ndOq9yLNZU+qBT//Pruwl/6puW3828q/2U/0akP/+63nTlQSwkvWe4p9NUrHLi/HBRojSx8+hF0zHlYc2jxIiGBLPN0v7Rb13f2tRRx4VbBYB+DTiaZtsEp0meYdoQTY8uBLY6FSMtisbSiPWjYmQW4h14TF3+5Rat2z7LO+sYcw9i4J636WrNn89jmvNazSxehJFp4g4Lzyerq55EC6KrdfE/9Qk8Rn8YqNNFp8Z54zyxZiP53IC6lhxm508zZV73kgx4TWmrh8PT7PeCxkCCojRZBrXXIcML6b9iFNYnQvnp59+gphqssYXovMO4Fdtycs9MsmyWPth0Jr1y9ueYxoJ2EzfDQrCQiEBAfUrMAa9p6yQsIjCtoxQfvc82101HF9R2YubgaKpMVgtOApL022O50qpDh4cGHEqiAPIfjLKe+UZSZ/YofDdbz5PxzaApj1SsXtBYlx1d7q3vxdgpE8KLzIkbb3W2wy41dAYV8+CpRvjZ5tXP0aooCz1jfIW1TqRZkn+jGFno9U/5/4xbac1ylTEd0s0gLfDWc1MH3S402bSr3k5Rp5odK03lUVom9pZ5Y5T1LAAKSPGYF+vf4EJxPS80Sjl/ssKsuRObXEFtD9C3+QJw5fNux8fQKvjjicFkwp/0tDli/3Rl0qu5kPsEQknxeRxSq8M2Jt8d67S3qNZnGYEvbrs5kZERPn54KPwlx46+tL9aO0YnCR9KIZQRdgld4cXGhGl8AlAxOaBDl6+yJ1prgM2OfEkuD5Fr7Fm+O9wsy0xee9bOoayhLySMD3G9t+Voado9bFsn8GL9612orucFRmwyQVxy+ctIM38oCrkC3upqaxTk0T2bLJuhD30o6fPDehxUzDrwPErWahqRlzts0FUI+elK2NYeK3RAzoAzrtDcs8rdyW0a5BdtQ3PTVFgIf1SZXA5yuzcJo7MIp0z456xg6Zzq7K3CpRFJ/iFpCfw0N8GfaKtCxiSXniGJsbb2vlFglDi7AsQHzdXpQyuCQrH6mULRzQN0NwliclgRUxB5B/WiQJMEK8ZUEuJEXPcsZ6FhKhibHFGSOhd82VR8pqKJTjZGsNDweD96PuKaqfRkRQPvjrNZpDMqEQk3D+R/i4/QnrIbs1GY83TcO8JykIY+ApawOoReU4Yk/c4q8AvCwO/Uvb44F90fII+0rzPkT55FWwFrf0Sc64VTHgBP1zpAR2FvEVapb5sb4sh1HG+UoRw5oDxr2+vpvyuZLw9Hm0DgmMFH6GvhYuIRDo10DYb38ZZVFzWgG/VsBkWXLZU2bAjNQGxOVp602e0OdaQ5VY2kcZvtl3vjt0yuIIS6jeMV3+HMGQP38zG19xWNljpPomXqKseGpXsiMzsNyxuWWNUdPavOYN3fpR5cqWchGSbC5+Z+ObsNTXEOT4P61Fw8sKcQRQwjdvyu+5mCp5OJ5V5ZESZ36l6vzUUPBOYrFOp/PZ4vZO2NiHc7dMp9E9gS5Uh4NO64G3Qvejve5Gy7IIu8K/z/IXu6glL6XKu+saD4Mt/jgtyMd+7CvzQWldG7myLGMJ8TVUK0h5Lx0cGafvFdl4PDfQ7VkrbhTFG/OxMScnRmadXB7Po/GL+ODkgj2LVs35e9VHTpbrIYw9wgbEVuJUb83OgiIwtc3+SZpF9Ynbf1L3niVxIfyAltwiI0Rx13qN/Xr1YUl641H5f5FmV+V0cN1Vthi1CyI8g1l4qY/vH0ZTnWu1poTGZ7vJGapa6ubE1JoVBq4YocU1+eN/tC3Da8VslYI5nsqTLuFB7AbSuPpOyzz4LCa+oAslYWX2onZg66X6i3xpXja25xNahWx0rYPFKT6+siIyF3MSk6sMkjxrVXYJi6vhKxFaVRgUGHhEiiK310m7sq30AJrnW712CD/WhW39KVt0oUR5t+BT8ITUan1EdXeOsFudbWgU9MHvBD1DjUb7nmUtsolu3bM1fvVEBSnQvgxfrVwymjjesfolTDNAsaajOobQH6WvvLloOHBib0Gu5Aa8iaMPJGYR+xFJaXYZBnt6YS68uxGQ1E+MSEFzlNGnEPipqGBqLl6T75lrSNGUIctdIt2TLWOZIcnu/nErr3R5ubanxWYJ1KI07O95ZbVW/Cy08oRRDfEuPL/a/T3jGEwtyGjioII9TUtQ5ebEBwKOHgsqJ3kbDaSQbyEExaNKEgTxJHc8c7QFruhTjR7BpCiPERisblwV1d5Ug51UFuTnDb1YCMCY6bSs71yfZaiQpJQQRz0gVU2rx7aJiWq2Hjda/teSYeMjNco86IhIeGJsGxZeN8fz+fs6YltKcwPqx7dQGjL3TuyubuiE5yf3PWY9NnhYby2qHotgA+0atGwxpcUvQMt4i8Gu2khwCfTAjGOMDKxLDCNsHIyrYTokMBl1M0nU+5an3yZ0DY2UyNdT+tOVRcKGmc8iuH1M3U4te7s55nGyQ28V8G9Pu29zXg/8136NcMsDKxqZyovvvL0HJ3J0RHFVyuCvQsEQqBFOunCTDhLZL10yRryLjJy7YqZGxyyRlSNsbWDpega0lBJLngxNxLAy56WLEfmZY/9z3xsbH8HqrtJ+BbhxQPxuTPbsJY1/MqXrZV+cXQSrUrZ8dYcRIKaipWmf86uhAqQlcW9KxTzHq9i1wQcxv4vzAqNmSHnx5/1DoJBcj3dQDZGaPBWAijndSlR3F+8n/O2XlYdg9dJWJKoWAP+BGq4yfNen5Hyp4L+oc4dMn5gGVHnh573L4D69WLaNrsr+TVmR2PcS6p6etxoEfr0uVxJoRBFDHUgA7tV1dsZwtj2QxssRXTJWWY3OptFK/L7JIxcu5eVqj3a+SQEg08ywg+/o3mJpzXfvdLrco3jogdhv8PK+dOMLrsEBZtGTfichml04nWajQD7M6py94R/tRsefr0qj8KslVr/+E3S3DX1UFPZ3q6bjpf+FWYn9aFZLZOBRTvrT+q/FeHiZ7yPy23JTJMe8n1RJTPjHbzSnF1dMXKqQUdh3020V+PnvYXVkFLNDTd4FzuPFd/w1nCzRrAA6RUd1xGKeGUdBZ3wAqsONku6dDngBMXO3MON9y79uj2xbXi42j+g2daP67arkk2g1pt5uFDu5uDLGHFh+M4upgMjs6sZWN1DcqE5Py1aHpVKDrBP0HBar8I3FQobGrwS1IVjJCu/L5TLMfahxhZ0D7jHD+7tThUaBFgjZpB6/x1Gthrhe3t8zjDlIn+bRzg/mln6b4KTZsQtbqtkrda1c6dHkR6OG0gxMO7c2tRlzX16F6I6m3NHUPX/5GWpghPXJIXFhbfIKK1eIkuZdpZMNDdUUHU/5GXNbOXHQF//HFltK5zvgFcA+ZEu2+RZuqwpPCSbnCl1HZB2mPfkeSpnj2q7nLKoDkY6Z3D2XOtPaOEefF6bUpz2sXoAv/uH/wc7ypGQkc3g5Gb+5BC0Ck2q56ulucPCHJHsGWjJc7desyljNqgBoZ+VntqIkZGcVsP7lPg4/IyRDBCwogXkApJKkggBqZinJh6BzRy5rSueMV6VZLyfqreGOu/ER2u028XXu6d3BShiYDt7qCkB7YS0dprnvRrgU1vRvWLdCW1V7i4CdlX61SbzVIQYHxc776ZRPvcO5GYpjVItlPEM05bzVll7Md7PvF33OUj5/YW5YDT/5/xhD+m3WAk36DdSIz+doWgiQKMHTvJ3nVSns88NhIGkHiNrVmks846OUV17b5SH2k38jqE2pIkOnNWIZis+UDGaZda1K12jzfpzM/Hxf99Zr6mVxiV/Vd9yG2/d0JMYlxrNd4L5V4Q32Ccnqq1bN5RXetYoUmoJQvnLnC4R1IvRKI0/3+by0VVHf4RW2nGM5m00TKfhKp7jdRcAwMfwgbG2YNR7/QMGWaiADmtcFcI4KAdAQT/F+mmGXcy2emMhdjaHq7tYcuxbdnd24fN4qz7Ee1Hay2jLS74NbdCY5YOQ7Zd14ujHgzPeZJfxBMdjdBGWFenRxckHY5AaZ1zj90XNbyly7jQevKj+ixxGPUaLILrHaj9snwRVIL5fDAAOICPoMbvuKGLukFw8pxod4Y0U0HCw0B4CmBmLTHFi9CYulTELxf9c72K3s252JmYRIwcQfCcM9MTetsT4vJlzyhE7ULTqj2lOIxT3u46hh1gD3dPxCEodoqUx4gyIRjFVNGTyXKmK8rCprYekyjLcNmljQ9zQjvJg4ciwLESsrRMphcAXefgJeCMTF5S+YSI1RLHO3UZF9pMfqB8zQsaxfjrB4PUcOgbEMfn/WHDy9uUo7f0qzG197V0DdY5x7Ag/K7cvY3dffU1OAwRv9IyF+++nxpBTmfPrYxE0NLALfEJ3xNOQ674M/+QcA2aLZbEWcVpFgUvRXkTAkP9BTYU9ywuthu4zg8kB1Ie7RGBGe7snq0UvUNeIsMz07GWIjD7NlOD5OulFTiItIJ5x+rH2/NlXjK3nT1mHT5WyDtip5x4tjTDFmNQCdb7p7sHPeBUrYD87+dvBwsThd2QjEqU/qGbTo6oJaO9R54Qr/M1c1TYnWpRJoP+IuNF0yKMRN+7Zhb8qIvkkq7zAjYOIbRQBfCDIghvspflWIJN4gzaba8ApjBUY8E/mon6AP39KYtXcSZCJAmPNagggCCTnbVrTR1LqyCG/3bjimhr/wicAO9J9Klt7RamYf2jSbaPYFgENE0bUYPme7zqN+0OdsV9iqr3jPdmhEQ6CQOWoHBSoHfpu2t2cJw3wp/g5WgX5qlb6cHJ2JZhzJRgIMVRML7b7XnLZSEqmIBpdjl408483aHGJpE7YVtv/AB4f4+hlG+QgyThcGlgFcun+1q7ButgaSkQ3sCoHls4s2fekZa9JQykQc1XeGp3Ocof1GjBcojO3mnAI7vscXa3xc79ZUHUh7uV/luoUPQPeYpSSpOLQCS/bjapcWkuPJm3zL27C/paIa6UxbFz9qo/vtwDFI50Sj06tltotHV5w/G6o08Iz3ldOtSiTQf9RCYLZh0yOKc+SDmNDOe7v5q2Whqk7VzOinR5E32lQ7bAiu2sJ4B8b4ow+F888InqiCCwQ2Vq7UVWDx5ocZ0abeUfCfwtPQgXsLmyyYI3+LLfbDgc/zmy3ituzdBIbFyIh/GpQIK9ce7bdVvWfBQvpe8R1DJMGBLs97SmXprl2A4htMWIbrY1GD/Eexp5RtQdph4HVCDurQjxY1LCx8ZwW4pbViq2a2t6IOkt+ZddHqydwaSMpu8CK6dPsMK3WknaPyHefKwPDd1OotIPrM9GeWFQkCj4uc3tvCH2Fx7+AG6I/UmA31eb0Cf0OgD7xkEQ73NojYDye3ZBhJQoWTiZHu+kXjPhsjLdD6fP0g+NSG31sY3DBh2BveMaL1l30SCntgt20OMER1kOgcKPc1SmDMKeRCseGxeOY+FnnaLikxh+hfvhqHqqKHlgE5QoWJDG/EeD+EaXB5ueP87/2QdsqimsjMDlSqU83h84mm8fBQovik6LabBhuUp3RO85dHZmB4/UpKjip4Wl+foEGBDfq2X8NBYRpW1Ot1uh0ZrpKhmP3rt87maoUVHNT31WX913QkPHXZ/aL1ablK+hNRQrZmdSETmGnlAR2k21ZHSxCsmU+AQ1A3atHaTcCXJ9CpP9JfldfGj2pUkHjXI7jdXJsOx/45fLh2SrCjKddS7LnlKf8Qb57ZS5KPuHSuKnMX94JL8d0mviEDK/083svRcJHpiJQi6qAqyE1496oarTi4hS91I1us7EbbpX135Czz5+gnkWWe2nvW+fnxay5onnn4zss/eo5zyLYP//LUsFD340LVLd2kkQHzvOPFfD9bvbl7oVr/dopergkvjsXep5GHN/wAk/v62rfvs3zeQTnRVOXopL5yfWaAhlICgWnkM4n0COJz024Vn3NtopCDkMeZ5liRUs5JgwruNWeyOwhG6SZtvV6KOIkzHzc6F5UIZcRmjNzGiz5Zl8oqeEk5cIPH5SjaYwV90CA8+NO59IjosGPv037RxAnTiXFgRQbmpb2RAACrhlQJo2bEO2JlP7UwrVfiFrg02+drw+7jggNXKdtV+SK6wtxbpfE/Aj0Yv4ycJdwiusgDXt6mCVnBD7SZjm03se1CBopuOU+uH1h1VbAmsrvn8dgPmh6XghmhCEeqkJ/6AMdFWA4fXmwDqSuq5PTJC6Y0mq9X4OLj0EH4R9r3N4eDEIbEtDgPy+mE+GZan9HrDR9QhCtTGwsUJdR1eGdDgL88HEY+1ZHPb4mRNqTdQb2pPv1wedzPZj7AQWxfZTep28S4DK4xEod6/+1fPbaZnGEEZjRFZ26stp6cekFPhMO+Ji4tupRSIfzXhdfPlsB8J2qNaoVtWBXDUHJww3fWoCTrQAg7620NGDaluWB50K6OUPAsXmJRqVm/j33WfhKtlQeZYlH4xGrQ1bB00bYIDdR/nHLx/nL29Pt8zXhuO6kfnRqbrZjvIenwGn2nNOIU4KzaJhfq91npOAAJf5BHMiS54y1KNAMfRuhHMmaUI/S83C67rQf6MuzLg40f6S+lyUtZOtR4J6LUqW7lJsgfNRwzSpixFwyKHwHL/4z0iUxqytXWBuXkJiQZFrpG1lbIw2UgflFlVQlJCYm0/2qrZjJdfZR3vk5cVXLkewq46jaofohLpHdzgr5OVHelYKrHgM+PhnC1B5MKmTa5d1qHR8ZW1wgMHh8Cb3cLgpHO3mzXyzb43aVfjCtthWPWpOBR7p3Zi7/2grS4gb0dQCd/IhY3E6LKe8DI8k/UhcfSTSu6t4xueadfXrhiXAiMPRYVXKKFtxaJ/XLzwr6cCvcHOI4WdmUoGN+rdp/lErkP6BLDqTOBAu/mb7xOyljSGQb6QmKa3TBS2OckfNp1DstO4P3YpgGdUhzyzc++60vbIdi8vCsreLajNGLeAlR8r5IqOn9v3ll9iXWgwt7TP45V2hXK9BL77cYis1K26UbZZbQLR7qPP+wkRNKnSuKSkrfMzcTWXa9xIn4CEWPCYjQkPBILLfGQcYha1eGpQ5F1nlgN2OrADpOEUb7iJTP9gO1GSbKFzf2P79lQJ9vx9cg5G0Rc7q01ltRLT7YM4kuteRle4rDW7RRmzJBLel6PXn6HBhWfnuWWCq9wgZ4zkmn4iyCPMSfcleYI2SfXKVR2OMWAUkN/1cUfy5r5HaiW/d9Ml8mg3oqeMO/i6QGJrv1PQzsbfNOTfTIgeM/8Xq3WyepyZ8yH987DH/DpBvI3dzx00gK2KydMV2sj6fPYHt51wQsCrt8r38HdbvHi9yT9mquFFZeOEZ+//Mn9pq63Ft1J4lVem4j0yyJu3PFfAE8SsjpQEZFGu5UZSfQ4w2oyHDPZOV6VMA5I3wJ6Gu4qV2bpHxJ63OvhOSEw1GllqF3JalFm4LqBbUzjUdSS8LLX90yMXyzvLOQnFhh1ZIqJJYLlbzy7LGYsLCYqgYDA5Lj8fhcXgqHYPGYABjL2iu2120BgVCoqguD1ycgxGwjUzgoXPd271iuVgHGTqWE8SeJyjmgYGWniXbc26oioPSH+8WP877P9nCuTnbEMw3TVRrbKt2/zeu8LrpdbNCQLnTySycytjLTkDxB+7+6Y0sWLatUogyHVYcfHILymRymT54ByFANNbkL7dINba3eP9tkIAIjhPj8YGHORxjmFHP5uAtpY8TkG/BNXaAPtyKDKYTvEcnnAWY2hjXHNWGaFs2PvzP2nht3xSlHeVuoeLttmEhVlfyEpOLQ5PztnuezOz79aA3kRdJb9uZmhAXXcnA2sqQMa2dv58khTsMxK5z7SNtcATHcIfEhxthUZlQDCIwOY4V8DrVv68AhZBQI0PdbSiscVRmlAJJSMuVMX1DvZCC8PceqSXMJDo6xNIoIkvDHZpA4/oAJkGGKC2rEVn+8U1+0KxgZysBNc1+Ew8gkUqH1Agp/nFN/prydDtBEstbIQ5UIFsu90NrvK+31EyPa5xooZzOinnrP3JtrcCoIceblSSwq2YX1OyGAdnzobKMkMyQhsaMkN4E9GmvjtNsjRjzAycfm0KtrzZarVwlTQM63hSajC+asBc1MM0b3M+ZxqENhpv5xQrub8PyAhPLQW3AvOqi46IBgJrbEJAAXn9MaOG8qsxvVnWuzgxzdEY8TBdVndm6CZsb6gBycHM1HrHxeq+JcRp6G8DxV0M1l+k1UaYH/7W343OK6E4mHqlZ7iHc5trFpn3kVyBydfnyg+h9ee+Sn2rMmmhz8QM1MNAYd24hgfjOtoR3iEYlEAuSjaXTMGFpU1hGrHHllLOoCA7Zvgf+wBl+zWNUKpFQ6KxINWLt7Fym0ibwdO0xmKi0sUKnozJbkn/PK69XBj+/UYqwvmHXlu2dDDWtj2YWhktptJPLJuFJlNplwK0Kx21P0dboDX5HCBCONfub9X6OFu9fDBJHQiAofw0YbvSLOEGsb5NjYyUOGlBwGs3cZXOsnaz/nOh/DfiHJtuCSlWye/qIiET/fRLPj7ahcZ3LiCTLAXgkIcbD20ScFWxCdXfKtc/oZEHi4KvzvHrSGu3MwyPrPPyR3WNt+oZGffxG4ubQgYpMkx8hdcfLF9TB8lu8pYXU01mA5VONXwYWTeWMvbPv7cvKGnRWsAydz+LmYpCxTfBBHYTxCsbAByRgh6aEmAdpFjcnJa9QSj/nlidyj0z0XT1ELZoc6xPHx6ILh6iC4CiJtKpvLi7x4unoIWbDqT2mSAe0T/iFFy42THFYEDnFd++9ZnAPjdPZtJ+Mj0B3BjqVmKqvAwvDUkoSk2LSidHs7IQG6wDGrRaAYru3Hf/y7ZnTWA2kaakUxfDpPgpy32Qp4FW0MqgptKXufmIhy6PYKtrrTb1FP3P9+yhtT/w6L6780h8sn6FwWzbkLmQ0FhS7FjQGiF1qS02bYU+Nk/ES/wYc2ZUVH1WN6/DIulR+NfusyyCOnFAWdpp/E7qTWOFqgtZ6nJzmlBY8+C4Ajd2nW7rc2sSJhybFWLGKAnB+mAmGmdgrECmBft65TdlLlGKoium703phU7ohO0z1zsC5FuDVOe4UmzOTOn8D/eipKLPPv8q9K5xJ030WUH244uBnngEz6NVyzb6i9ybHTpw56+q2ev7oCSM9DwO0bzEvFuTQQ7i1PVQQ4ZtsaqBZGesCc966JcBu803n3UJTJD2QKqo7vNRQk5iYkKhwXjbi7y3L9LDzpemlNjHsO/ToilSGGBdOIMpkXb3G6mDtiko/in95hWn4lnCU2tHkAqsiq6RjUaQSK5iRnudTRz7TILefbddhyBqW8eQxNCq1II9CpdGKYgw5V/CC8Pg0CTmSL6PT+RItPV0pQL0qD11U9Tqu4hvwquvV7kJAthcbfLeKXEcLR70yvBp0oBUuH3aBXwG5bU96ZngWvPz7pkGll3T4p1w41Vlvs9SMULs7TzJzVJU6gZJcHjL37bu3RKfFNxTEq0Iqp7+rvgw037LwnfObVI2/AkeZOSeZqtYTwI4TTJkqdANYw5RmMvdXxXEhs/mG0j2XpM/CZE/CJJMye0jetxRoD1lJV02/FxaaIaooUBXxweWFhermKpaOxJSghEBovQM7JMwxkRWUiCCJUmNwBjYvKR71bq71Xp71IG3J2zDnCEUGDG1eaw62FX1AORMV6TCM2XlzHdsIbVGDiKPzaruM/22+OJlO84owJ3yj/iDQ2LulFSWbQanaflWDE064pAIxbB6xj/g10BctuShpMmq/NC5IRAG1c7IYW+UcZqYwD4ah7Vx7PDXY1xntpgK07fXwIi+zww07qC+CZ07tWZM8Q8meoKRA862GE0hflQC9p9lsXXb4MWY+e3QEu4P+UevJls4ZlEzVfOtOSZUkpDS8oHa27OI3XL8Aa/8nkG9ZSWNLOfwC0Y2zRfQmzkVF48wuXJpbSHJcp99hixIZiuPXHYXTzjEt2lMmz+5OFLeHyAfkg6lYemAtHWeCNo6qpMeFSCLh8/4dpWiqTPS/RkF9YaZEJtODVHtq0P9RFYKk9L2gemJe/ncYcUaHXJWccuBUc/ZI7aPIMO18i/LVnrEq8M55OuPXx0E9t2jxe/VOt1FvaiyV3lIT6oVwz6TWmApTtPaY1dXUOko1CEXklPhRF4EffzltKRyp9TFILZ9fq/BNU3tRRVmKGWnlWB4wNVgnzGMcrZh19tdDwCYKDdgSd4kA9twRYO39jG3EClZYe/nGZPYy7WagA9uyFdv6LChWLYjaozU1OGQkZm9Vo1X0oW5ItiHDc7RPkjkbOj3qROuLbLqeZD/YnZt94EpOfUEr3GK74Jqf503hUReE5u/roO7ua7fExSzh0ZVMeV7VbTxSaxa+KxjarZ8FHXyutSOKZNtm1aqR0aY56Bzl6nD4J4iFbN8duB17Vjc52gvjIlzV9bIm2HlOtNl/aXqjLqIAp6Klu7Qi9C/1Kn/pab9yW1KSImqnQyemLi6of4prq3nBvd9978g/FOYcy+cjk3GRj9zDPKB3ql0p/GfP4eyONdy/1plAAGUzAE55iARimT2KldJ+gVHmaBE5/dD57gg0bB6eWht+t3b821JAFCBO3hYRDDLzlqHu6Ozuupia2iUWLUBaQMxcCJ8zKrPquIqUgcXa8E3bbTYOtBTgVXRQ4T84nc3TXGHtmttIgVzYfCa5nOjRAmPwiuuz60QfawQEH7Eua3a3olCtGFRFxgGmbcxGXvfE8NWFpk5ou87Uh3WOO5JFTTBplmnrC589GBTmGUHbB9AO+OzDiKOtE3y2R0yMjvu9yR7F47xdzhdBZ9rDeJHPMXD5SDtrp2VwRRDYPKxutWNj75O0MB+Ze/LGZtqWYk/BpJeVs8VEcil3s9cD/6wZRNz8FEVJtGSoCvmaPbH/skyU8YxaBaQxUpoCmYRkVDH2EBNOMf6Ej76OZsYeY8IRGc+oSxh9DWMWAD5lB71M3MOEn6iPX7qC056Fdy0++nP5cEeV7P8d7U0Y07TE/ivtZTpRx9uYf1diyqL3YSru9w0zOLt3alLL/jmQHRhMcj/XJbzuVpQumiAZh/fE3oWMl1GMuSeNyzIlJCM713/V/31gYcJ/2h0VC8W15F1iwns18R/6OofcXcdyvC6Dkd1CcivJRBnPqJvSGEnGIQX5hyT8c0I+o88gCS/2xH4ixp/zUT/xhrGfwYRzmPOLgOgfcH34Mfjp/vOslzdznnyLlv8P03KsR/z7DNB/mo3Xbv7h7MBAAOKP01I0/EgtGlDb+QbjTeqWJue0VPtxCpBV5oCHiK4avqmkeY7kNxOIiC3NlS06hbX4LynZr4l5IQ/lgp9++bVXCVZjjrL4zJriH6Cx3N80StWkOW4v2XvM+tUnV/uql+Xt6fceSAiinApIF6NgYBgQjbztjsVikgaU3tb8DVFi3ujjUK0tdXdz+C/Jkf9FD4juvJkWEZUsfwMYLRXGwxp4oZlmpqHefphLhoJgKASILC9ICaFQtyaw/J4CzNKYiRGN1Sy/kQ73I3EdTtLL5l7Rvi81TVY11yyDsxjMuaDp2fX34AKG8FlQEDSBdqip5tbr4X+D+XqvYITvBDp/oAtaCeCPTgFJgJ4MUHsD6J8t2+0VwAxcgLcooU+DL7p64x312Nbbx5cHhDSbHU4wy0S5Q1itkgME0+y8ExcuZqMlAqrRQqCj7ZDkJW29ONKaYLsg2hWyJV3jklAnasHYEgOhg5QM+C/pZqIK9vuvnhoeqn3cUQnErMOHKG2W57QvnYdqBmIzIxpmwbi1QDMrAPz17ZNaWgjpeOJpdAN80ABJSceaC/tS8I7ytsLH3AcfA3r7crvgKhi+h21bybuzasLGGPU/uUtFDwHado3T/hAzvyUUiI+OJseSTw80MdvQ+XwbYM/DYqt82GKC3jYFNwxAw5LvtpX1tm3N8TbyZ1W2EZQbabwz0O2IyAG4FWSyc4BhtEMPuIHdVm2x3ArcQ9dZvzE4VGkVIGvmcb8h9y4mWDy/dYZvaaQiZOKjIic1LA0nhZl4yj9pJwscnFhncVVOXgELowTuybktaocBN+xa0LuUDzkSHRjJiC2obyDAfYVPcAi2jDM44rtJpRjXjKaGyp34olA/BFWiTLEajrWMYIRuCJiNCSXcl8XEuxrQoyuFTB9BbY1HDJV8vQDlU6x9FgWJoN95zJt4LRqw6Fv97sp6J6IdEnoEkia+LJ68UekUORBlEnJ7zKpyupRhRoteiYIuFbmwo50oF9SGbQwDh5bzLlY9r93ZZBsVfFbxjQVPRCRrVAgdeGRsJk2zuy22mITSirW/WrYLxrwXAPFwEyN37fEuhPWu4gLtMOodZ4OuHSvE2zx1Wn+yRTegROCuNP6Txl8b5dVL9xP8hfJs9XziRtQfdqdQ7pLeA6oz/etrgglw7ot42QPUq3cpnHt6ScsFqH4z3zr/MOZHID6xOw9xNx2yTxei+GGkyLcACXkTmqQwU7oLwQQT9+Y1mtgQ9RKBYeYk3+X7KpLqOU0A+gMnW8q3go6JHsIaBUPWkThz64zPj1RRQQ3RHKRevVkcTeZWq+SMv3qsVCr5VxpJUEQ5poO/XL1uQ0kwH33ULDX3qN49Njx5JUBy/soRFIr1P1Pwoynbq+vpQPJBK8JjJ/tTp6RBpAPYweco7PJc0gycY0gGpEY3Q31dy8FwoqKky/TY8YtjpChqoumATa426RikPQYnpOanQ6C0ZBJ96RPUQ1HWx58eJfirCOOL5dJx8tMfcNTFI/7kPuN80CKJpcNzwlCYdaMH3Zrw5pvdZTLmF0OqVERIn9SEIFo1lXkshEwNHDP5OYo++bS3hf3LD1C3Gx6vyYp9OMz5G8Pb7s/uL+7/Lg71exxYeNBDvIqAIeCKy1TaBiIzVU8yA+y3ASSmPIOEiEKnUtbaQge2JQ8UCFeqpfkqyjc3U4eMGlMyZMx2kB7cSD9bBxsjicCagmQcJAkjlqxmJfDO8O0WipAEcfSkS0L5yGucEhLQEdQ9Z4ZqOR4yLoDDeAyi6cZ5YirzgP3H6gal0gHxuHMey5e1VDXNdOuzAllj9zrNlO6Ogt97XArvtcNEvXmM+Pxo+IVRM0kC549fNCRWy4Fzmgfx9tOBV0OojsuQniyv2wHSQXNQjoW9xgdSJf3POWsMluLa7xX+SuHh0ssRHpTn6XzE4vUTQIYVr4ZEXbqJFVmblS/yfM103DicDYsP5HwYqTcHrktAx7Ve8IVlUyw5ElwytyKrYhnJkAmmB1AnAB8kt5TlV10uDDCzJhczzPZSLfiFyQEsyaMyj/lSSaGc5zjq73rNvsb4VYwx/0LIgeEnDDPyBWVsu+H1b5gje6yC0bMzthgmjb2QiQyYGDzUt6/rPsJnqjpHa9k/q9lnbDw0pww6ZiwYNGNEojokgmHSVr+fnaEV6+RkqDf14PhJiCrUzuJ2aL5ImRuUx3A10/zlAnNkZSrEDLOQFTKvIs70WzrYa0SZdwKbGDcnfHxf3msOI4L6dMI7w5isGpqDjA8IDE5Gr11r/ho6yY/hwms8KglHyaeGYnr20fLuTNjHwgOdwF49MRYPwyxvJT0sfgTGFU+V1EhHe2PyvUch9RorUIb9S6kZRbG+FPeaf49x6qlvMH4df4oJLl5UWu0DBBgS+ypUXODMbP8dV7qplYbh/LKh+BKhG+2Duc316aXVWhI6Z+qa1aV9UVP7whR7UFlkHVfLXqS03Uuz3BNUaomG4UugTOvl361H4/qqWNDV3jdovjCl+lYp7fcCv0C4QJlvcR8I0YQmliYBz3e3oqa9HEmzj+jN2Y2y05LB+b6heM9D+GgE+bo2+4qavc55vVKZ7I3YAHZwFAYsZBG+J08nrS2xpKd7IR5ule+zTlR0hoLIlbBLhK4fq7k12S01goV9wI95Y4Uslf7HuULcuvQmd/klW+wa09taCaHxQZDCJqLc6PeTN5bIPcEooFZVN4U5aLV+kHQoZYe0HfH1s1vC0P4yvgGG+qrGdVOAUXoy4mJoZIp2M7DSb5ERiVPqx8Ho90xV3vgM8FRnZi6o+qZUtyGQAAsyU41vK+BcAPWxpL2hxKfaoLZGpbcAhmF+u0Y71snMLg75aKQW7D5VxIFBHHZAsh0Onaz6mVEx6mbDBTV2C6StZNinYp6HDtWTeWjYyjsVlplUJCCl7DbE8ah6Ojt8Xaja/vn6Ktqc4deDCGYrHAkp0pRbRUmREakwaTKzRZywTxvl0WK4WBHrZupNEa8gUgGBLwn/hElxWgWqRJhnT6/25jIFhVFPv9RA267iMsdY3vR5Uu3ayhxEh6riG+Ig60hisYQLvx+CLHpLcl98XZk2RaEUvFajaw9wChZTIRNGsifNAQwkbSQoK8HLAJnhbcpR/k2mkBtTOSmncW0LFOPnVXgRhuop3GPvnmMOqnia8Xu434NO1OuD+TaIXwJgewP1bji+AQ67lQQp5UOyklJdHqyZ4rmLxjV/sBhYJ7vMOomYysrEoH4p0jw6t1YtTHEl76yAIYnjdlJOEG2RdqCzMaIl9EtOlsZwqUR2CUM+xVsBvPqIUD14l0MCnCBisaRba8z5xBN9Jc5rWuL0x4c5JHw/8alXBQPFYNA9pJfMRS0+m2DWNQli85zqqQrXRN/cnvZ3k+WJmzhlfXJxcuGonjI9m+9neGrKXkwiH6C380wzzuRDt6t3JaPEL1j1BScY9WxwnGbT1XmTXEVZMu4AHBVWah/nn+LxgjzwyVZmOtlGgdMyAgS97ZaBcmcUHJefJ+biVWZV6zMcB91rNRHhSgcWXxpezzoe0ydsvV/hpWmfiEUWuLn3+Cynz8WmoBmOfrxIoh41GTFI4HGCyPujFh62JkLwsOlmbUrjPEXL4+a4HPg3rfT9qPyoIOg7eAjc7fyHG5Tg10D0LWoOE8THqcZs6FlBjQwG0ILkNS8TBvt6JkbBwQrJftWUWLQdgT1W4QBm5fi/Lh8d7v2DgJW5drI1WvQAg0nyZtPd5AsWXsb8JXLoc/etSPMH/NcmtzBlB38FT3e/KkHc+URvfAdPvqv1Nzn5XQZc8ooY7Lzr8Fot+c3Bb2Nd0uNPgFv8bnO4xxbqhwkn9tHbMqSQM+kREYbkCnUFT8HuqbhXVElt4yUF3ELR9W7tPcP3wIBjo84MPkTKSOj+xp3K5e+q+T3nSiAUup9f+v7h0evjdTNWyQE9aiIIVYsVBi/zHwnuvjt89u1hB+l8JtK2MODdfWDpCo6/zNVLGsOvg2co0QXic9J15jrj19fj3n16UOnhw88PS5x4p3Dq2fNxNj1ZiRo9X8TbMfSK//itswAeB4Wq6Gu8Cv6rISBbyuWLMETJdu/NtyDp1Iu7E9B3zIPryZYH8t7fNyI4qGd/7wC9rcb9osHSXYXPpVlpPv9XDS5CvZRsIRIorgTJvSXbRdORYBoJyjYp3lF1kJG3C7MEc155jmFykJbH4goD8bDQRz5gXBFcaDweExwqnstSOC1OKXskfA1Lj0qgS+/rRsDTskN5Y5QA3Ag8SVD1VdgDDp99DIokmzDCRl0UzeU9Rb1+J7Uq+ntUvsgxKt00eZS7iN8hC9YafULnFxhkugDkDkRtjzSnz3g1xDFqGsjNKLw9FXAX8jtkOtunGF/RZrDsFaV52Mx49wpiSAg89OtO6sti2S9AlYEcuXIvnw2Fqi4buYrwet4bZtXT3kZctvT4YUX+/WCf0/Feis2eeOKmrEw7Ot/z1hiOT5eExiYAbMVZNz3+Ldkt4F+V6wAAz/THwlDKuve+fuZeVx3+nAVQwRI0sD92wIwh/3MDVp6zm9C5egu+v6olEPh9eqYR2tqcEjeYsLmsm3BmtFLxp3/xUKpfeUkgYss6Z65kJqz691UAVbQX+SOD61jSW8cVucOZkSmvd/NcxdbXOPXCniAChQ5GPPovzzzOALfzkzz0yvIX1Lo6TWj2qu69yLo2P6gw/fVe1zynQd7TNmoa7WE20AbjAh/gMNJ3Nf/N8MvJKSRc+95anYbBIOX0kKTB31b0/ghV8PpUNUJ9B/9LI8O63ZbULTYiq5IU2DfoivWnxAWhT7wtrEfpuit+jvXyekKaqw2F10JWVdIsWwBiLxSo2eCQYw39M4SG6BRW1O61reEkRibSX991ilC8isMgBkYNGijGunADkwwVX/+kzr0XUWno9kj5Seg8D0SsSC/zfswRE1+edI6fU2tMaWXMNINB0QYWVQRnETX8lCbZiZkJBJtlzDU8QsdnB7Qf7UHLUB+UiOajVWjR484k5fkn34bRaAuahkahzmgOGq6FH5VBGrDbo7pznoYOazznrNTCU/Lye/rKRhqKdDhhopVcEmvlLjK7pSo2e61WaGpgYOM3OgEu4wncQgtRD2WsU0a8qCaMAtlixmHDbod7aKPEajNqJ8JsgKwRjOKv3XSduUAEDY1UBBHDRxqInXUhFnWqogAopQHstHCvYF2xnD7uR9+s0dePqNP/rIiZmvVZ8d8NWq908ZdPgC3x7n2mSId1vFj5WOoeUIZ1Eehm8b5yEOMoBU0A6Lm9tyjAWqSiDej28Mg+SfijlrWXy+o12FLu2HUYAD7JPLjMecd0BxIbFXTTCzqLy6eOl0K8BmjrAiAD8DMXm7T5sJ8LAsC3AMWhJihXqR2Ag5dACkm/RwZC4zR1XEkpCsl5jWAl1oShzu5HW1tAAcvL+H70UC+AZ3Yq4/0/RfwLHQPGPYGY+RatksfsyJnkcsCkRtdiZJ1ZdI4pqNg3QQaWUQFmqNFsAuBXNqZAtBlAiOAKvxCDROUQRzCOIQEvsCEJFwwLKTDDC6lojjxkICDvaiNMlDfBFxrmVkIPoHbdpRDBom0hBldWN8TRVIh2MTokEaD8kIKKag+pWKCDIQMDz3atvdcIv0khE2pObMid8cypeNgmd6iWjnEBPFsGbaOyhzYcTWraBYRwoEI21HxrFjP5OkcTs1lFt8CSD2oyqQSbIYLSqRYXe3UsNI9tKBUWAuQAaLpuebuspAcDMMr52kWYmFOKD4rjIbMFWE81z+j4oQzBcr5oUTEJzzwqDdYFM5rPxRBgKA1EyeOnz4xFvVJykS3AgxSEOZyn0izQbIKB3whApc3XGlgmVs2dj3F8MtQ6TmKMpaJYYA7vArmBc+XDHEseRuyOwiElIZYiDWVzIZiCRNsjYaCEcHIFZUuOxLEUZGKXCXhSlWUJEg4yUoJir9ncOPME584fFUkMc/42nr2xD4chWiabeC4zfIy0+MaFByXCxZEzRWYn4FLiJTk1TrkjZo5D2AFPz9+2GbgDylOkGZNeSA3JFiSU3A64xO2UYdbASTI9LXaVZxtLYpnhyK1LgUGOJ2cN90eHE4M7GxlZhWaVDdfAZKoComWl2OMlT+k0Dsn24dlFyVNxkQNJpg6Qp5DGgeg80/MMj9JoMDZUKerHyuhEZvtIaUToGsYhMxUWT633LXkt0ClE5dKqFFQssbUUGErRYd4gLMm4jQEzE8jAucjLlF6AwfAlTw+34NmePniIs0ReaLgFafHDFrJzkoJS2TwT0nnchgT96vP2zIE9zS3nsSz0iTv/6e0q4ey10+zcfCOjcwHAwFHRuZRwAcu+NpPAGPs1s2bjDw3TtpCCKl61lXSw4KRGBlx0vu24EpBcEMrBd13oSHaO7vMpJxetueSnG+kABwuSc7q5pEefQU/AudKnMy43V1yVaj0TprWYMs3dOx48YZH+TU9eQXvmVxVY5Z01m3xcz7Yb0tzMjj0HjvnyywksfwHe5Nwhgbm0EZwrN+48ePIKhZd36QT4+fBNRGhYGLS/AdPz4x/G6wJsQmeZBZZNXFBZBUOEg/ejNkKEQhVeWAS3SEKXQxYmaVi4iOGFFxGhyIgiRPZUlOiiRCOViySPXIH8yCiNKDSD7D0KalQ0MdGK7bnfDRZXrZjiJRSrqMRKlCouSTIGJpYU7OjixEvwNk7LEuP2olRpePgdd8KAwdIJ6qMDDEKXHn0GDBkxTkgkQ6Ys2cQkpHLI5MqTT65AoSLFSpQqU65CpSrVatRSqOuwzz76xIMGgpnaQxnJoEadUk0dCsyCq9egse0wIRxDEATNmpo1V7OWQmrVpr3TVsxbsOiAXXY76pgtMNBunbp069GrT78Bg1U4YiusKnU2ZNiIUWPG7QiE1z7KZ66JBTMd2rWZxDQOqVV/Eybr1WNHO+umivPtaqndWVLDBlXqKNQrl+ylMifbY6999psyXaP7QjV45LZ/3PPAHXc99LgZs+bMW7DogIOWLDuEgCWPu5/xU05bccaqs84574KL1vxJXhokncQmQqL9Kwo4iR489S3XQOkpIqYP0lJC8X6pAB/VyYBmREFGbE0yk8xs2NA+EwkzTipkFuRj3IAbeRxwc7yTcOtMLqpbbobjgR9mCTP7hJOCOF3JgmSS2YsY6ZzZgG09qeHqMskPml47RabjIzVkXUItGZiThZtTHmQZJwNree9RJZM90VQoOVt/InbmbDnr7XMc38FnPQ68Bb3n2ONGqGjoOAgGuEG4zIkk3Bv6MpLDmG8aLTWnDYk32qBhF9M1SdFp1CItCk/CEl8az05cWKZlWuYrRi5egW2LsNINqrXIxlXKgvPG3/cTVvPzVfpGv9OGXX1Mt4HaiHbbQH1EHx2HQRt8c8S8DbSMvEQVWrcZbZGbtulHxJpms/ojoIAda3ULu5LBfVQH7oKTS3fghmUz7c40ptzxnXj1d3B7LovgydAJf3zdB0jEX5a5AsBmjXrCbJNevJiDwtzGQiqePQsv7k3XjvQ4UUyZZU32lJw510RTzbSkuRYatOwrG8BX5dwXTdmiNGjQoEGDhrxNV1hbi7H0hfXu2Oqbe0/6euUL3tTGvPgW2vY9czJrrHwNrCPTFG2Gsm1VxcltGyBPYqIUg6w8V4vbVjF8vYxBlfvtfvckmBKwYWwPxzGv39i+h2GxgY+SN/1kOnH6jjSbqaXsieQ6esUw7RckYLqapOj+wWzFflR9qyYreJtC3bw9kdRhv/tN9FwzX1/R2PU9/i/PL+1SD+gzCc6hwh03kU0kvwYD9N8lwWL3l7hyK8a1K/4jpgQ3TUMQf03Zvr0scuGTV5vrUw+hMeqm4fCO2b+iLHodn7iChCeL1HhMX0USn8ux4eMRfU/dte59H4mvlZgpUGg0IDQIrroY7YPFHFPTW8cguF1iVJv0/cKFDKrqHv93XEDtLRru/wckUPq+oi/vgj+DbPmdI2yHfxvQihY08ynnI9CAelSjipdlXgDlKOMpUIJiHgGF6JBFXIE/CfQEavEmUAPVeQ1oD+3yEPwB0A6q8m2gCpI8gN93kfctXUxLe1Ja4xK53MzJjaxcN+QayFW+zBf5PC/wPJ/mk3ycc57jWW5w4ICBMQbwTp0CgHmWG871mftDBmnGwuHo8Swk/vBplTL2eUSFEMKm9wiY49dnHlsPab2hSK9HIb11s2H9jU82eFE5NcD7ZmmWfYRk1xLxEjn1l9Jx/GiYhxY+XQbzKLNmWUweNoT/zFMeCx+qlIMX+c9Yay3mj+4NHUA6ITtkyPSJhaayhjmI2lTwlTk0QA+z0BZGhSbKIkLmsWk8zIX795fL+TvsPFHrt0A5Aw==) format(\"woff2\"), url(../fonts/dbscreenhead-black.woff) format(\"woff\")\n        }\n\n        @font-face {\n            font-family: DBScreenSansRegular;\n            font-style: normal;\n            font-weight: 400;\n            src: url(data:application/x-font-woff2;charset=utf-8;base64,d09GMgABAAAAAFzQABEAAAAA5xAAAFxrAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGoEOG5xkHLEMBmAAiiQIKAmFKhEQCoKsHIH+RQuHNAABNgIkA45kBCAFjg4HlzwMgw4bXssH0Nv2IHTe1soI83rYuGqkDxvHALxweXag9jhISzpd8v9/TlIZQ5OypymAqN5/JIjSaS64D6FPlLVwFFwiO+GFPTs6zkKnfkX9Qke6qqJEGQp2KtrZbLUV+QytH+umJV6481AVleeTRaKRnKVpJNY1jLofB06UWjyHA/8i49WTzHMHRiZ3LH4nnbCaRGmHEt3IYJPi48jm2WmwWu+ZkZzhn+KhQCS8/E9580WZevBlf9nqYqWiERpuOlsX7Uifej+2CoxdD1Fj1anXfx7m9ue+t8AxekUKo0YNk6j/ATEDq7CDtBojclJhfNBZTaRRP5qcWLgNwNxEpRV6wGAwYAGMsQxYFivGqA0WrMgWkFTswsBCFLNQfyPB7pf+96nhsKW5Nsn92AiHUSiJBTmm0iiBEAb+IU72vm0+ku0GmHB3cXFhQN0V6a67RAKZ0Y6mtdnN7my50uk195yiqWWHVkLrOWpVQSGRL3Ev5E9ylLx6jMMoHP4p0PMvtVpVKt6kBFMc+pL9NPf/OYBnOJkkE7hAL49oAfM/u90tuitkUZjKCt0a9eXCRI7o4nLRVv9PZ1WIVIaVYan5ZLQnGjnbiBP59CVwdv85tRlB8t6M1AU8Fo6Lh8ue9kTwpS/7O/lxnUTZaIHdZam9Sa+3RS4RSXZSUrMuexGG52/2pl+Tu8lscFMj1dwEd1IHAMq5KHCyvGrgjajwZmYT/v/3A76tfd6fgWGCIlht1ShINwVbNQWLsYqmfyGaGyz0sTHGcx4ygwhWRSyao6Em/VL3adCKv623H/DuQuidS5tJnb5nbhEVYCcM38/NhRfO44eqsDoQ06IMSzCULF973//qTOl1058PiNo6B0SKVYJxZggRyPJaW0509JpehZ9QuwTgn9xUyDrpBjIdqKaun2DkhLzVZEhPC7nfb1mxPTQTmFCb2ZguxPR8EvKEPF6jTpqqv0mXQKIkjAFHFDAOMm+iE1TLlP5eK6/SSnLgRq4hxHkBNkHmIa7XESkXf3iEvAkSYCbMxSNKATADCkzNDP//Lpvd5O1SMrRHaUIhhOQk1Fz6R80oUB6LRllck3jLlalWuo3FiICkgCvP87wrnDU5gHMW731o3OzM7AK7g6FgSWAhR7J4D1JHPQWJMtSZBUCpFpB58Dz1xjuKPCN3htI7b3PnI5v+Zz778MPPYuvzD5L48/e/5lKnL/9QAdoSCpst6SjT8Zf+pLD3iqCAhEe3V0WoXMdX1v9P1d72vhlpzwz1gyA5dK0rlzX4ZkARb0CJGJBcEqAiNujQWVonrgO43IIOKXS5KHMqKh93LprK8L9JjPflFKALriFriWnqKz/OESmjfZMomGAsy7IiE5Wxyvgdj+HKQJ0XBRgD9HMYW3kBVz8/thkcICAhCoiR2zC2bPtMr0XKIFra3WlOdQV01FfsAJnaMXyPsi0IIPXsH0ZuBkvERpZpYshNM4jSNMO5TDNPuWkW6UY22Y7sdhg56gxyTiaSrQi56g5yzz3ksUqk2kfkD/8jDVowrQyoiw7Eu+taHAEk7vYqdtoPTi34diTUQLwBMJnIAAJgCx6Qaj9SQu9oOYTFibqE4/3+i0A/Pj8QwdbzIxFrWwciXewdolBY90S1TQbYdQj2ChxMcLTAicCZwUXAVYNbN+AO03uh9Re13EaxSvVaYQwYNW3x7PprVth1CueRlz4OP3MdgKO5MREAGAB/F8EA3MYFAk4Qa30wGKA1soE3uUbk61scHtiBr9othCQWK9km5+SRfC8V3JyxC5Yar04HBCRG2vHxoiChW4gGB74LRUhRoDars3cjwdQCYNkS52OP5csKLpErfjYVPRvTwlW+aqFZ54V9hk2a76vK6TasQ5TzhfPAM6/nPz5pE2z+FXshOCIVxCAWcREgRoYSDXqRSyYAQhZ7obbR8k+honti39KRchWrPK5XKzvGaECjmoZF63Ydu3QnPhIe9NbnvZ8yYsnEL0wGNMdMZkPhsVAhIylsEihyVokS1rKBzVhzvNCNt0DhYpnFZGeC85WWajdq1wNbxj1r2ab9eOpr3/MTL72/8OvwOweAOoXyJqEbgyAAwkH4jkUiBSJjhahFJ0ZgcaEtZx58e7DmQeS8xZPUC7PFl8KUq43N6Uxfhk2at2rboXO43Qd5RnuN8jFt23+bTcxyU3WGvrEgcREgdizTSuxYo/XapJFgDwXNX6jomNjp0LmK9yu7Hqm1YWBgf7Sncbu3mNb7Ll14fE6vLxvJ3h0oaP5CRUPGR40HP/HS183f/V/uz37Glf9/qUwTACK0MME+nTDdyOSAYjQcmV5euw0ZJ6TvNDM9Gb9jMOmMTzRMc8gmk7zQiB3FKW90Z8RbrhEVpBWT+t0tqdlD3yePA9brlcF6pcdevJPeJdajzxYP1J/+MroGsOe1K1ozHfGKFa1o931LcRAQDWuBfkr6eWiJEjklJnESJXr8aZVIKpTaUwWBhzTGQ19Hx2jlpfHyGo1Ph6a97zlS8rgfUHa9Wg00ir7mxLgyUKZLvAhGyCivLbR2IB1b82KuwDveYZIy8iUSJek0SX4kpcMw9vbYSM1phUcD3ZQaq2491iPwj0AOis4Ogb8XtyV/+YF3Yegqc5eXhxXrheB/7juLy3jmlfYtcS1mMdHPnH2YVr6WUZpyDVBD1GhUQySIKcxSEiNQjEI0WCs0mMEzZ/NgTHZ2vseAGfpgrxs16Ex/M+G5IOtXuNMTPusHclJsd1IG2nLZ8ln9M6nCr5LgKFYMjh5y7M4INGPu/GhqglKDMpKUSG2z5hVHd6dp6XsfdIlTwd4V5Na+6lewt528dJozfnl+wbbAObanu64gvTZNw1dbLMT8eg7SnipIz7aK3u1AyorVCb/ADJ0EDXAQ2G9vcE/c5pDIXX1xF3f3LALt7G3cSPr0hgzvXqNcwY/an03Vgqn8timvKlCTyy6eX2SqybefoC/HTHPtLV+7PydExLd5JFeE5MjDbP2X3RHdSDb+tQdNY5/OZOLssn+TQoEBsIbuoy3VZ9za7LSYtD3+Y/o0ms7TKdLmKR1W+vkRwCnAhcez8ftdkP8XCkONMkGC2RZaaLkUa20evPlrQT3qiSomLMb3YdrWaNcOsob8OriTRm/+1mPgdLE8oIKKmF/vsMyqXbTaBRMhqXC99DbJVCuk2ijdQSdlyFTc7l4tX/8UgVFBhRhYoJtRHplfM69n/t/bFsPYfJ0iGZEEKUu2fHZVWvXZ6wSdQjcvoSwWOD68WRG6grGidMWi7LjLxyoly0DGolagVLU2/fY56bIi+q1dL6mfrwKBQsEmoVHIoUa7AfudkqHYLfnNhM+3B4VG/VAprSJOtTpsc8Bpma64HeLNvVlxAINBw6Vj4lJntu3sn5GV8m3x7/BhLQ4cFo+MnplbvU47HHJWtmvuRvg9vmyApMCh45PLUcyjQZd0h52T47p7x+/xYyteKjwGAQWDEmUaddvpiPNy/eL+8Tv82UmQhoBJKJdFuSZz7HLUBXlKPCi/I4AMGAKRiJKRVYVmPXY75qJ8pR6WnxtILlE6kkxiKnlsKrXotcdxlxS44ZHHl7rIctlabmw7du0BvPe+D/9zG1qh8sKEDQ8hEuSo0GLALFo/+cW17ciNt0DhYiXLlK80Vj+DKNqN2vXAGjdr2aZ9p7PX/2dTbt+D93H4nRExKgg8xChErRceM2QCyZEHf+HiY/oLqALlK1WtUbseWONmLcfNF+HnaN+pa/c88fLB+3/2S/QVw++MAQgFOggc+Ig8k3q/XmAFUKPDiAVbzjz4Co6R72UAOF6qbIXK1WrWqc/w88kPqzYPq7YdOofzwDOvfXz4/RfiK/hv1gjBUWHAgosAMTJR6ZtDpGnQYwLJHgqav1DRMfG7Gs9Jl6tYpXqtMAaMmk6L20vW7Tp26Y5H8N767OfL//+lqqwTI0ODCRseQiTIUZloTa4MmLHmyI23QOFiJcfMH1CFnq9UtUbtemCNm7X8f9tEH8AAtJ0sUaNux5qCfwMnJCI+dokZifUy6jIP82bezrt5n8LJIiIklVrWaHV1S92+7lB3rLurO9U91j3U3dZd1Vv/6TMzqRiYlKrQYJOnqrz2m/8YtKdISjIgUEgEDDwyWvksqjTpNGCRNYbtctBJE65FABoexgE02nJzqnTLCZUoNxJFbHk5uOEVsf6klJCLcjQiiuHMZj2xXOUlX/Jv2YrV7fm3Lr5SKrPyqOjKr+Yarc3C1dsJJsMUmmrT+rMYRqtoGN2Tf04eJAxIB4Wj1omHCL1EePQMPUGP0AN0D91BOOUaX089Sf7KEuKS3CANqQA5oh7+VXEKYXTmY9MwCRJiw8kSNkDW3BbhxL+BIKUBISkVuPfdZ1989c137X4wsrMY/N4fJqfB7/w3JgA6tUrhM7EgD9vBzmE8dDnn0Bo6kH0oDK3NOsyHZqYW0Fc4ND2hzqkEi1CD+IJAqExiwT6UI2jQCSWDi0hkVw/7HgUQhjwJlRf2fu3HodOHzvu/mhtgPSEsOuCtUZ6KeAg3ktGgHnL+Ro2cgBRbGwX6K1qWC/SQxQLNFISRgUoKMQwRwNcAfdRvgWzKPf0NhNfvGuC7GMqk+gLfyu2BOKVY6YGnSrxGAxcVb2UH9ilItftX5wuql9ryoGKxIqDMuszntYsciZJwSBEmgQASyLjwai8BddGGtk6Otfbghe5SLFUsaMuBuq7D3BfqRvwbh2Kl2NOAQQRL6i4Q3QdbRCIJCGYQQgoZJ2oaH2dzjzirqW3M14AZza6c1dKVj4RVSu0Px9UUYl12eHPX/PYAaz5eeYS7nvCCf1azcP5WwYHzTsoRInkfSgcmb+YprLkcX6H89TVigpVkvais8iqqrKrqaqqt7ojjc2P4EgmnjXMWYvxHdTJB/w9MBP6shHw4oS4Ed8qX9efob5eZzKs8dxVVVoUJZDS51DHX3FLnnkeeeeVN34BhvIomTT755pd/AWkLrFOdn7ycML6PdSAiRpwEJCQRicmMOtCyqquprvoaPhMuwNcjvr0KTzazGCvSL6katBkaK0zDqGdbMmtlZSurmlJKKwAvssSuOiSYV4kCT1HPTuJduJyMHnqQ4+lUhi+f3aCe4faixRBrL+v76zvGQGNMt1iarQ44I9t1dz1X56P/tBFIQrJc8kpbUFH1TJG+wmyE9CKXNIFkhFRWx3wikhNSea75xkhBSBW55RcnJSFVps4/AakIqSr3AhKSPSFV55E2ETkQUk2eBSYmR0KqzatOmZETIdXlXec6kDMBvdDmXkBAZT5XdbPKfdlVrApfdxWr0rddYlX5XlVZ1dp3FavGj13FqmXcVaw6pj2NuwheBa+CV8Gr4FXwKngVvEZ5JX/u8iK+8pfshQICmQHJtupAmu6mbHtRLUcEhkSl8mwsck7ZmmXDNHXhOcuYl/dckCuvBBeCV4GLwKvB+Rp4BbhZ4bXg4rx5DTjWabyA849r7JsiEI5gIHpRHXD8bEhrrPLRDLTRNTnKOiqVZZAoaBYzSDSO0LmkBpKT4Kp6TZ2p1ukyuAIueXthGnluHhJaUBUp6PMrZEXpDwckegHlV1gRz1Q0t1xIh4NASLYDxj4KcFYhlFuMXBYeoxCmURabpPIC+0wDx7kaT48nAVO3ixBgWzcK0K/tSxP0qwrwZv2Oi701rHfE7yNdoef6+c9bjF+A5CEzC3u9pfKV1c50JfilDXBDJk6bIhBa/2VxwGoiKAQKtUyitCLzzK/OBRdV7+RZq6mtRT2vsj8zMMd5L3gle7A3T8DNuJRrXtrrffqP6l9c4nMldf3u+jONQAY7Jzcvk1hIIltcsW480zCpv6p/UP9kthmuPvZ2ktO855ntud9257/Qv6fRZDqAq07CLJfkVIp8C6hboUUnS5Wzuhb1rMr+yMBU84pm3V/dt0L3yCXcCwDb648UOtQdoUuJ8wPLv6+7kzGUcX/BvEOFx/TWa/xIqxrzHr3u2/iZML7E+0giHP78Az6c6wY+TB9KJuAf/J79HyTP3uedsfXc6vvUc9ZyfplbpoLXuyd4vbuWRaWmZL4Dw+vt99TrV88kP831jgEGgwD8AvyBITAkyEQ5KlCDerQgim7MZzNwYEtx1PcJE8tpLnMdN3HO6sk+z03u8xhIchI2zontZczbHuFp4cw4yi2ySjEhEbYmZHIkXBRUs7XpwLQyzlqYaHFgUqBgUNAwsHEIZdPQ/jmz0czNM7dSbdKr+tb10Thcoh6b7LDbEUed/jj+L4tc+a64qtQDjzz2XLV6/yS2kUQPOwaPSmWqbLLGIWtr7b5eCuuctkE3hHRHLLBaljPS+toDBHhEmQUSELNkxoIVmWQgYImIsHDwYghIiYgpSWpJwa6YlU0VtTtWS9KqW5ouG2x10B777HfZeRddkq7ELTfcdI++1s5766XX3vjTQ38zt4ZQslnWstVHbpDCXHb62ZvPwQLuVnCWZBkPK7lYzM86PtYIsIG/9QJtEmSnC4Lt0s2wUKPCjYm0308OiDLuZwfFOiLOMT0cNcA5/Z012IQRfjTSVfGuGO26cW4Z66YxbphkykSTZnlmqofmeGGmp2Z7br5q7yxV56OVPlvhE5EUCGuNd9sk93SwqhMOOumsU44ascMue43ZY7ttRu20m5VNKR09NSWVbFp58uXIZWSw2TCWIc2Wmq9LZw2atWjUBMAELf8/Jf/u377uBsDK2xXb/9Um++Qb+RUBRDgDwEhDW6NpoRu2B42+7XWJxegkOzo5fRLpxAM+uppd3KfpS0buysML4pAVJYZYalMlk591te7TOaCch2gEBBPfMl3J9ujKoCefvHKnmOk9AvEZ/WtG2dUkdXhUROTc/Rllv4+TrdpuKCsqDEh5nLU6TU/qYSohHHWHg6PEOeKDmucO6Sl3IRjobGbMIv2VgBIAkj6YPToGYkE5i9HpMcv0h7dW6VPjXNnyblaUShE7ymPwPZtoLbQ2imySMXQ8Mj6j83SlqBANcUKsaPoqjxvKkRVZ6xQ7PpZGmYZBDxGkFFIq760D0EJ+Q1gXSXD3SfhQ/kwRbhJPoiRAwpsoSbqSYVRa2SBOXCvWuCd+YMNaZE5YSqcst0fWKNlNhvYxi0IYoxMApWQImNEYojQOJG98SS6zJQxXinJ9Qk8Y6UlWVGu11IA0EyamtbhLdv5b5UktFD1lHbvTs4RjtUXAiCZ1JvlpvakO/CM3xr9pF8Lv0xKThBxnAwDtAeBboH9wvPPy+IHZOwjXvPw2AACw445+v8SpE4MTrJaR8/G4PKy+1RiwyUpESSjS73VNuaZ8GALbZqMy847DK1gY5asyBcla68V0lFlKumLnRXWoZB+UP8pNO3tgj1qn72ySX3aMZw0pjGTGIFNxWx7hsV2LmN4U3zGJ5itTSdNqfGPbSQln3WQhsWB2rKkUZBsuZWrxSsrPXF5dfmmv3oFbj8LjtR4mrZ2zsLJ2MkZ4BxYKQG8teGig1le3qtpJZzUc4RluFWQ3rtacyWZ2rcM18iTzlQ2MOa0FCPx+zUN16rTrtN46mV12yeXLm9ex3ktnFRyv7dVg+4Mx1lbeDIdQKid752pnvelOYcjfdrKuc97oG97apkP9Dsm+Bqr6NsnIYkwycOxfN4cZVj6esG+30dqnEvOwCdMaq4n5zbPW+6srpdiYKEvqlQiHjJcbmOxBimbsutadkDMwgbgkWCaVZIyVFz7fffF+OjKaMU0mDcxbT2RZzA5gfz+GG6v9t14qBbVWLtpHJEtESUIVl3LH07ASRdXinVmA9/aR3CgC/NXu/U5QxJVq8KLhCgdpMhoXHHBhOODfxZyQzZnSZGi70UvwnDdxkKk4EYSM5n5BUo5iBTL1FNZykgqcqCse6dmTBcnWVwUQR6I7Ey36RDVZyHkmIZuYAmAgQykWtZWKNJlk4IxDR8jG3grV5NRK6MuQXjTZIpMUwyYjIIvBQbYJJ8Zgki15Syju4reO5n5GMYg1QSe22Yo5DYdomL0tZG0pcPmvcVCgNNmQIMBtaLbIDqhaoy7+rF2N0Zrkv41gNlgy52gmZCqeVdD27nUJYhtZ94YgzflKJ2Ym6ttrdtCsQEGe2saEO20S2bpltsm0OmrWiqcHN+PCTWrUGLswEsxmGL/3mAhXa6H1ErIrqCP59+oRkfNdQ/7iiMdMnEyAtW57+o0IsOQ+hbY7SVTkw+ewrbvN5eNCMSh50mntyO5mNZFpBH0NkEU2qZg8Z7IhRo1m856gH7RHU9ZWid0WNmrQL9HQPEKj/CzN1qj/E+O+bqiwQtWAVJUrquxOcWCQOWxzxBWTMHKk22njNivSuzFYWhkmiZw7wg3N8WlArIecYc5DiMMQIKs+n2lu1gaTw8pOb7EnXncUFcUoOBs7W3nwGTGt/lciMHdQ6U3d0FjybmLP8baxcUQdHXf76XJnxro87LrTkaSMWYKRckpkmUSrke91tZVjovuLLPIPxmXBsjnH23ZZ2bZLc33BNSJyJCP6TPITLVmg3HzD89YlOh14RLVSHK9PMk+cX1sTiKwLCRnLV4LkykaDMXoL+a0KHRR/JsNzPaL6N9dkiQYJ2nMQbJ7hO/IiJIcX1SuumfsVzO9pkkmurg+p2/Vf7RKPNd1zgTUU10Gko3NNKPZhfH1YRyyoLmrBroIMMhNH2py7UxlGHCqI4CQKNfVPk2XH2NIW5XmJ5RklF8l8McU1SVyFzmrUHa4vQHSXYlHR0cV4bm8KlHTgqjH+VoekRQRS93iOqPHyDCM6lyPI/L3MKQlCngdXFAbotFzskI6Je0FYqHVSkPAbCGl8oIB70hvo3fFRIy9t98TCitT50Q9Vb8tf4pRbAz0qxq9AULATuXqDGmY0DtjDsWV9zAfV3B7mZ8bEoFtq09Bmcp0CWRUnHwOa/SLBuKm0BPMZkqL4g395XzlebUruRN05lJGle+IEV6UJMyv7G1Do3N1hpaSiySyL7EF54auNOhT7j+NxbuefN2D8nurXHuybBoHeHYchkjGWxaackahy/DiulcLihludyGooHjCNZyl5Gf1Ahk6PL9p89iSNOdKPXlg46IKDoYOu7lCR93IaQV7+jnU48scRUbEQpjh2rUQRzo7P86jWXfsW2avtcOcAQ0mmRtlKHJd4MsqyyZxLbYCJTYG+3NWESHoJwf4/QF6cwpybmszhRMQ5j3o5CQ9xjZIRJRNmAk0uFqdow2+1MiJaZgwnUD4rHFwQnWqP3BhmUtzS0vWc/t7+n2L7kk1d97toMhzSR/h4xmiDgYDQwYgHGWXkiDXe9xyFGiLllHvpRuq30KzXcO7BhvA3HQEOS49PSxdGKLpU7uEr2CzAPDkqtynaI0ltzDOTdk7Iee2j3epmdx6vnWFlxuyPQlJdHXRTSIkxoVfoXyNAQ3tM5WtIFbd9BOyt7AB0j6A5dtiSug+ZgQYY7JZw5ZB97HV78uzkzKRiw8t/Lz8osxprionF1aSjEBifPF6iOTAp9Wi6TfNafpYwoIXJcr1gkDVgsR26hCP2AK6cLaoJfyCg7NlsPTQWE13u3zH5XeDEGsUPDMTd2mvFxkXd2JGxIchIf6Eq9+9Dtpe3Bz/wubYUjd/PauYLUD4cvDuskgVM25pBGS6UJ0tJ4qU53JA9d9v4WcdsjgqSof0+7ilmIiklrMGQ1g3boZFQsWhp16MJwwh7kieDmAOdumlaKOT7N0ARBSmAYVoc1LRcQEoafe1gXf3O0tc03PIh1s4xlomNB1lC/mZMaoKgi7G1B29sbPA8ka0ud2aEkGbXeDqk0XeXWbF+HoZQqdHucoAg4aGWclcP/0p6dusjrntYu6dQk19SpnWywRCMZjw72fFaHjARFhBQ9Yq0hDmOS8Yf2t5Zfmsu6Sxmhul2XFMMZgDjPIV3juWLcNUKNv9iVbILtt85VT4tsk8fKVZJ8nIa0Vc5zL2PnrONOgRUsD5DpwVOnM3LLUaMDHHs7GAMxfsHxbS884tAFtl5JYUv37v3fBbSE/P73otAgss4kuOQx7JQ08cXidd5Rp1e49fQhUbidUlJxrGe1L4uL0rX3DFZtYmjfX7eZc8DwxBHOndh4QD3FK2kH8WMnLMhjM35fdiZM0FbMnNLFJ1U7af7BR6CkoR1ebpeB+phcHo1uj0Ocq9Chj87u1DFa2heiDMM6HSa27ddE+1bPf2xHM+w1SSqQK8Mda/y1zORJkA177KGtIjyLKdSLDzysfH3ssoDQdJnhkK9YYhOHVDVRXJ1nprB9TtAcx0Gk0qnTMiI7JjHuztj8pY3IESKA1st9RT2ghyth00blySIb0dgWhO8gZayrN6yDYF+D9mPPn6QpBdspye242R3p8eOQKa9+0e3oXwNkviZe9Syq8UorlMkJcQaLHuKZaugEfsY+Yvxc7nTm5Vxq03u1vp1smqkPZCGhbWayL0bqrt+DOLKkM9sxAETEN+MsKPKlc4GyTFaFzQCo/zk1qt9Qr0lxy1k+9FcaDUkId+96xj2H5wTxxKQKazrosNgZVOWALC/GJjRAr+kMaUNOT7rRVELO0ICk/36w48eE96jvnhc+k94XVojkJ05Sijf1zv49Ps7d+w+IUP9NA3VgIE6TEd0VBx0kcZQ64w0M598/1lniQqZW1oFWXDqoVCJpB7NapL6xgXuMKmLxi4QKlJcIb99VCd2zB+0fR886p67pdUijgP47L20HimfvrHFXJcQ30Jm/IZtH6kmc8Tqc3SfkbX+iEskHWXkAc+kU6gz2/nD6XmAayZFXHP7n3ZQVdEFpxK4rwP1UO8fBbm6WEW7QDNWiiePApl9P9Oo2O3ByTm+3XF2KbpqTX5JT3uxGHpK8fMn8cSl0sOuIFbn7HzlAGVlIyFjbVEwaU5JfvsHyqbEd38hiJHrw+HQoKoGkeXYT88A7dYkqHSlt+Jk35K6n3IXBLfGD2JhzQ4ZVl0/yPq6PyiSfv7g3M9jgPn9BemNg3Ag29xKS3ofz0kQH4xv2ohfDXlzfeloRcjpmWHE3+uF6jYZ7xhscU90LFBYQrE5v1wMdh21o3n241ML9+X3CFoTy+R75TTCQUnzdL7jOCFb80bFvoGT+3MUl4//vtrN5LkBBDKDmvvWOjgnQc+GmJzX5h3rsgY7aHlZeO7R590Oj/jvvSU3PLb+4SQ7jDJpmgMyWB0WPFEGmYL8oOTKt/q8nC3t9XKPMtkIcAHPJsm4g3EHSyKbCMtgIekX5FmXlZyglriqR6wjqWEqGe1551nv6tNPPo9KFn+inM545IPkE0SfD/2QBbv4C5Uyg//Vd6Wa1GhvwkJdxaZx6ZYZXVLtTKl7J7ru8U9Dk2PTo0Cmvgoe6lalVKpPRD5ryeIP5zRVxK0D9WH5/1A1aMJH1A+IBO+oksp+vhvIqTYQZTaOPx8baLK/4CxWz1qP7myvoS2OnHv1YsWohaw4RU+PVCrGDxKEXDvb2cSpL1rb3x9+RHMq7wWo7hWAHtC5B+0gBygNpPQr9Redvv+h/V7R4cmjYvE3H7E18gTrJCHftdbS6Wz6Z+oPR1megUnis6PDb1eyFrwZZB9mDU4V6WgqoYSrWBEFo9UAVGHYxool6xe5V7XgdJGO7Fd5EaQt28/vP7D78jBeGzwK4AFlEPUM9GqHYM3c4Plntrytqi3/RUSWTK5ae3zn6IZTq/+Z+jqvwjVvyXLHYNUSPuB8/yqRRMQkWPjrKckpv9Tz9UlO7ajJa7gsZlKs9YoXx/PNU7mLC18x37ui6LtGTx9sUO9cn1dh14M1On0Yrrtu3bKVDYvaWezwi10wwopM85RZVaFiI2TCdJPsQl0hOz71aYJFvQa+fyyJhUcSRCNvXz20oMlwLAEyY2D7jtCMZ+ZnJeY8W2AoqLqkupGTrTZPmfV4nRNxfnJI7S/aMRUSvONvXYrisbshc/GfVYq33Sdq6Pk7z6bVT5nFr/9lTP4SyMgNnmxI5R+JN06xN5DIxildUszbzZf2jQ9fXL9h0w8HxrZcWFcvtAwvRj+utW1aiH8MaC+qSWrJ27/54npWMXgsK1tqbulObiscnl2SuElmlnoNlZJ4bJmXQ1aw3j+tumz5cm5Ivo9u/JkkAat6EDx8ec+hkYur5XZsTq4NuU9zvsaLch14ZZXQtX7uUtuW2nrr1sVLy5Z75PrJ2tpit6fZ0SbpoZinUPlClkTyRDw/WCcElog8FQ6bp7W0i2/bkd4AQ9fyBSyZ8ClvSTBfiBgnz9MA5DMETu92KEc+k90fNuf8pvHhifXrN1/at7nnXF9YCM+0nzSstwwvBg+Wb/q1OKk5CcszT/355EJ2ttEQwUkO6xgQXuMKD8l6KLD69XmxBJGcRoaFzWHDXgipKWJCTm2JXaeFaFKl4RksNgEPznemK9M1jAwZydjpKCcXRDWiXzkLLOpgzAaHYPU0fVSKjteLh4+cDBE/GDIPPQAcCS3PLbYVG22e88aziwcWzFu4ZOHQhD2SNDm6qDmV86tnPtgfhiXEeFBPzL6B6UMLB1VNE2Xf3GKyF97k5Uc9ZIQ/tEWtX7+UZPzhoWwzbBtMdOlhySLKdgqL2l/7c235eexZbPGvDc8KyvfH7ow1p0k9B0rNn47FmWP+PemC0tev0K/2Fc0iU6njTf0L+NfMl5npYNj40kFVCponlQoEXE49oNE/nfmSlKqKbJD+ro9EFxtzze+B0wEXAjmSCoN3brghNR2eSvrq7/cxsenXE1wKgl9mBpz5YOyAE8f4fUtSsaov+mKeWp328yf5G0U4UlyckfSLKYPMl0oFfC6nIbrBj+uPOhlCiIEmc9ncbQ0lgPRo3uNUNjXbR7b+O0dSUegrm3UxIx2eyjwdbBpsbXasKkbqk27DGA9Na46GkocUyZioKVqh00EwZEK0k0kr98PhWeFzGnvrYJxZoxrbEJS8GaiRy2O1d8hwFCtefkEUnhp9OoafdAC1yiFYewT0S4n3FNR/v31lRvMKtTCswTzY2mFdakXIQaMBpl1Hc3RYGwf6Phm8YzOcRzW6UT39slzGtuaexmU1NU1DvY1N811wQgOYR+IvI9EqUw2LLO+W9mBoFfXUcqeZVqBUMmzFlkyXArfxwW2lIbI+ClscSYdKvGgH/1or71HCsbfLufmlugZ65b04gWuR2gKTwVmfPrdL3+aWvp7u2sFye7PvDuitw/Jod6/wkcJo7x9zCT0VEcj3Fmq8chbr/9xJ+3FPE7qN23au4JyCq0gxFdkNBAk+LG36rQjYjzuYBmtBES6/OSZdoPUUsWWqJnlrdT07Czpy6TASvxGYwMHqHQWmVMroxVgfBvMVhQxn0AGUlKeJd2vy4mCCJIVKBcPBv9AxyN804hEHsU7wZgn7giUaWXlBqVEFnRzvKfCvYeZpIBj48XthcXG/nyFQbFIs8t5BhTA1HRgICE+7GRZegMhF9RSSUForTm1Olgw7fRQg/P6UcrZEEPowgpVaOG7d6l8VxhWyno0/7wSUjl25QCFd+O1rwUqFIBUJDIxyCHOoik/UuygfmWSgKXzXHMbdYI6u6/PouMk1swcL7JhAKERb2ZjfuV24xiNNysgQBu0xwFEZtWovxnnSIKV6tnUtWigGHBocEvrTl4juht5aHPtwrFHmySqQyDILKsr5lkpj7JkbYwpYvfV9dRhh5Ou/pNlWFLu+6Msngx9+m8iV1t0isfGH43Jl7LHLhszCCsbap9GY6+BCEivul+inFb80oni127HeHtxYLS8fffq5DsW0udvrg15L3rksK18qxd6SIVaFEf/Vp9anPBNcNNg627OkKFUB2vN7otpvdEiRjAVM0UxlFkIOE8p7E+vVINSuLYdKfn5gZ3yYNwr8AzQQtME8t73NusSK1CTua1r8PbyTPCO59iKsk4VvHncE/nxg4PpwVdXO/qG4IVeu9KWQLBO8sHRKKAzw1/L1c9jwNCTfKNFBP41qXj9NLsiM/uvSL92vo5BCs8Kgl0MgS7IzxWuwww7hWvF0YaKc/UOVhp1ZK82Ym4SekQy437T4Kg+VdO7b2Oo4WDOKz5JrInKDyhvrnTqrnAWDsXY75aHhDIMgkcAiCAuVGjaGdqeeW6qP0So1ORA5NwICXHyTVjHEHcKgGzJgi7zyhX7MaBFYl0oYGi3O93GSFAjYh0hk7GDPfxaDPjRG/yodBl7NmJkLltYYJwMpjwItMbChsjrtpkBpw+zO2fzNgSWu+tYWMYkXfjTcOXB93vX8g4E7/3K2HG45nB8+a/MSs5E8fqnUTL9yxQI7fTNhbhJ/GRE86M9vSUv0kacY88w6pOS3EHMZ+k3P4cpdh6sJ3c5tP1dw7g0WyrP2Ik15dspYcPFpwWmkty8g/K6RVOFyqh24FbOfdUr3xlbWOFqRQv81zwpGviXLBQxuWjW3mt00aNUfeeeXTwG4GxTzKgGSN0t5xn7pIsqReHDZbB9+cgoti02nr7REWH0hGDk6mRP2lSeHygySbOW5yNPhlwNO7i4SzRCFPE+GnE4kCO6Ya6qrzTVFZz5WFNcUDmYoC/MyFFQqegoKLjc12XKGxvfm087kn7l3BkLcV0gfKJNIpYj5gMKhgnz34kauB3D8Z0zjqkaORyznuZuiKx+u2cK6wppgD5NYN7MBwRJ/yUWqtibUVmhx0Rok/V3WIoGqozSZ6qmpcCrYbQ1NPY1x/l3dvdPab/iq9vqdVJcQTYy4b/eEmnAVaCseP8rCaAGDChPG6nDrdUySgB+HuPfUwrOsMa8pwon982i/f3tvCoT9NRgDmkqDAks8tvx5D+uuBqgqZgwmSZQiloykZInCcBUl4PGxqrJSAd3hpopaOse2tR+KV4nDfANbFUA8tYEp1ZHXrsajeNEtvaJabQK711dxh8lcaZH1Rly2fU5gEYp7Kmrr5riKuPwcNYwLpanp+iaTx1WVq6Uw9RzYxjg2Dpd8kpvOAbHWY8mv2RKbPIuO1PPhMjAbRJYxmEq2NGXNq87R4YlnlyeDVZzQWb4uZTTOXVXm4NNL3RRRP2j9anyGAOCa1slpNggyJRowasny8m2NTWXbl1lY79+znGVtjDI+n1Gbmu//IYBET/T2sVpYixErSZzz2ZAJib9kK3Wwp20+0iXqqkYbkl9rNWyH1e2xy5gt7trGmtSOZpGUN/enzsv+qmHfsdxSQigxdmmASBkuAdnweCUNqYpuyabpAHiLVa9jEoRckGHP0wJewRrzGhGOCcxD+T15b5rJ3FvvG3t3GT+qyGnLt5TU7SXN9lG5ZnRBeFpZJo8sT+odQFVq6EvGXOV2PsVho3Hrm8d2nZ68PhGsWu6/cr73gFwExGAbyBI92SNFId7Kejm1cmq1j2IbE7rXgluH2226tR5taveUObstRVxOjiyJBSUp6drqglK7S68mUzVfb4eZE9d93/FfIZq4iM7TCBh0BJEDY8eN4CU0ujiLK+y43TK2o0UxrCFUNSTl+KjWB2yYP6O/QAjEWF1lpQKyw0rlNSWU6bDePk6NPIsi1dJPB3fu3azaRGIDA0HZpNrcM0cgr++39/tmg+H8N3oU/OHarqzKrHmMFQTONQ1kSuIvOUXldNQ0tfA6FcJMPhtvgsC0Rk6Vu7rSqRDNaWxur4x71NM78LXxZoCy3Ht5ojFbavFANCFCSbAKvIOIddHRmmiPOi8HQLDZNZpMopgLwj175eK5NhZtLMXKvM2MX/54WziLqvyx0l40/37zBX+Vc0YfRKwWsyS0bPDyAZRD4y/2Bl1xJYBP7qsqt3k62sq7O3avunrv+mSYap3/piHfvlF1HAHXyJZpVUy2BCUFyueIa7XI1EEfySQ1a61VNBj2cy5bzWExiyrwsrpedyFXnJedLIAx1DRdS7HbXW3U0pg5bOjrxat5CHGiVwobQ2ZRWEwuEffDNDmPCRn7Khs+8pgqJ2eqBeKUrW+7t224/vLq0zDVdv9dOgiHfrV9FD0ekZAt06YQ1w80lc39zpiOMb3bQionemWkF+r9cjtB5ZaEWPLNdmqNqLvdXMhVtluTKK4qj12a1VzX0FGd5l/ePXda9+n45ZT6cXbWAPN4fnsg/tEOjH/qsVSMxuqsO0ro8VVVzpibLNXKWEqSqlwjfIOFDj2P8mb/7Ytm9N7rUbiqDb5gCvda9OtIlwr//QlX1FMGe3Tks/laNbRRSdM2Fb5ic9RkpoYLeTH/OBfBiVOuRRNfsjvNV36VM2gIrQAmTWDHkcU0ujJLylpzu/I2QVhA2G26W63afrACQwqZUh2yLlCuFEnFJCYUQlYsFTWnov5Pukj/Q+fbX4T1Zw8lh+RNyvtsAjE60mEKuisWo+JguJTeeAI3zlTLTXoCY8jIhIQ5HN7T2PSTmxPJksxGoNGHWeztQMIiX4Ni75GX94EizscCZ41l/W90bTDFgvNJuDYsBSuUCn/MOBNoOPJ/tljih/3vxS/47CF2hw/TMMOKhmGUSET85ZfNGwIVXCAx6uV3MkPKFqzbXTmnuC+QqfPJo9nspMAD08DxYHAKDV0NjUtBDEGwx9UFE7xE6p6DyWQpVSxTEAnJmzWjmniskMjh8DHohOzr5fXR4UnSqLmk0EggKHlmSxQiH3D0aUT0CUiib4Vcl1sx1zwYyNwfGOw2kJl/VZ1kLa+oTw0UPC2RkEptrAph86XvcSzHzoP4+drX9WJka1wxW6/q5mCvwQQcAhna/ZmFTU9PHAarlmf2+t4AukvCCvJh+7agDVn/eYI88OykIqnoGiT/x/1524zY+Et7KYkmR/H/mqOS6wwezBcwEhDsMZADD05LBLvWQGNSBq8miRp6qGFYPaqVCQ3x6lMVkIiIDdGp+dFSzFSU782DHZg5y2UnMb/Ly6C6Bxj/Of6M6DMrxmyyzQI4Sg5p0oT5yiyiu2IwSrqQ9iA+lpYMzK7h/nISPq88ufvfn/OdpVYS5EWDyyvmNuMNjIohb6+f+2EYfPeRkEZwG4aCmXIl4+yyrXUz9eB4W0LC72c88FjDWxRblyvwQ6gi/ZXh4Mw4kCY+sE5KR8/OnIIB4V3vzyr5loCThg/MXJXv+cefcOwBA/h3hf4F+vzxnX1Jhm6oUH1TMlKaEGCcNG0Qk29P40VItK8VYUiTxaCDw6jSd6NhXG3gG7YBkDdCBgw6iKurRJ0fWefLsL6Z087yUuC89LQULg+ehkDcT0Mg4Lz1ILxWZbFDroI0YRuyJZ3lS43AQc0RsxlbPMJjNa+3ADjkG/VJ4Yyszle4Uh/xPtyWEnnXTModXuC2S+bqGVtYylaYvjGma1h3swKebnx+POkCpu9XCDuFs+r22X/JyLSNHlvJ43nzAub7l9tc+ptLlupv3EOA3+bpb9fv0N9ZvCTnjrU04POFLDRr48YwqqxmklGIBbPi1IUpiFxFY4qIB8tzRCmVihEeX5w6jgXGCo2k5LDT2MDGpmZugdUbSI4umc4ahg6zvIZvRJ5hBkwWjoyFS79JZ513L0oTTYhmEdBZDZlAnDB4fmwvfgF+fi6p8Cr5rK1eOp7OVKo5fghxI3eBOB6UFB8izAoowZlfTyu+i2MvXiG98gMJsHICV+Zbvofv4UeCmjvvxQT9J9OzT2WzXhWvWbS/sPmSIO/0YjifF+IRLj+nFelD+/DwpwhE5Hz3L/AADvaG1ZwZgf8GCXtCVyQqRPF5edWkzPIgo4wlzhWzZJF9c9p6s9kRKtQHKEeaAlH68++x7ufeZ035cVOVsuSs6lYKL+yBHKAMR8c/S2vnZwxJ4kQt9p72vrZYXHwBP8lJsGtAMxtbO0I3VIGV1Q3NN4AMNjROJ+fD/eZe6T/+d57x4/H+4636nNbjfTv/zjOwMq72PV6vHd+ozpFINAa+QJ0rFWlzeBGR+kFrY1g7K6IbLwP8rzovjK5JCeZAxMRUPlYz2+yeFijNmqniB0woUBUA2H9ymD4Lys0oV0zcSnr7iwyLr/24ZoYnBSCA8VY0D7QG1Q5wF3MiTLwIJ7dqVnGQy2TNFUlmAGlvJNwAyVep8btRbKwvbvaU5/ETVJYraQJhVmbLafFp6aMz5tuV+1kn5SdZJ7vMXSdYJ+QnWLtuVbp3ZSlllF92yF9Lw9Pj9qd18tGL2aCs5uKe5r5GwC2L/G51LPPVKC81td6I4g9eidQKJdGSyfqq5+GYezmzrRVeoe2csG5+AAusUSDYAdBgNlTETGAhs2uKzdP9A6ScQNVK3+x/xcn/iuCqzCRuhl7Zq0x40eJT5Pko8OaSiPCJs+ojdCkku10clN7e3BraJWTxcnksYXB3V2e7kB+hxgwkGyRG/+IfWD/m/si67MuFKfnJtMpDZyT7AYSB1uDa2dx+ToSJG1HELbXMiyXvriTDX3Jfqv2uFWtNNa6q6mxhgvo2KwQuIYtU5nHxuGH7ccALldtYY/Ix1hgfyz0yG89XutZRG7xxKW3lUdHRq+qrLHdNHR3XnTMvxutXv3ro16xetUpXYqvXdEOsSRTJ8fEgQny87wRxQS8g1toLuUiLJmqExjqy2ajgM6Jdqfq7oj9pzb2okv4C6Y+tWI4u4WtvaA5vzz08ovF0eokT07ioY6fX20cgkR8RHQFSxA8nToeJ02ZdOyo6ekR9ROHMzKwJGGWsvuc/VlpqOCnm35hIyEBkyPfxCGJAf2/hG7DzsXcWQo+Ez05USZrI+ly9ctbWneqdCNNGhLr9sd+6sdx8uRwvQkYxkFpackgUGUrK2bLBHDJlrZTJFwpPCgmQdAQWi0hfkvrSIKAi4lohGaZgwmhem+dERakGkK3KEFU/A/qA97rcsB+iwKwFLCK1v6RaObra7ClbVawYrSoJeI7raxjPpaiF6R3qRXWjTa01exZr09vVAgqXbKv1myz9tqDlBBxA2vT/Q+Xes/NUV8SlFxbeO7gWCj1HFbMWmRf9h88cWxz7oZgn4SyQz3z/O4h1L+Q2LnnNvtgZ9Km46K1HCs7dX11MwG9GoWcIv8U5p3Z5ZWXdUG9D3YJSiHdpktjZpeBlwCl2SzHdKZERKxx2eo4A5XtTWajXB49YvKBBpyoQWW4uWk5dgqBNh8On00BfZ7Z2jHSgYCvNHYUhqto4qgpE9EBn3Esol3Yl4oB50uUKI6VevBAEgDRF/v99Ipzkf/FucEQZIqtXNCFKTE9LWfKWUr1Bp/64PBmU6Jqcck8FHmLzoT1JyuoRff4GT5vz/ElPs3OjMmeBKZvYWMJho0xjFIkUR+RmwsPyX6P5GFxi2AEbPc0vNgVBF1YWZvPqO1g5thVG9bbyhStWzRf3Jsvhx2rq4fFB4/NCzdHJ5cC464spyzjvpP4TkenPU1OKkxnljeVWucJqTMlIVMLRSLEqDY9XpiKFKDpfr4CvuDQVxV9uKHu/zQ/4O9CWPy81KZ4FAA2mI+bD9pjmIUSxikNfb6IEmdyVpd9ylGciqxtd1uLKUuczVvBN+28FSThKCjAp5Pc9sBg1hCa2PztaD1Xa9IUIdihJKX2eRhUiE3gbLnYvvsLGHIRTn+zdbpEk78k5sIFCV/BIAyR+/MHqQVOQECq5kpn4dpe5aJfbbdq901xWsbu4cE+Z07xjt9ldkL5Ep15VUqhZtkRXULhYp1lhNmlWLNYVVHu9ztx8i9lcaM8lnGL0NwBpeI5cTOBSY0aOR7R+qedzm5QKbnMDX6Zo4HNaVHJeY7/kP2YKsZTHJln5EllZZirRxuEg9m8uWQEFaeOQ2HWHLp4n5mSi5EP3goJs1P8KKyNDIiL/j1yEcb0umhsDwLppW/2ccssX2xeFix3h+AItee8dhPx6W5KGECGRHvtMBkrcN4oz0hHCIVpJ6Wmk1FQSAsGGhzo3HdYfjnLuSTWnmsDliPm/xHeJj2RoImdinXQdAm42ewewUM/+ytMOxftP2ZnOUsTbX4DA/4AxDB/O8/kB8U/+5zNU7AWxxjTiBpDFwojrsgC3GD+Syx3JPveIWakoX2c6MkpVAcyMSVPkIsq8PgDzoTIoISFIyZcJeQwGrkcGmLUYdB+Fuo/F3kdnlCHWXAfFPgUCn8bFsW8R2MqWAWJiDPJDWNjGrxsGSInRjA/h4APpbdWyQJnfr3WHbEQVEQlf2NkKOrGBZHjGksf7HDuaT89RA3KPGnL5GAMPXEmB4fuP3Sd3LLAmO3P5CMzDjwCtFw8WBOUY8cnne4iedMhCO+TH//BNuA+TBDPWSDDix4+dJGgSSCR8gDCXVBr17OPmfcZXfb0HUG2cTsDMVXuvgOiyRSaskPnL9ykgf+cbe3UZPwp2IrjJmDT5tgTCZmNDAszvWckwhVbHzx9Gngn+ta1LrUQ+1F9rM1pI4/GvJJucx0yv5UKkic3GZ+ysKuNSRwVy82PzaiIkkf7rJTVQ4wDE9GBj/MKEn2yQ+dh81Hd3A5Us3KvTN/vuL0aZ+1w7llPR08DHp+svLj3bQNqEwxbaxEGa2Owv9ZI0ANKohNdzn0HlRUc79KTjpDbIgI5AuDgmjAJh4sgeUDBMrIi1ivxK6AkbF5HecZAm3u4SxnwcfDSUU8Fmg8IusaVWjBWtTi5nlXvEdD7qtjs6Vb5bfqdmnb7Zd78CL73nERhiZHcyDIuDQa2Iki1L6YjRnV+HsRRxfkx+m5R6Hm+9l9EhdG/U02B7glIItC8L16+MLgnVCm/i1vjw0vRaaLmj5VUxtS6gUhuOKEYBFQ1igMWASBqwH+K1iVltftonFsIiF8FCW4DEbDtWRvOpgFvMd5jg5Wh+uMQMl5jhEbNbJeYVI3pscUM8uI7K0sXpQlYSGFIJutRCx9rgroTxLninbOP8BXhweeYJwtmDmRXMHCumi5mAFi7VIihw0i0D4bzBzGGumJviuG4UzprCzCxdmjt3a+Equ105AplR8OxkMTVxlQjrZsO8MY4iO2HMrGBmZAuRd3perPX2n0OcK1wuPSnh7HaYme0XxeFLHWvXlVpeGxbcaZ34rJcvjdn22MzcjwY0If/ycns9Z/QzRscfzJdiC6/mjE5yleqixfVGKXceLNW6GlQy56wLgRNKF3SkEc6Yi5tXIhc4+Y8f9ooqWZXpHDjD52J8kufuPxTMjLR46FVfFdGd3xgMdaxK8Ky9fk7UIzthApm3pzbrzXqzXiE57h8ftwr92IxxG/xHDAelStas9OPWsyoxyt+/9Slttbpuf7WxMgaV/6aNdPnheX9Xht+sq1vSL35FJRu2/+bp17jjTjgEHIBteznoYDAd2oUOobtScq8L3JG94qb/J+0ddM2Le6OERtCl7AoJGMcq04mSq+WMgAkjVBxMh3ZV2w8pueMCp7US9hHklaSg5f4jkja9dxyLBAek0N1R/DtB00Ez3xjEgoJWoGuFzffpAuoeseO0WxNBKKPllDOMkFI+RVr+EHWn+OFilHZYQTq0K1gOSibR2QoZsSiwrdHrWvqdAekgX9K27i/eNEa8PN4Q0XvYNW/3KwU6GEyHdgXLQSn5Wk73vYnFSJ00KoFNZUAjuAI/iGJAukMe4n9NY8yAXgdrQNXV3hS3voU7SaRu3m4xCtYg14v/If9fBFRdUnpaPdX5jbPXCNbQt/6+Axl5ftZxkkzzEoCcJnu4VqCuhtgs9aokMbyThyyOii6IMtbTV9MuUNN813B+aRWLv2QIOuCYs+K3D/MYhyuvxxDfZCSmURG2hWbhnQ0j1ICqgxmQHk8bPYFSGKQv3tPOHy74DO2Hwb8BtAe0gNt9ascT7aZtxuo6h1xTTTCg16gBVQczuPVLcSfWF1R7xYAasDUGAN1hQA0HfPN57rQXfXU3IMT/V8Cov8BbDLiHppTbJYhQSxRTVLXmaeE5KBz84wkqUeB6KzexleJdqyi7TMgpJLr80OquQ2Y74GudY18Q7xnxHuRRuOq4jWy04k4rVS9oSSWUi40uaIl/eLAC8uWRqnf3uxtmnQE8iqFXlSKhXK20KlmlVFxrLZGSy4Bn08ZHDVrVK6uyV/yWq0VUHBrv2Fg1dP/PvLsn/rM1rna3b/j/593nT+s8xtb0/sJ/7d9Z7xIDLaH3f+yb41+jmTOtP/lv/SdX6P5Usevc5eP2/05gH9fGHAuBibchPIyPhDv1v3z3P23/TC1zOMstnvLlTJ0P5y98Ht1G+5FcbNTRz2lu84x/59WZ+a/khP+djLHMbc8S3p5nUxp7U0w6JoUkifMi3l2YjQrOiWpYJGS0yIVNDI9AFujKX1F2sTWq7mtI54ASxlFlHSc1jw7sMOfna4vYSnjXsBLXYk5Rk9Je0wo17CHnoU80qbo18QNGKcnfNW1giETwKNhF664asGuwHGK1yPYGPALehpcM/SsRSAUJzlgeRRWNSrhRAy6qqExoFiHVHXWjBMbW3fIm19qdYD7/82Bm/vDOsVLk9/lOOtXaspPpFSNfKmj/J0DuGYpbIjlzRKu4rFfTZK1GpEe+xJrGZeFdNwLVMkGoEF6vAgdZhM/WP9vGMgVxOaS7lVFyaoECYCiQvVWKW0mHCJ1WLKbl8itq57yMraTIrCc9imbae+EcguJAEr1uIb2eEeS7IzJRR2Kl8WaNFOXEvkBtn+aX653z/MJ6BnEF4iUM3gzkpAJ765bXiV3ONHB8BnIF5O1M0j3DA9AaURs8eP+EYokcjeyCMpWU8oiQynsrvk1YGPumJdMdfrAyGRwwZ1q0FIzplCCXYBg75O05Upjn/WXIKHzKIcmwd61IAgy1OqGevLGDetqKZyOBElRyjxDK2WgN0nMBTT1hw8vVrSesZX6Hem4nbRoY5v/5gCWc/DS/8DzuBaxMH15NDwc32U2mT+XVD2pLfe+2we3xS7OlV9305sORNFH9tDJukcOrTDfk8uJPPK5IYUdI50XJYr3PBeMhVb5erpR2Fp18ZTtxVNN+94ppyJKLGIkOB0spTKxTQ/4/lIGNoQE2JxsKkh7NUcLoLsItSeJwb1q46B9Jy4reQRyuYgJN8vAQfhR2E+ffv6atFh4+WE2cQ/FDyg7KNJUAHSWOBoxUVLsDVANNZfEqau20ZkWL4serk23n6fO5Nl1kWFkz3IyjOWRIWrn1KBzLVUK5lcFHBuSsEYhF711DKaNa7fQlbbwZbd3QJ5GunCpTw6ThnNgSZuZY9JR1t+JO5uakb5kz9/XeKlj5ukSDu9n+pB/lho7e93dWqFrkCg439ExWf2v5IXqre6r3Pp9aXy7N3EUypnKJh3BvqAbWBq0c7J1k3casF7ee/D4NSZPw0ACySuFOIBnztAfKtnI6KNyYsFxTd5FAB4cOZNL9A2gIoENEQ4GxTthiCcHcwAWkFgkOLN1cckuoNiAUYgIMO7PaJxk+QQ8OZCApQmSVQcJqmQCfjxmDdhPEqzGKBvJS7toMi1G1CI6ilrUOZoTiyE5+DY7Ffav1SNuVT8n2e1BjhGqyVboO6IWhMQZsYO24TBXfBWYJ+5yePG5FBFMbN7CPohvunfaOWjvvd5zhKPMsSpnQRAfjGHPtLSgsLrDCDl+w+QGLYeXDhzdqXJgQjJ20cULYj/u08lwv90wCnWDSUeU/+JYTT5NaIxa31PUz/DhK/SPZonVAsUF/crRtnZaOkVY6rKZG2SASY9JjJnlCu8iJ9cwnSm4mXnW8hwNqREM+fJghxGxqfcLoBLsTpt2s0VOe3uxou9sjIhxaGdXT9uhi7o+rLW3JSqteFLe7ikpTbX24grYSzOeHgWdtp7gbUd3JxjKvCFin9VEd4HxsFcVUSSMNaCDm1Txp/FUGF4SVCX0Xrh6B1WhRpPNkzwcUD2Mr9MbFUYspwRuMH4gJF+rPwR9ExEJiOi/FIGEjLdgSYHdPgoPANgK0D/6OfZXUOwavsh8+ENYlsY559TUlXilZRpA30qTByegwNxCE6owwlVaMnsHIzs6wiiK+0cbsNxa4gtgykPU1M6779M95WqS9xva2bPI028nzToNLA3t+Uel9zOkwpUK13RGd8r1s6LYFrCbxsBMwyu1QPW7MVyryUNw1D3g8VyqchkY1mg226QS7SLd6koRqNnV0+mXYvSt9CLmindPMVpPkiF273xHNNjRrOsR8iw43L+8UxSGmjGtsMSMTYxpnvLINe1LYsCdg2AdA2XSjbII4fw01NxVzLkTNHQDsuYnBpJeTUeha5s3+4J25wLxb8kFw5xP7a0TwUXuConWBTJ1wD0pBi7pRGY2vEBISF5UQJRNPDhqewZIxEvIiUQ41s4rKYoXRN9A5KpkeqtYyB966V5Pyru8lbmArfVD02Xl5YWYki5drvycKUaGGGFIzNdsqhUcmYS633iPOOs63aU2JyrC0e8QIgENwJjcRPLcmnr2fiOdbT7xArLnVlT3cuxVsdj6wzSyGM4L9ejE9sy1baUgrjXb0BAWjrol+gcC8y0A/prlc6sDrdhKEoaplXTzUPNsA1evFOsMZVcDCe00FL3Jbj7R2YO1REM/ZqYdwIV2Gld4vmKhUMJreNlRJkcoeWu7VhcuqJRY9pEtSE4sLa2KlgnCyheE/PaMCPN0soO4cdSQLNxActqHwpNsvAlruwEliY4w7bLIabDfp6pIwlw1Et7Bkk82a82oJxyLmgaepNwqAm2S9udDA6qEujxNFiHtcekLtaLvY3bBi/KotKaXr0n08G4tsZF/OPe2AD3UlH3tqHUQu4fUBZVhJZu7FJioMXsUUV5M0hmZXtgnnTlF/bU79NlIdT6M1PNDs30GDSvpEyFyio/GSP5E3T0ZyM59vx17cdgf2wbiPNDSwxP2KtYnT9+Mq8LKSf85zcGbpEXTtkV71fv8e98m07VE2lniVcVwQjbZEU+UqBGS9D+uISitiaLxX+0K3LPHjBFsdgG2qzVZntzlar2jabU1zYyaZJ+RFk9fB88RoKtcGIt70JiPF1If0afyHz28K24NBT996XcfsdICJ2TTAvNDebXu2spJ8MZr6b+iXangvZXSeznY2Yl/5RKy+2dy3sWIajorhuddNzmpQwuiETTAqnrqqrRGg3LSQEiA178D9clkzBlGSPlPG1Sg5f3bIc7BltnaM+qa31oZmrXOhJjlhtaM+cb/mQlo1UaChtBv494Y/JbjX5o2ZB0sTka1vg5Qm4hAuR1Ymnwa+LeamVkJ50kDplrGftiLGknHpWcH5Fi0srQbRf/UaV3KaYj++o63WGa0s1MEfec90lHmVJel7kBZS+17XX5WoXexu+w7YkHrWX1J6EHzVBRA3PKFDKS6muJfLRKFlVETWTtDBryFpRqhYUlqzMScWeI+mD/i2lwadTSEknppUuPH9LVfY//X0pm0obVdSqfFzlVZCfNLNyG8rQ57kRrQwDaeRG0HyO5i0G1rL/ThxS5nRHvtSB6Muu2JhtBtb0aC0v8ddMlFqMJOguhA6UdwvH0/8VjNfhG8x44f3zO0TV/FQDPDOVwOIkiqxhiFwzQQi5RotQhrtdy9AhWrXqobb27eJvsfPiBpU//V2uJJMSJ91tktEUU3VejnU9LoytiYMobs5HRf1HD5o2eCMnsdelOnKak6PmqJpz9qq532OeWRM/Jpwzxu9/eogciMs+UHaifrWPO9acHWA2Mu9Ml+zT4fM/SZLn2zgCsYXKqgupn5bMHxz1FguDPEB7B/rMocpKTzEQqKuWgGzCr9O9yFRC3AVNK7CIj6fNePUA7dTjCV46GcxvYac9GXGs9r1zxApkDoa2/maR+lwds/AFYUWu95dzClOa0uzwVO7kxvihq1vanV3CD2mRlQkYfrxdKt2n6+gkedsqGZqE31alcIT2w3tOLUbjmTj3Xs2EsH10gCDsM83mAnxjJCo202uDoXRF9A5aiDSdTjs16IHVC1ym4Zum4Se0TY+5Qd9EXKoa/c4MB317SGwYZZhEY0ibCD9OTElFCbZWeD/86XnAILSaZDu2ql2aeilttCbILzhRrWpmqD9jrTus1vuRGjnKKj3/K7L0Z+bGceDRY237uyzglJvOHf/9u/uDh+Hb6RTsSrUoxO6K3f+DvMttM1C29T6T9ydLJNfwxjl0Rb9cSleh8NGO/JmarKmNdI6g3CWmPXnG4+YF2bPJ7f6dE/Esdto34jDXu8q3unuPGPv1tadEZ69DFcphFS1bEVS9Dp2C1mpJBOLXmSIcdQQCQ/D9SCrXZRpYnkp+5bnI7cg1Bra0LgTBjFw0S4bGKckcxxdU42gfYdDoZ1i4o7RpN1x1r3VbOVAAkK6fmZSBihKsZaZcg6oQ1iPYpYKbqsdeYZEK0tkjZ0T9F4coiWcoiQRzZwnsuu2w/MBt9VlE2gJfJDjHlJaXOjkYIQc+IFjroHdYUDq0f2JPS63qc1702bvdjR1uCUOzOGY497sO5XblS19RC+i/2rWUb9oDQ7bPjhgr3dWbRsbnJlNmLPdIAnaWgh2tW6npfWtcXHgT3f6brWNpdxbGzfaMrieDaj02PkJu44amWQiBjcG43b184ck61QCNow6snVfLhCLUlv6i0zAL6kbLyf45XpkaWlHFSWe5Gpql6CRqN2hSwOtNsDhh78Le42hWdKD1trBqzq+wEF81tKcNa9NGoXKEArUqSlMJ6FBSFdxYvTBtRt+9D2zfzvrXZ0Dyy/8P46vm1/f7/yjcTtu/nWKkZrzXLu1lf+15Zk+4YBWS5wYP6CgPRmCpqXEjq7zE+u0LgqKituuIYPNNlhQRWpuronmwTkrVZs6nfVlrphnQI/BS3k/8TxxsiX1SOHct3K34zDPy1AO+YKUDjSG2xVsAXmh15eXCvB1c0LoPAOSedl5dzZoxVIPcc3NxhNV6Lrqx5lSyAV47H0Ic9U0qhF9hOjKswpS7ZTqGuVeHJ3qtwVMiOvQWFcN2hPC8J2RnN7JXwAdeRa9izsSrbF7U0bfFpRCpIaRad6QvmiS2UCkbipzm7Cso4zlwRMW2yofuw8XQWeEl8QuNrxzFfW+p2ESH7DK+Rb/AH0R3Q+zYZ8PY9PDYf04j8N+YsAQ5hVutqO6J5fVWHdeWGXJV1XuQIljmN2COrn+CWIqI+yv1/yVUIvyQBG/VL6JQhbf4YwVnyvaHQS6BAbaNEivTWeDrumWNEX21FW1JNtg90UVi0xLNBEVyyKBilgVo28DxWF2OPvZpMLTBX1Whd2KuT665LS17y1FW/B1Gq1x6lvFcX2jCoVm8eOvvcPeo976mO+hUVEWvRrKrsaBdWuaPoqD2yS4Pz9M3GvgQ5HRDDKaBe7S3jU2PZ2JhWXoSLr4iTZPfWolC3wFeonrmJXyMbJT1zZk7BuJnE/aarNON2hZl2ngshoEk1rNl/phNiORpf9vMgvfDXd4yZMjbYsKVfgHBPuogLJJyu4ZNajbMsLBKJZdM42+zROHJcQK16tUC5gcp4aFrKeIev/Z7+vjwfeEz2/KI4IZbA+ld3I5EHd35OIwoFpm+Ffzt0e2d1Kj7AG0D9IHF3FYjBnLLJqJyZ0OLTXLoy3N3bv7culH/+m//a//52P5Sr6X3bZOFjVLyuA4REmS5XoeGCvpRRIw1QVQVhEwTGREPSA9YzsZcHaNHeE3N1xQhMym5QokeNZdTqGmcVnUQ5ULQBImlkBOVKMuTLB+g2LvTjrtR/QM8xCSqvbev++4H/3xrOIaj9DnD47uAn6CV6/lh9JVaoDwkubg/6gUj9mUIvgPY4sOGyysfyPgf7b3jjjxP9yL7/3HdfpPZ7COepYwcnbBLmWf6QPTz0phA3f0UoZHdPX96HP/7JX5TVz3u6NbSqqmetAVRDrsm+g5TS+4lZROkCrSYstMwC5TSer8BKZ8a1+vHbsd189e9bd309ymYaw38O2Ve+o7oCSNMYL+HKBr7eIgUpY6IWket9vZEw4saSBes+gJrVkYQtJU+mupy9nR9EKXgtNsm5bXEhRGVUKpXZdR+KJQHtNnxp4f6E0A2Op/jsbrd7pl/BvO/wLgzbeSP6dtN1r3139fk4VgwvsEEIMNiJL9lR5xwbqGZDcY4W4Rqs8fnl/H2HkOH/NXeq07JmGdgh6VSgnTnVqYttxAeVfaCUETviFh++YLBU3wUMXn2nf5tL0SgnNvWUu+xsTnjYRrdb8hCGzrgz5GNmyZBKYZvF8CrngwvKZO432VeW/YvldxeJmcbuGOUy+JMnQhv6uYnL/nxd2KixffZ928Gw5xoqRfTWfcyk3hNilU9YPE38z7noa3JPFca5qYk2RpIrKUOdKermH24rcNwhE2M1g2b7Z1GSLx+wuwqe/29pEcKAwdg/fzxBV9IPgWbJhhdXG79tfTkJFmwXomUMyNW2/H1dWKgD3sPLd3Ucr0LkGatc7qaCvjvVF8FwRBP/ETgT30hxCI4Z3wg5ZOAsvlXAtUGWE9BRG9p5oPvwqBBfKZD80OiOqegElgPTnFZnKoHerNEjktn80TtiOCvVHvMV1bS+EDRIEWvMFZBBbQgNca8ZQuZfvZvfXGCaZNHBJSDGzNUaPWeEarcXw7eJny8VIzONAmrpb/ufGr0gI4+V+1VhpWgQCQgyMsNwIwHTFto/QZe09Iz6j5nksejh/o3rMy3o+GWhCY9cs3g2/+iB7+Q4+b8u1zchwPBQkCnIRWNooaGATOEA2J4P+MO/Qn34nhMheKckTOi9ssIJhV9AGM9u8DI5x9W+gjRgISLnnEE4kLeaZnr+NGXfM6wRwijbEs3OPF8PxYtwq750gCmgt8APXKYprdR0s9i6BN4j2rd2pXQ/7mwByYa07R0LyyMCYueAQb4SHsRdMhVRzsYY3zHBr1GVAK8yAJSmATGgOLxDbAMjj0UCvM11Xf5f+4kGYl0BWvtr0MJcZQzA45F6Lb9+JScXAAiixfnyGKuT6CJaJ8DGL093F0NMwngMJinxAW2OwTQWa/T4zudD4JTL31mUNKb3pKoexvvHgFHWamzAt8BKel+Bgs2SEfR9Qu+ATw328+IRyetU8EzfP1iTH7qX0SMvISnzlUX67fnxTaLxXowE0dv4bE9m0vNU017OO9QnJgCfzzdKq5qfpjUVOng9pgHTaDSg2Bgukwun2IC0V2FrYiKzGAEuMEWWtsCegE/SjYmAivDsa4gDKmI1LIitPGwC9I0hmFcsIOwT7DOi0y0VAAs5WGnsRQ6zJGwVzjoWvnV6uLXC7SdZ6xU7XzUSWMkMI8DWpFydqgWCgwScWU2RNG6zZdF8ns7oQlCBBc6aVXhGb77lT5kxJ6vQ6JyzC16zTdzQrR+ihrXOUqNKriYFeqRqIRzOJgCnKDuIkMhhSMUdzfYyIeq9pstZIZWLMc5i1bBhWdbG5us9nyasawZrAadT6yBQoPRyKNknHOqqwYZstWU9+NdrXc2Sq4waaJMPDodNRyJKJbFFW9VslA/72qJW5cH3JuNYdyadh9xTrqHtzRCHMK3M7xGieSRDaRdgNzzspjYbh055ezJU2qIRyLUodciVpjPAUPt8Uny5xZzywhjtzsLSwio8pEjXXWqqHH3UbcsSKe2K8ZaxyyeqEUTXSwkIYw3C4kEXO1LOnmqiFz4RY/o6rkDnGujH037K6UKRFWOZnBqEhG+QtKWUCWLi+bS5RPxKv8eG1UMj3JhVcIhUPF5ucOLZlYcbDkzNwCUe3B3ca8bLMlImpyDyfNzMhOORzc+qO5foZy9Rw60hFvp2sBJFaVxvCkI6PlTZ3X3xuo26jKRoU4KvXwiEzNll68DHbGBSqd5HR3N8xUpIs07fVgzPsA93C56cTxwJS8kZUPiTDVHrt4gvuXCc/5kRm8vS+AJNCwNpOkeOhxQXhSMFnBp9AQhfVnfREiAUovKqQrnnnumxdFiykjYKhiQxcHJL4XOkGo9nxmg3NDuRlulyS5hXLk6uqzbojY1WKRSlevfO/TyzNDLg0iijulQ3bXTJOo1/4mj4oWFi46ho/hOyYyQm8ixuOIhJyLO0rOqGiV8dggjsB/ARZEx0joQ0zT0FtFmVWpLqvKWNiJSXwv4uLhJ02QzJSlCatTn6jaxCTJk5KlSJ4yBSVVLw2WXTY1TQ3UGjVr0ZSWro1SjRnmi+F06eUwpC+319q7I69+I8tXoDCDtorqsMaqTMyKlZTLKE++T1k6anzW3mZjV8rRabccd8JRdiIBRIkWAyhWHFBOLm4eZcrRvxFMcKJ2+5u3UZNmLVq1addhtk5dus3Ro1effgMGzTXPkPkWWGiRxZZYapnlVlhpldWVMPikjY0QzhLsJHCW2iZ3bGJBxFZWa6zNnNQEJplYQltXvoLW21BMG22yubvuKVSk2BU6l91wk5Ckc7bYapvt2KKMneX/77tbr5TYBRscaI9Re43ZZ7/xLDVqcpWr+dyALbXPXhdNNizaIsc64GBHHHa+Qx1i5n6HHXG0ax3LXYDNNtpmq+3WmeidtW533AknnXLaGWedc94FEy665LIf/OhKr6WLNc87dT545Y16L731vquuofR7Bu974KFHHnviqWeee0HsWt582S+DFfDxZJ/KvaaKY1/o0S+BKTg/DM7Mo0JEuhLXeeMYCGkgMiBa0clnRpViiLAJp/5wpA0tBu2axtSjm5JIsQl9s8jtvzm6jKoxL4FY8+1V28VTjXnTJaXdep2Z4tskq96NzxvkgU1jMqQ0gtYyqdCT/9MQHvdzoiBm5XVvOVMSP6eQ1d/fag+IvTgz0w57/9OR4vS+e6i41/A9fmddN5Bwrxm3m2i7giZqzHfPD6i/BzxUza7G/GxJoq8Uaoyvm6KC3ZCITubBEPP3/Xx3EA1vOr8Qhe4wheKbKnh8EmuxX5JEPDlL50NUxd2OdY/5tG7O0r3nxiu9CSdR8oB80kYQAKG4BRLuMqCcRKmCVyFTpLCmXCF1LgO7aoEUUrLy+0uh/xur7n9OI4qaH4OnRG4q1oL7iFTNCwwBod0sf1p4hxGGtjVNqRhht4V/j5lS8V8qj0OvoIw39OMU4MD12IQLhqltqEUMAW4YWnDdUIcY1pcYCtQwmxrWmRgKzBDixQSYRYAAA1owIA4DAgRYXwYEGFCbAXHI7dMxHWc3aCBFhhwFAiJK9+T02TEe1wbQVANERERERMScPYYYb3op2nTj12nGiCbX4wEDViVd3Z2wXR2lvbyTdnnySIxneZNyig+IHhc6nVyM68Qsu4ujretMz+eWdF3TvDNqd4hol9GJZkyzi966jygXJQez/yE6ko9EvG4x/u5sbTgQUgwKjZea6HWCk8B1Jy/wqV52z3FucxaL4n3bFZSb1nExedZzIM95o6wMVYzk+iOKFFq7qCVStBEewdIlz4NRLt/uvDzO0gpATOb5HNA9ZLk0cpn5/vs2cHonI1KET7aOjrL91G/7AZbopFnkB5wmG1n1WhkNpMiQo0BARDnMnENhmg79RMtfBbUFUtBECOBvnX6Mswmu9sZ+njRGYIjfIvH2q4xFbp2X7xTs6gjjsVvOLue1opxgjSFuYLfEtgTg1CWP1mO27TCEoJglyxo4L0b4dTCg7gmk4xONOKeJB1kxM85pUm+R+4Ns5d3+BkvniHH6MtYrpRlCq7nD+YZFT4qxcOUL3Duwaqz4PcN77wff4o9fEuNRG/XDnpNzdRe8ntZHv+f1WkCz3x5L8HTlFsN63Uvz9sawc9KedIIMSVBBX2peamUyS+bJPF3wC2HRL4Zlvxz6n0vccM/NrTDgHvf/QM9lKOP3eM9N0Ofb3FoHAAAA) format(\"woff2\"), url(../fonts/dbscreensans-regular.woff) format(\"woff\")\n        }\n\n        @font-face {\n            font-family: DBScreenSansDigitalRegular;\n            font-style: normal;\n            font-weight: 400;\n            src: url(data:application/x-font-woff2;charset=utf-8;base64,d09GMgABAAAAAF5oABEAAAAA5vQAAF4DAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGoEOG50gHLEMBmAAiiQIKAmFKhEQCoKqPIH8aAuHNAABNgIkA45kBCAFjzcHlzwMgm0bRcsHxNNOIL/uhIrQ2v76OxdMN/cg0J0kn/AkHcRsRAUbB4Rhvo8F//9nJR0yFNItgdKq6uz2G010EbKgy17Rh2ZV5TbVrffso2ofI0epbOOe2dN0EMzzYsnPcvK35weKLjALsXH6Su7Xc1rgWPYF0iIBmzXaNrd22Pm21/O7Z6NIyglXJY5X3P7PyH/SaCLkSQHS/UztlWLjsLS43Aooth6EYcSL+DY9/sfWx4gO41tu4AtFtq6XLQIblzGSlZMXHvj9fZ1z7/tYmAlQs5rpCIUihbhtZvYN0Tbv/sHAJiwUXhRsLKzEZRuLDhdtZGDkyiisKUZhbKCLcsNe6wBss1yYgYJKS4UKCCpKt5SBiiIIqCiK0RPd3Omi3fpWeeEyzkW7u1vc7ar+dtHbX+33urt3Sxd6GMCS/KQKeO1Oo0m3LEVkXYSN/FGRqhYY3viNbe8ILUKoAUJTAx/1bvSPDXLz/l4uqa9UbR3BlGqEwQgk0mA80rFUH3v53/Se9xMpWJxE+BDLIwxOYwTlcS45LHcCT8uc9XcdlMnWU7F/r1M/HdxehuWX2/836RWTUilpm4wEXCyfeCpu45YA+Gnuv3cIzlAyyYQvvzxehHwqoKxbIYtC9tf5rlzvFmo60Kgtb2SFnpWkSM8dzXxx+u97SJ4ZPkruG2NEXbTlBYQWMbf/w/i+S3UuvstYynbnRJkdrC+QlPudIZd+FxYwNCrBBlUmRpqGpsMTVMCJnfYnu883iee1BwU6iYvrUqqrrU/uBzS7mzIlBJU5dhhvd86usmzJE43JPxCAoq/1c/N115Smyi73fyA5yoxfZmfnV/tpAHH8T4TMzYagBCrAqqC2QtXJt3eh+89pzggWZqQCXulIcDj11D0Fvv6X/Z0ojmM7jQrsLUt7tN7e8EoMkh1gv3bBRUAmXBAFIseLDv6/lt/sf302pff/blZbyDFmZqXBLj2k+ZcmNXGaGBVZhqTQGEFhDIpCUQhr8IYrU610G4MhAfIMIcs7T5038QLnHPHeh8YtZmYX2B0MYUkBC+lIkDIg5SHpZRxA8PgLyJFnJb2xJiJF3RfJc8Zl73xqbfSV+8hlF34YW1v5BUn8+T9RdNPvxv4wwQWhiioMpQgtCNrJXfcYdF0SyqNuMOrCYOADHHkswwEN2PZ/qlrt/zPU7gy1gZBdXY/3tin3uitL4M+AJP4AEgIlkwAV6cClvYly5CXC1LsH25diF2K5RZljte0VVXP+8FfpI5dzZHYIIMHotv2rb76l+gE2N4fki8HACIRwsQwjX0raajz6To/hlgFW/eOoIxcgLGoZzrp7lVWUKh6CFcp2rZmzVyqmIaiHSwlZS1p700yeRwAl+fT/E6BAUQSiwhXEg9IC1lFbwGYeCzjBbwFnjII85A8SIgYkTipIOh5IgXKQ5xpA+PggbXpB+o2DfPQd5IdpEGaYBZqlPNRGglAggOI09j6kz9cP6VzSjF8szeXCASBdRABK4EC257ch4Pkep8DajzADvL5dfAF7vz8/AMc/nx+Biz/iS8Dvi5sCT75090B41FVIvIOw5mBc8zCtEcxrDG0tANYiyFqCZS3D+qjAwXx/ETknEfEVqWRTSDm1NNNJP6Ob02MwWGSTQy555GP4OT8BgGAdjFAAIIDagf1bZH6WAgqI22vbIYIswF7PvIP45f+reOE3AfgPEaGow3TN2CzNfi9XGfNlgEXx46QDAUXR/+x6YqDgJDRDDm2dGU74EUUaCMWqeuoGwMZYyj7dYQVvD8zwL2MpJeNxZuZnKaimsd5OL8NMpnm3VoMi+XYecs4tz5MfT303rfwVxCwgqnBUPBGLEnpY4UYQcWSrlFIOQDRdX6YjazmaO74pWFIkLJ5Usq8Xqlx5tlbN6lQ/GGWaRdbZ5bh6qfsAeeVz/1P+Y8bIWWEA6zqBSVGozSgZu3ipCFsSj+Wtam1giHndFmc88ScU7Wq0E0PTyfViV1JPK90+6HFmWWazuu9TX/uR93yt/Z4HABWML3DcGQhVcmgDjBnO6/yIKvA/K40i6ugC47ol9rjinQJ9j8MDsFiQXM8k1vMppbraSDu9DDPJPKtsc8g5t9VnPoLs+8pfR9xxEB1ueBAnSmlMj9lchRXu64IlrjwrW8qlWfrAFGscg3uGE/heDq7IZcUT7iW1sskKVQ5qS3N14rBEv42maaovHliv3Trmknte+czP8D+/kMHxszWlCATlQPHKoCb1vek7hNa0odOf93hP9J7iPd175veq3qtvQaoE8P9HAJf/ngW4BOmFF02zoOPGfMqD2NSriM1wtLgtvXfW/a5w5H0bbF/xOTfb5pHB1dnAaNt9HzbOFuH3VjPMvZLZ4/nmZ2u5etcUS/LjRWitQ2utsskyNsme5eo6EuRu96641n0hr882F/oVKzZ8wjy0bcBZbigtyG/cDDeK78Nm29rfKqKa2/loyrRR79tCKerbzMeqfEorTlhSiTqvYXf6aABzq4lx83prfQN5NNZqK7nqSieOHu7MeWfeHD0elo6Z3P8SdX1AzovAdVJ1vaVujEZblJSoR9LNYfnuIuToZg+O4xVtMhMmqLgHaubruq2Qr+ws4455bbF16ysVUeecT+e/LrCnX5XOj54LupCUNUTa1Uj2XCNgRCM+RtyjCC3Xdcqt5SZW4MgGLrFBG1Y4KG0FAkAk90IvFpuTJKqQUDQYP897U+DPotgKARFnfjeTThDLxjoRmfkxySTUtQL+NoLoDpaI3gy6dEhzAHPZRSjqQytEJpGitGIUuEXyGjB7ihTJQWGOiBlKW5KITOJRK1SaotMm9x9f6eiDrzzPDzWJ/kW7ymb1/mWh8PYetE4vP/W6sdoyz6utfcgYSUM3sVhDd5UIsGx1lCSpBkXnWVTgm1g5LTWUiyGFZqFfM3GmEaVo8p67VdVWhgI/U5dIzCwy2kTEhK2KkkQVkpiIhbTUFPiHV/4sANxGYC6COxCyqjpOqEr1BeTfU+7rEd88M2vOTCieSyNMbJot+6fIowoBUBYQviFS37bbavQKe7D1ttf1ev2gTNtSdgHr1B3jdmavSzpQfzLPr1RtZFalnluLFus7gnoNq5/gD8qhqAq5E4X8ZE6niquhQJILC5JY+T0/BNQsxQHvK09ufyjFQbU7tXaHijwliJFQwz4ucYMHBBJFEnnwqFDj3rT6uttBEEuVhYCkonmCcvvUhw4m78+XF6P2iqnSYcLVBnaN2vQZFyZRjjI1u1i0HwWjStvHCpUrdKrwcIWhlVai7pKqYTBly41OJZeAfhPCJclVrvbE+13uZVeni82OOxm9Kk3aDVgqQrI8Feo8ZMg71KDHjP15lTOo5tZh0FORUvA8U5/krONQQhOTOQdcRjU8gob4I5Uqf9DMcV3gUUbFYsGTgolDs07DAkRLU+CFxhzXjRQqtOiz5GgJpQq1vLqMCBQjXaGX+PN1Iw2RNgNWnCylYlbHJ2RUkFgZirzSNF8XMpDQGOJwtoxFPb9uSwSLk6lYpWa+LmQhozNibTk1K6cWPcaEiJelRJUWvmYJUGCM2XCxgoZNg1a9wkIlyFaqWivksjPr13O8ytC8dfvO3Xvve/3vRJ1wGwRIUWPEjpcwSfJUU7u1sachc7acefIXKlqi9MxdaBtZrFK9Vt0GjZu1bPO9//906jx172P9biGDg1BjxZ+S/fedpUyTIUuOPAVmZKd7KFG6XMUq1WvVbdB4znbVupZt2nfq2uP2/txz6CvqdxuACgMOCDlazCfnVm7zgyhpitTpMmbJnmt6b8eyOlC4WMky5StVrVH71bvHHcMwad6qbYfO3Xr2cf/+gfr03wYRCA4PMUr0WHGn4InrB3GylGnSZ8qaI3e+GXyebyFSvFTZCpWr1axT/zK6KtMWrdt17NK9V5/9/P7/m6y6kMFgIUCKGiN2vISH5NjJU6XNkDlbzjz5C83oi+5RidLlKlapXqtug8b/bZY1QADgqWytMODSTdw/RPBIIT2fMm6FsKEZgwVw+BDWigihpFLLGq0S4XZu7w7u6B7cyT27J3fvzt7y3RWi9cxquLToskO7PqPemzDLP3FQHpJp0WOCw4knBQO7em26DXsiVLx0PBWqNREEAZhvCUUrRgwmL1KZq5N6p3yVurz3C3kEG2fLZ1/LRhc93mrXt8/7V0TH3p8rn97Z3eqrufYbv/grusYT3sQLwFV8MXhxetm4kW04CgWMxl/VDBkPTpNY2oN85iPvGUfMW0YZRpgHkronmS78V+ColOJVJ6owMKS+f3VdhIZjWmWisdNgNVR2y6PddXGqf+jfRaBjBaHDgfO3ez3f379HORrw9GCzGjz+S6IAEnx+/J6uBWkw72kbur3H2YZy72aWIdk7n2kY9o4mH6zvtzv13sZkg7q3PPZA782NP+h7k2MN0t4wkFmCPTTadyMARK9r4E6092teByfCe9j/fbIarR7E/Ble9UyRp4GnHgoNkwiao0316V8CcF0rNh1d0rxNS1ibqg5ZsynoyGhQg3YL9aPcNkn9VH+b4Mqigf3+NrxXjc1XLI/JTaH7v/Zrdvnl10eblb7/9Wgz29e/3lYPf4Bmo1878Zng2w5nvb4zfafA7NXj2b91sN9iCJDRsAoLp2XzzAtwn4aGalkG3Nb1LJEmRlaG8ksO6Y88yR1w2yP3q4pam5omrNUUzBL+LZTEI5+ytDAYeKtNipVmsq4p8QOiT1VXmulJJWCmz80OnkupOjTrAS1a8f4pVvxW94GOHfnJ1+UsG0E6iXz0hSs2KRSOAwFBj/h1xbiIb9I4+kiEJJfLqFOXbj169ek3YJBwjoTeoW/mYv8LjkcFPORerUiy+oXa3N1cdi9a2JLg+RmlvE3/oGwRHvyatWjV1sKEnEE0dBgdDLr0MLHo03dhIbEvgwwYMmLMhCk2M+Ysrq6lkBiecgAKEYhCHMRDKSgNZaAsvCCgXVCnrs1wpngvGP2LaKQkzrbQrb+rRYeGjk3ZN1voUm+PLR261uXXXec0gMZIwvC8wn7jORH41vHSVhgto9m6J73eHfbp7aDw+FZbqmDKWx0S7wwrf3N7ULFq0KbfUpFSFXipkYDQuAnzAlgcktGwsNlwsZSKSZWGIu1EYwDAiuHtQmcIQkp4u2GMIFA1vD10GEOhWnh7MZjAQfXw9tFlCg81wttPD5sU1AzvACYz0pAa3kEs5mSgVniF9FmQhdrh7Gw+QVY4u/pZfIbZ3a/JB7On35MPZm9/Jimzr7/FR2Z//yYfzIH+Tz6Ygy1MPpjCFqf60EYCLQItAi0CLQItAi0CLQItQbSQw0lnC/jlD9qzcQKYB2C46WQ1iJ8SsU6DUUEQrjjrSXJbUDkcr9FlqNdS48iYebfEcaPlveB48D5wKfB+cHQteA+4DPNBcOmR8wFwsKZ6Jzj61laqDqmvWAjQTsKAzNOSmr7u62OYd68cRARqR2S4ImA/ho2xUtA6X1dxtkCdVU1ZUL+Vpt6P2vSdLPY9g7c4T2krAbjFQn4QHh6Q/FmWKFOuMScdXcpOTBqwS8riy1wRnHdBuk1E2qqHtUN1anFjAdsBKNFVzh2+dm6YcIElODwgbJtXEQyuW5yQ/Pi7kQz3eK69in6Hf74DtbD//9H3LAHhsIzJfk92FTA4ti7cBzcQ9YrE4cmFyyjPfIgfKVSPDH77XxDSXwYmYxZsuVhOyaldv5UEen0yC3X6s13lmvfmcKgMKo8a3M0LX+1L/1c02j0YOvY+9iWmidEwBsbCzDEHzAXzxCZhc7Cl2FZYK5xah8VAGK8ZHzM+Y1AYmgwaw5jBZQxgTGJMZ7xiFqCW5y/frLyQxQuoy5yDi7ptS5URUxz23ClouAWt1KHXR7Ooj5XPbJrwn0MvjRJQFgBtp59gapgWhpXbey/A1sCnco3yacOpoL/mMHM/caRvnf/3Sm18berieZ7fLefj/87+2M+afnWBY38B8OtnGeDX69i+MfSYtPjfMYL4D3bdlosnxTfETtGUKF4UDiJ+/AYRP36JqkV6EVtEB+D735HnkQ6C5L2kQJhxpGzeAzbU8z3VcWYzl3lONfuqNr74QLj2ML6i1u893FjFqlff7ad+eBIIz9a4tgm6iocH5JetNyR04Z4XdLQHj99KsfYSk+DqVmQNBi4me7fdNMhZTCjKVKihYtLHZs6OAyfueMS09AyHmTUOzbyTWnUk36+fs3GbzHbFmIcChIgVJ+WtfB+LIiWeea5Ks1ZtBPoN+doK26005pBSJ7TyabNDvGcSmnGHsLW2qJXsHiPGXggWx1Udw2bdicaKNZcI4JBGERkUUIKMQQsdxpoFS1bULSUnIaUmqzeVRrWcGrTRecTPVX1G3TTivieihAoXIVeGLNkCVapTrQZfbTe64q1ho974pMUXctyG55oE7iB6hOIpVf5IHtMQRFMwXdG06YikJwZNGGOJDMUzlcxEEjOpbOTJZIuHI529Qo6KOSvlqpyLMm7ew3XSEqd5OmWNy1a7ZL1rtrhpm9u2usXbXds94Os+H/fs9sQu84741D5PHfOZwz5x1EsnBXzjvKDvXfajS34gxXV4CXZ4aLcPyXKrsypUq1fjpRy5eIoUK5AtS6E8+Q5o4GJkoqOmoWVgY1fBwspsp3Ru3nLNGkHuutMPU0wjMQmA8K9kkMF98wujQDoR+VmFHWfHNxhgEJ2IlcQxqREWXRMfIn2w87WxAI49ePQWa2p37yuObbUNXSwOImrQsC7UexapJKxF0oxpmDu09jHHwEFAH85vfTg3aeNRfS2OHz/Z8CrdhMf0aCoNP+1p+UGRLe90U+k6XVqofdQ9a6memJNZ21gtceJtNKJHLNU/jsWHhcJ6c4gNmhtU3PiU6RVOLgkeCIr4uvSvBghgzIHjwAJNTsUs80Q8bt+lOWHJOeAxJxVofYkZmTXHgRYfdpJd6r4Sj6xFtL9VCuRYHOdUEr0icK7v0LGQJioZF4EREuVSzEGJFNLPA+j8lpYyP8KejdNZpQywhTplIJHeJk+0VfvrZ86tUd4snR023Ad4ArpLYA72iSry0ieIqpyAzfQyYLogOvOASIr/itBvAzhj2UuxhsT6nvUOU4psHAxsP3VBL30tSexyyPuMOIz7zbIV4zbSYR3LfBBh5Fk5TFkygbvC65XAbsnpdwUAfgpAvBfwY6DGnwjQ8B8A+T2BTJtA8038uEN6j/6biUNBoCyQUsAjUO+40hUIFTnWdvJEJdIeaL5CVeFEBDmnHCrQcyW6nwmEaiURFxm3KvFMVCsQ3rk947SfMFctPBfquBFBHqqCNrFufs1BNFZRZoQQBgTz68LwW3L9GNGq/HvMprZGsN3gUsORnjTRSmcmDOchBYlkVTEbr58LlPx1Kdx34YDCK3fjQiP1WveT1s6BmQBma4V3BmxndA/WeNPYWt/cq+ooHWhzNi/NgzLZjTNPTsBKLy7Ls8x3EBiaWjCmKZ+b2FSXYqAofXCydrVLLl/fvRzyRTpQ5nwHNyP0JwMAlbf9KfTZyx5cBu9tuehVTnYVxWfOoashZLpQf5dbRynRJIuwNYKQdEQxUVnGMp1l4VRaIALcSMzBJgXpWE2sPjUA729ulGJlEUn65HMXr3dmgqMUzVAWc5DyqhlLaDMwlmdJhlmXBhCy8346MwpgmzqW9OAH0s5k0F/v7lO8B+PfeKnLqrVyET6Z+WM8U2JsltKBp71vl0qn8d7b/mfkAH8Wwu11JB1BIefy/sfgCgfpcxO74IALFZ9/x6hjcyJDxLhmlRJwUiN+opJYoWTULim0ziCSMVF3IKV1hcTqkmPs/QmCVONrEdgDYWfLi57l6ixlqknIppoFDAQ6W9DOxWvzEo5BdpWNC8pEqZVXMr+I9LHJFpnMSj7FEMhicJBtwpkOcPDGTojMXZZzSCteAS2K/T4zsdmKGFctU0VKc5UDy4iL9qCDApXJhgIBbkmzRbZP+QIF/L6t6kOPGP/tCLNscspgETpTr05VxJQ5heIk65R5QcNNpieuzJyl2a4OaGXMBOJL6DV3GqXlBKNNQOYoLbEkra9/9O8+UjVunP2qsyJBI8PIcbqZgMxD44sL9aE2ZWBWarCYlQdJbgu6KHnNCUt1cKm/kUlOrS7KHNdMReHa1lY3lF82FrYy2adyu1Xjw3PKL4iC7xA8CGSRTTriqU02oMLEtWPCNcluUmPFSoMmMbjuKwU8SEP8/jgpUO93xj3Gm1VzlPdJ5zmn2ws0+waZb1sbdMUDGDrKbTVKPAxe9dfQXBUxjmoztomXK4WUDlPv3pT5QQDj5J+290g3eW8ljfBp1OS9Bsj+l04qmPj8PZZPwJR928FO5SpFOmxxRuy2Q+T+l+n59e5GPHP9RDLSXD+R3jUOZvDs2R8KkpzHw0JZTe3AAUZL6eov92RC+V81i+SV9HztlPnV3fhDNnwobbkZU8oGgwgblFF+rpmuhiBQHdvnjXMijEdgW015ot/E9iQXDUtdUw2Irg0pMvIXg/YxJScrNzjAXDRBNnSGOJq3uGZU8wqERcklPNEpaCuiBuUPojfDsI5+PJG6/fy1a1njj54BFFMdTcRmDg3xk0M2tozht1gtrTMMUQRFvV1jAKGs4M0fsqAi4MxtGQwy4+bMaeLwVIAkvxQ0Q1hwY5Ek1cHnAotIfIqBJ8xc3GeIONwfIw8R/KcKjHcFAfBtikUuSDMmd+uzAhXSNmy08bdJxuZfYcK0kRzX1UihT6h28yBWqdj34KJ64GlYqHkOb3N0vakiqTtWPYYiV+Tpt3L19LMTv6z3VZThHYESHdr9Z1X4oRRymTuM44aqpkZcAOQRcthscz2eMcL+wHJEZcvccG4hDKmylmq6aXQRWiO0QVNUB2N1ARLrpPGsEhU+tcQYSElaB1rvVKYQ0RxsJd4JFFAsM7ONexOfwUMkfiFNZ6sktq8cN5O4aM1Yi+z8vFD48IgGeLdSsr71NfSpiS2+a7cw3DNRAEO1Gpc32k5DfZmY5BZ+7N/ap9HNc3xDxjJLmttO/f2RXPTeTFpRhxTNkj3FZgxm1JOrDrjgYNVBN0iswLJaDyGhdTTx6HtdyDgmDBDJlILti1GStRX4PPS+bc0ie195UODC3MyWwposd2ApfeF7051G+JTGSFcNwWDUWmUUVLP6fM8xPcGUGZCWi0uRWCeBIh60NKAjBIBgg4koJViKXvUuwlHHWgSq94WDmxfUTlzJJoeHxclhRu533zn0STBE4qMGj2FqHWU9f1yJgYDQwZAHGFXoiP1uORxl60pJaffOgdkeEWEqePhXiNiyZZDJSK5goFwYpPBOQUBFeaMCY7STnkfeuh4jMZ24oSWqCBeqgFQKVdogHujSEjhcSTF1JgfHQcui4B2tDCiph5FsF6kD/ushHKtLu7yHwVJ3qiEcHy1vkHDEftwZVQQZ7s1Fsmuu3dH8yMLWYfdi6SvnsDVTIGdU8cRMIXgmYzYLbjtrz8LlGF3wQAGEzncATWSTkRwRVH/BrY0Z/J5X8Rtk6v4ibQdFPurM5ChS1dH5l3vz4IYiuLzc1S0JCuVfKHBxnjZLJjBsYkRtlKMUI4al0Jfa11jYbsuo/h6STsmx87l/AvFpcI8HmtulUUOoWYxuVdLJtzaz4qeI249fI7T+T5JqUHIKM7O8viZfRVArF3zSGqknE8wzOlMFzG24rWgAv16fqyU64lOqkod78Y6SlQzVBKbabM68iXpYfPnAotx+icRMgvOG1adkcVd5t52D9mvUwz1PbZsoaxdA9kDePkBf/I29tFu7yavxJ9q5VjYYfL3u/XrlEgY9dbJd+nY8stzx/7jidfg4PxuFrdn4UDSrJCBWQyq0jrFYh0l5xaUyUXm2LMnuDVGU53HY+XpIs45jBx2Jv/ViTfwOOaKBUCZujM+3eq4dHNcTZIjCu1fCQh0o5rPzVnoSzJI7o5WQim3fkyyUJ2aU3sdAglslqUrkCha+8qlF4kteWKQv+At0oaJ4UVtQ7P5j/Jc6g9z8OyxoLbp5MdLbrBlkaOVIcmdn1/F8zkxspIV9py3wkTGzBmfSBrCYDOGiOTtjy84lheShGKE//X8JNIfBmRugO8dBnqs5gp2gC3l8kJCE2EKfxhprRppxk/2ha65QJ4EnDKUUOSvY429zen2N1qOolLdbQQFMYbGFNAuPJJY+F9QeCFKSGQv9lRFbA5/yLid769ggrsNRmmqJ0K8YwvjQx3lzbcGxLxllrPZ1oEC2K3F1hmFpWHoafExEsfQOuNpPH2NDntJPRKeH36u2o+uKFtgXW3afIvHKlp3XMeFfsuMkpDMR/vPixsL7lHb0ymNagfbVrGwKsutiSWO+7yNb6gyDXDfRLLTL180yCxTEYLA5ZDbUMg41X1sTEclhdDJkXwhIcMY6Oc+5Vs4bWTvcSb/xZTzz0bl9pks/oa1EDuO3MeNNNEQsnZUrkNdrRWyXZjsILuUjIxzkt+tO+67AoWVmOK+BLVUqg+P6Yw87hdchRZeS3V6bXfcj1pQsdOxrCR5akNzht0QEiouUdAn6itBPHJ9z0C3Qyx9raJ3xNg1ZfEk4x5yD6evZW6BJuNpdSHk6uWL7HZm/Q2LEvvdDqElzjmRz1U6cHj2oqz+zNNWBJxtMq1/jKri4NhBr6n2s3tjC3lpq0r8l9gWBUjHulHyT5hX0FciX1xpHwrdynnHYh1rPLwEOJq/Bgw+EXHB7330AdX6x0Mz5bpsSo7nvLuT8HLnABVo4X5zQDtTG7az4SF6lWEfmO3nzoOkLNf4kiG2mYcmAyuSqdjJzKvYYOkncuphU3MdcXLqTvjYvoNSaOdbPnzFw6y5WquU+JUVoOfa7w9D8nmNsvXhVd+za9oWuWV7C0yXAeVLFalk0ifl1LjOpaXvWJG3SN/BftH1thE+flufEFahu4jEtg3He8gERxYrOX35gnRtDm0E6DhqZke8pRZuMJX6bPCf8iciUo6/M1kU5AlF5c6O1WtQlVCg1tz+RpvH42s4m27JCsuAOTcwvbS9IISps/a0/11ueukEwc6shd6CZo2NwZds1uTt+i3u6YnpJYPAx3+NmnsplT+hBOTK/kvi/tWiTnnWBDNYrBu+jQaYg6U8ZROMeJfN6c3mONtnw+UyeTYpxIWOapZBNommw0LYc79dd56F2Oynr/ViyJiT55Hy9JHlIsXgP8t+ERzJLkhCzV2Kib8V3ZiVu/lc5L5WlaksNt2h0G/rRW2Joe8mIfL7zf+pbqZoz5KNf2lM83PSQSA9YxFlvWaZsmy8kyYFi8c75L7XHHrgF++f//RXAXQImiutF9bxhvZ0o/VUvrU5bVODP4XubMptmO2s2fVQzvLW5Nzl09qWzuaMawjz/H5+Oh9mUOvjRmkIQja0Vs0dVNP70yZ0k0B+OtZ3yO1HKOw25H4uLTtWlN6TjiLK/GmN1N+9+23XHfWL+jl7y9WJdK+AU5zStzj3jHG3qj3jSnha7mU0XcrOibnHY409Hypawh+esGqZCICqXT8eiSj2R2lRqh2dq05RrVWeBId1sMWMbdx+4/M57R27sLjQkHQEIQSqkYRFxU0CyZSJl8vxOipKVAF9DonN+Ztvpg0d2nt8SoT4jzQ3h6dX1S3yTBYDta+6I9CIW1Sl9Pauf/Qt7R/ZXQ4zu5pP3nLlJEdB5vfa3bF12me8JbGX9j/y/vZmlR4+df//9MzcONlqgdqM5tWCobf2qtYHJ3mJOytkhFGUzy/fEJ3fIxSVjoezzIrvMLsaIK2WVIqhyxCwDgot4hURa08FvHEP324z9+kpq1noQMmpw3clk4sf+j1yNVd7YlIIOS0eYodb4nvgMeH0Qf2d+RBmjP/4kGXD8Tz1ar0cv99l+aTH84p9X5l378qOflzzxM5/9wLvzaRyhLnl+Cbb8Tkz9E9kaFLruSTU89+vdN46/s+f69u1vz717bO/Vra2ampmV6IcttZumpuo2tgAGqkcRvbYTu69vK6+DHGWrNY7eJci+27XPqYNul1VrXk/cluRS2mpnpkoTdX9MtqPLE62/yHe/EOdSNB8n7f7g8HsHbszIakkGXSXyxdHx0Wg2Oqlyv6Zhw9JVtZtbWh1bVqxqXOFW2uaDXfXej9+IGwp8T/KtgjKx+IBofBFKAGqQ+9s9jb4B9wg3uMf3xLfsipVfJhUc5E0uAgjwFwo9ugz5IqV30RCKr0jgTaSFr247sef6tu27bxzfNnJpLCNZ4dzP2bXWzKyErumb+ak2wgYjl/ue/Pf1dY3GakrXIQGjI4IDHMEa6QATNbDVCqKJ5EU05JvdHMQ9STFaSrN2OT2GCqSdKU8jlb2iQrpdJQqsvpSgYFSNuNuLqgFNlO+bK536JPL2gHjTgorMqCqwCykkzIP0H436Rj8CXE71GKtqK00O11XnpVWT01Or1vDMtfYMyrw+6Ih/qiXxo+0pWetBQLMMmxtE01MvLV+wYsVksO6q+B8koHn7HK0h86kk9Wl75ttHVqDr5p5aNmftyDJefdq6DL8Tr2Ct6/i5o/884QzB96rrRWXf4fRd6V6cNni02vPDmWxf5usLoTzemmne6mhdBneK1xWt+xv6n/CyMAeJ+WKPTYujChVKkUjA68wMReOK79Ox6vR1ekBFBqWh0lb3OXBhxq24coHfsNiQKsbgMjCM18NWv9E5796JGAOanHxZ+MECl7tdOSv1emLlf/qjoYqn1OA5KU+Nkeo0oryeBH9VQyoSKRRikYDfldkZjZX9/2AMYzqlVIpseKzJY7h8g91eIBbAvYUuYygWy/b+Xi7wVUQq4tcS8BkY9o3U6mUDfU0baskG+COG6OOjt09l0LwqJDXpEdPmaigwliIKR3O6hvPQ0Iyx3vEQipdw3tbYl0dfCdTK5CDdcQYa/J/+qjgNl3UFyIM/Jm4MSDafgrwSuTrI0b9+FWcJqvSofEvtsoGhhjVOvDJ3a+S253MGfb6jHH79/2p/qOQVVbjJ0xNyS8nu0HjvumCwbyoc6p5uzkvvBHNo/LU0th/tHvC//W6YzO7yMjyN1UyLXMGsq64rccoKVCz4KV9E2YuIt9uez6XhY3lDe7xdBbI9Kr6Vo23JhGqiAGwNioZo3u/f8t9/MEZUcpVaHDflqfF3TRrpTeqSrsk2t2+w25ezSEfmMsuK5IslKPa+btlzr6ZTC7PMsph8+AqQT0xniv8XJtzDPe3EXlnvOdc5hUyR53A0WlhaZBou5m466sDjsxBzY5WjoPfc2gSCwOat4il0verBjm5ued7eGzdIjEsgCI9q8lTX4pYeup35sKTkIp3+RTHrc3re1/DHemk2UgCTK1VIat5zJhX3q0WwO8DuhT9F2qlUmUHZ0uSsUCLebh1tCrL+GP26vHz0hReF4FwaGEwT54GfW/DimEKFI+FyQADchxkAFzGVOWan42CeJlMlidXnTr9wKVP90U36mRbAUy5Rx4ZmzZlZ+6PUuF7fpfvh1v8NNy+XMG7/+ptrhUKJI7PiMxvKjUyDsej//68VmGti6k2s0dLnqQJ7+3PruHA9eaKpnvwtEl5Qrhj/SuzJqFQgSSRX4mYL9q16tlANRYFF7naMMN59KuxGNBW6Oa17Ipz226+A0Z6JTrG0uLLZXWyVSEvsHneJXQpsLDsOquKEu5d2USUZX/6j0jZQOKHx0ESIJEz9nMZTB+9llHOluQcuWdKVwZicj4cehlQxtv1ojKjiKbU4TspTw+/qNJKomvzpSytJELwjHA7zs9fJt5Mu/GwisV3ege60F2FQhdxTqj9h8zXLSyYlThfJI6XfLNJReEz19dSaZQNDzWtqNJri35uuennOKjVIavIjRpXHUWAoQRaOZoeG85Ctg5/Dtms/abcJ6mK06IEr5m9tJMXqWD440LDaSdbCrgSXP7mX3TWcx2WanJVUZ1nh8GFP3ItSszRJqnLV+Y/FbUa1PppJc18VpRIYSciM2CVbRnmYbJK4UmFG/Xfe8sX/ELbiTNB7rwK/xxCl9RpbhRqB3GQok89Q3g5INisWiSAGiI/UYlq8UQv2wEgv4RkfSgNn6STEid+2hkB5FiKPLdekOKMDPSGf2aXioquXitgpaUoMH1bIoUtrtEYug/+oUzFFrdDoLbkKWRoSv/JzftukbBJFNhFRUwsbo+IkWbIII44mEVkN9Y1RDTQSDjn7kggeG+48X8bGSEZ97IoPpKikx2lZ60HUlJlpd+3jBN6zhBYgbsbttu9I0Hd09Hcodyb4XJ5Qi4qhTj+ZHhy7Gb7Z8F78gX87O08ETzSkpR6eMtcV3a9vX3Dnbgvq2i3gYI5iS2n2wCLFKA4aLc+z2R0mqvbXZLuL+LwVsVl7cbUT+2R951znnvNsefkRgsPeyNxXIvXDEuJJkjATCGBhbCVkYLOtmi8EgwuT90uO60hOa9A1SJHFnP3EteMxXCooLsO0yFogDLNpmlKgjJwl01eVfwJrF3TmGWuGjoO/i7zx5aT31DvK9sMQUyv+4COwxRxeacmEM70+Ck4qJcG5yXlyLVJmV+i059IvpB6OxVQKFgkSL8AR56Ao5eP6YCDA+6utrQsGW+s7HAweXmmr2BxFzITFQpBnFlFztliRpGCddZ29dRZZeLyqZKlfplBAQbeqt/6971f/6o5yl1hc5uqYaS9rEko4ro6srqdrt4nuii5StjGk9w2AFH2sfo6zfndjdaO3OCgdHahxCCxbXfBiX7DVoyzv7egaCOQkjIxMLOx/HG0+FHNKXV2gKs6OvKHSpalz2qn5k2yyAbDMVEN1ub0mYylDLMjBv/i8Wl69oXmDjcWPdNJ+/fqFJxH13zAg51YMDVTnddprPe1nCiaizL7FS2EyuZAtoym5ktSCjibo7Dt+n0tc4vYWS/qHj++59vLah0nmbTHbxxYNeRWgAmKAJdHReyxU/O8yS677UzqkrD+64kMBY2WrpD/9VtNPYG5hXbg1GAx7qrkCkyaPm8fSl1R01/qbAxYjs8TAzduRdo8Km+Hg/02xUZpCIrO0lIUvFKAk4KeF4uJiRbkYs+XL4aO7Pnh5/VmSeXvM9rGoAY8CmO/2+12ikiYvSzLA6BPhORmSiH52p57HEmugxDVrA3u6Qq171zSsb9vd1d26d62zNcRs4nKZTaH+ENPN5TLdISTs2tCYaFQ0DVzLkF81IG/qY/UHOWMDPUupPlF/C8kEX2Q3lLtdXp9LxurydrU1Y8PdYqlg+auhu3Hm7dFHTXUFSTTQmli1KlWWy8+nspkETWavudgMoDldJiObLublmt/93Cq3bvBsELGKMp3YxQ9euBPZ8iNuZ6XT2fkeYzTS7Fk8guRrJCV8mgK+p4kctMXqIoFzNzElG99p8rlETI+rWNDdc2L/5Se355LMa2JXTyxeohSDKKgATaJT5XIwb+MjzNnuaSoroimy4pAAvr8lf23BrYpSrdAx4GttXuKs4vFMMuhvdHWJqaO6yeWt0BcxNQ83xvSTocs+6LpdQqpv4Qp5xUws4jdOtosiKmIJ2Vzx6MPe4/v6NW+baK1dMEukeWvspolFYyoxiFLr9rvERe5GlrANYo8lYtbgIyygpun8ErpEW3IxKXx0h257+OiyZeGj23U7wkeX6dXStmHvsLTNYLj+HZ9JebpuUBgSLsOvocvvVCCf6WP1V8uX9vQPioaU432FdgTNbuUG/B2tzUrBUFd3qDln9Qq5XLT0l9DH8RW+xWugZrWkxo3UJ6vkSWpIuIAsKybrs5otPWYA3dWk15cxJEJwwQ/fuBSuzZ7NTSxZhLfkxx8/cSezKm62NFSveNFzM8bsWjSOkKmFbGmRBrYuRPbbY3WLsy/LYdAb77b6Gn0jg23hkUMzd5/feppi3hqzORw1ekSbQ8O0s6Va5WERUZRFGBa2aIiooSjDs/KidQHBUOrflVwDj1tWEyhUhZZ5qnhSixYuyivVlZoH6lr8QZuBxTZxELszuDQKfKkAK4Z8UklifFUmtsm4JfAjnxF3fnCQIaWx1XwJ5uDX4b3bH3wz92WKZW/03nD0kiPaHLrLwM/LUNFhMUGUVRIxLPBrBGypFlO4tcUp7sk/ZUNlE5sgu64NoWxnXtRVdYHDKWmsqnUVB8QDPVQrNNVsKA9423wuGTsUCIa8uAT/yPKFw9sTdzD6tL5exhulyHSyF++A/ndHZu7DPdb7G+wNns5ztJ79i5fBZRopW16o5oq3+9XnLhky93Lu8cduX7potIqc3zTwFwLu/lb9WuZNxxswJ98R9m0DNdk5Ar0GwUMyNSWm7urtJqjQF5VoeYhPYiphGznYf6AWUuExtkgoZTGxcEGeFPysUFDEVLDFnC0Ph4/vvvly7um2p9gdE5FL+hQgYh/Z9sJsFhN+l43wWtW1Zz2xI06llkqlKo1Ewsk/vaklpGe0MtqPCMSP9a/FZ0jgbz6GkRXDsn5ZlcsZIqE0nGgOmKZkyor3ggt42ZoRMew5mqNgMCBLyjm3synnVkGZsrIeUGUkpzbShUemP8rNiileF8xJuwwC5W7j39kI663JhtoZjEFKCUWkFt3OPx9TOfumyaeKzl/w2atC/VT5kihexaIGIpKsIuLBt74Z2B4nS0+kg778lslWcMXbDqvK7UGCNYq7OzapsZEe+c7PEPBrCAqYqEPmoFAxfAzttLr+Wjms9Mh7CKaSJVOq6TT4au60HlwgoQsEQioFwrnb1v5HGlSW1cxIzgDmwKM9mVgboAOddQYBi25RGS2tyx1vxXKPxia7LAz2d/oHY69/DUFKk7QI8M9QGppZZgEJb5DKSnHvT3i050jkcxr7JWC/3aGX4PREqmqbP7cwXwvSkllwPi+nOiCivkBJBDQmsv37/xHIsF1QzbqyyWhu7eLTqNxZ1gfC4dm50wDZ90tKMUWsFt+m9heDWMB/VaCf5oxGcs2LndvcJBVeCr75TTSn7EBaGF8EEq1FyRNtO9Iarp2IPbhcZsb60FwXEDXmop9WbQ4vTXkf6JVbDT3xRfkUMOd8oP3P1G1EZi9qY7QVOOYiR98/tbblNW/F8cyLq5mBRjr72520rhKFXTek8CfQRRXoIrCqhmUpnSuPQTexPqwBXVQCL1Zxojm5NBldwf4gB8SCAzUj4p+fo6dbEG3fv7A7F8usbUbWfA0QjicHkkzz2upof2CyNN+21GgNa31nNp703S7oh89kIbBdffW//8blU0X3dcSPw6FhGGwcChuHxZ0ZjKUKLDZJNFGbGaNMQajBECc0LiicgEHXU+pQxarlbEobEoYc+p/vcVx5V0C6pU1oWpa/SHNDzj8T5vzdV/lZJkWBTpHVBQMPLulSIkF95vcuV9eb/bcQ04WDG3BZLrLFiROk4e2RqlRSXYPVhBUXyb7amlpuT/wGaD3kdwBTHubyukaOaqbsjy3dbcqn43f1qsSOhf72F7/gkgCDFhBwGL4AjcNzxarG49GCfvARm8Zy3/JUE5UD+D58z7jsOcuse7jBrim6MXDstzrnrSjgK4Mro81m8KDnpam6DjMvFZZ7AnVXinAdWijo/d61+vS2uiriduDIrqpixn69/dxXVezCywrFqCIheNAF5khXqM7OuTOQ25sb6p4vX84V2Z+p3mN4sGq18UGdOzYmfeGBXjsBtTd1RX2T4dGqVcbHda7YX+fLqdxjx6jc8iBdXESBSnIMtViCVdmBltIyFACaFO1VEiy1WEOOBEopEtMRmVeKC6DIkDrs1h6oGDMtWE7hHjvGZyv30cwYqsSzZFEisnYulOzM2CmJ3ZWBPSmJ2xVnzpqRjdD/oU/4s30RWj2nTmDga2pBlHDB6Rnzw4XThVOWoSiC+6xt3niVVK41CGNJ0pB+mw0C5kOSsVrFdqtAU4UfEUt3/opvTdlzc9ayu21WaK4ejH4s6WaIeUiQduvRAObRv+yYuALo7m14RLA28ae3hUCXFiXjDKLee6ZofdT6WDF+hqo/+19TRPBZWCTCZ5W6chS/qSSt2vY4QmhsBG60WGrN8OYzonnfEkTiijhiKurd1UHAYQGxrPFJOCQZUf2f5tRPBCqYSQyx2wOMcn+iRS6QGCV8GSAc7gtruemWN9+hysV5SEU05yH/kfGR4EE0By2TwNjiIY4gZZ/+d3UaBfwpfkBMfkuRK+1rDA9PDIKRYLsE0TR0w+ZfG2xpSZ7xg+X8oG86g81D5OiUIkxM3639Z/61Wb8/s/FMv7Gi78zGA//azBzS7f0/bdXPblIbxGK1kS9QGaUijZ6XDjBN1vdGpN8SAEZpUsAd86g4qx4bwYXLGRhRgWm0viVBzkvQ8uNXVXw3l/dKgTSW5QkobsnOKfjH98XkfN8nqyMbUJ9xEYKZQKcnMTAmm+LFe/jxTpkvoS7RU+e0SXWfg4r/py+O0/9qqPihQl3RVt/na7WKIGb9QdxET/tZ9Vn544vu2+6DgpOyk/yTY76xWf6sbFaw+5Y7tLNAreH8vE//pSyNmH0CNyyhrOKDuT114f6JXuADsE2CaGy27bd3tl7I4A3MZehEIoD4aofzYmr+C/NoYzBtQJg+Koh/bpNhBXGoCC5SUgrlkfRBp3NBXLxcmKAN/W7h58YiX0nz1GwEn2KQ6sHQxztuUxpf8Bf/yo1aOaU7JZAjzBKIYbC/N2VEJOAb+XxR8ujo4JBUkG6L2Ig0iI0x9mv868brgqtRHKSMB2O2nrqo25lZ2NiTGOiThbnxHl68TeZMrEsolyvD9lyPjtU/NWh/0Kq1VQF/oEMrhlguvUFJ6EKl/bj6uPntqqCXHYLDssP8w2PeMaEYCcHmi2kNa0ldgbiAuWNWPTtnndvzrJRujb8KO7DhK7Fp40aa7sD69Rs27n9kwaQ6IwTymAEKdoK/IMSPvmYwFWQawMWSrnzNq6/uUF1TZSZdV+/HGh6q/mKFPiBWj6r2YwwP1H8xuz4iVQmNN63v7618f5/V0Rch6/mrNN9RYwT/gOI9GA2z6lmgbJgp8j7KSWebOdcp+Y71HXHVXE/lzKnnsvWTb/h4XBoj5jWUUbgBn8LB4dMZf70GAvidBVOve1W68BsHAAFQZ5rwHZDBC+P1FP4LmcEPZ9ah1U3fW2cS9u23HCA07iBYeh9Gzxyx2tUqvj0Vs4K2tDvCUloBNe4KSqaZ3r20gs7E8EVFQYn4Fj8fgY0hU2KwK4AUcgwWKSg4IJYYJUxk8cLp64BMzQS+XZNqOFmG/Vf2fmYmZ4IQ+JFO/exJQEAkk4+Y4ZqA9vBMjc8/49Acbqthhh9NSphyjUqM61FPBfZ2dLbumdbielRCjbzIOxI1H/oz3PxuGoC1I9J0d++5YcsDfc3FsYeHVuehCll6zrh3/Kfx5nGuPvvLujKJbI0i+uu/4ZL55MuFiHWrZDsqTK2fdV27p7BxiBv32Lm/LnF1vNgUDm0IBELTY6HgdBPiNxNC2jQi59AJDGdNDcspktDcrnqWgU+Ovq+pNpm01VKZpqbCqK2S1t8fsfRkxTM/zcv7lAlmvhznesnccURTZargJyeTq6vNRm2llLebje1WSilcqffJJXDwU5pzmT8jL+ORPzPVI7t2UoHrgmmeVAb2/atJAGSRuCitx4Jx9qTqmgpGwBFXM4ns/P/fvxr6Q+mZf9L8JO4kX5C3BKruOGCyb/P2ea6e9/Z4dqjNK2q09FAdj0cZvMSUyQsYgjJ0iu1LipBaAEO+28XFLiImY/Asod+uFXQOlpuc6636Pb7pdeunpWGEAnXBTwBl5P6wYzK5MhNWCQQdqmEaHL8DE/RfGGK+AhA4sCx0Lbw00ONvUCqdVgwJKsdQyTI9jk7XYUkSconIpEKtPme1C1Y7mr8YKU1O9WBgtxd978Lh+hD7UvkcIY4HJBz/fgueX8xf5/rZrL2f0d7d3Fjf7vZ+xUl6XPN5HzwfjQJyIKj/pBQviT5w/1QnSttkdhAEKQBTMScVW8TA5fKOfDNyQo/mSIqYd4/OdqEUTWYbeqOvNXrcBM9e+Z0kZE3gIYAby2BfH3RUH2xurjl0wOFrOVRbddjnduw/5GiuJK0yaDfUVenXyLnslauMunU1Nf2mWmmo7HhztcRaWe9w1ListPPcUCeIReXIxPkcJnDD6fS+nzqF/G61it/TJVSouoS8Xo1SELLm/tHBpDcKOAwnRcrKkGjg8ZIPd5LYSvw7SNCWPe8/ppm4JEX/jcREZ8nr6pb05LT0/0/RwpwxD91Dz2E009+Odhtrvqr9yuSRxDu/wtS8XBxJ/P2hDIeXkEhQZIRMpi2lZCJBfHFIGA4Aj8vDYFA4HAqT17Bjtmo2s/4w1oN1y/9cMODfdcjVUYbll+subzZuRqLtVabNcS2kzmZsLD6ZI0k73+rt91w577M5yrlV/DLM+C9QDucnFzkRW96yS5t+t2/FunXVvpLsdMfOZTirYKgzb9FHqdnZqTnZC0TX7JtNCwGfv+CDcwW5ad8zDbgot9TsDQJYcsHejuq9gIC8YG8tf6+a5nbw9gJn1P4tDXvCoLJkE0hUNwTMCBje/QGKXyxjgv9TyZUyEbtM2nsFJIzAvieT/8kv+I7Seth6Ljf7Dgh0NztHfB+hZoYmRPCkJaJIZ1zKsV+vbqLDE1dXfJeecvSX3ME2XZIu+sf7AeU+U3pmeep4JZ4+SCw1f+vrRZ48ROTAwWNNB0++dmhxsw9QXNrlwxdpqshsS8av3Jdnpe4DNV3H5hYcguybhU81oDnqEAt+ys8+Fc0Ld7gdst/ZBxJof+buTxgC9IgqXrNj7MiyZeEjO3RK4ujkMt6440hV0lH7UAdIPLoIaxh2wOnCBlpDvfwBhZDNKy+oQuR936eCP9TT39mUs0Z6uv3WyLVwg0rkyNONlCVptvBaPRZvARj1lEt//OlTdxLxYTUtDsPPUSTo8k0s6kzS8KGZe0/nnqdZtsRsyTmStJ/T3zAmwFd/kAi9FA/yAzpSFX+ot30+OUVrMy4mLWuu5EksWrgQVaorSThONmC5On5a8uIZ7qlI3r4SDo0CL8hYAbYfrfbeledHTbAxN2qTPHrqUfLoNn15xrFCFXUj2cg+fvgtzep0V9jycl13pjOMsDCgAHI2b0enxNqvt8m9zb0VGstPA7/83HZNW9otq8C/22j5GQRWbd8Gx9CObRAqCRsfVsW123Zzu9ad74nOj8AFocawPIWg3k5QI9FSQe2WO4QIKoSzhUEVVaScqgYDWo6pqkOFygyVqwkx/XBB6GdCfljfeond28paabSrdEc1Bj6BYDvQlaB5o4l6axFHtWqsgXVWqcFu7ouU127XpKJBEBAIuzAeKgqHTGhD0Imd8hm1BBu+Mah2xLV7OPdAo23adrdBMsuv6h0RqBbL/OgW49qtuwiNOVy7aedrt+xysYBEB4nNjawuGN42a5YQeQkvB6JhL0QRXkgpgkZQf6XggleiCpyyGqIqGsGxgw+tm3C8MJAPO5AfO1RRHQHyYQdqxg7Ugh3Wdoe4FSa80egx9qJHqHXo9YUK0UqIh1sRD3cgg+hIb5WLoCwfLvArI3DlTlFD7YLh3fPlvN3mzBoOQD07EkIdrpyhGhUXhxUXYmjREPSwdu70aueP6s4bmj2WCPEjBg6xakDGo+mROg4RVDAgMg5BmiJuPFYiuefLeDQhkuEpVMMTWx1Kd+UK1qh2gSB3XnGWo3a2BPeckcUeQINg4sZX6Y4oaIGeiKI3BJpBJW25QusQ2aZh+1WU2JG/eD5qZIWfCyYzthoAF4kqv9UQw3nD2KoguqhaByuNa+dNR1ZMGyGava2rUXF4vl7WC0oRAgeaxwLrd5LxqB91QP+iWRt+JIMgVJgNdYmhXq0GYu2C0WU82jmi4SGkjYcQhofywnCh+NhWKDBrhHD4I0LFVwfSYDQ8f8rsTbBT5VAQS1ICF98k1LZL32rC8Pv/ed1fAXkd7T3/sOT8hx+Wv7Xnb3vPb+AT57fTeArc4zWxD6oB4dAV4hhPOTgCJ+A66dZs14zEjchiAvuMjXOnWHrH8UF8zdi6qUbCed+gUmyD8ti2VwJc4YmHo3ECLpHuOK6ZGpeqe0ntdL8YYxwv50ns+n0GywWnJJvtOf7Opu90pmQ93gm3XhdbSdyqs4efuZjaMef4yyYgh6iZL1VzczrWQhdIzZtQns4TWW+MMcY8HO2pBN9h40AHCVgeiKhh3WlPMGAelErs9D7HRE3fOx4Tlsy+/k4RcVXA8Z54ONpTCb4745uo92/FgcK3VkMBwiwGfNC1PiPyMmHAB6Wtu7iTEJA5LPIkwSOlxtnOXx/FqsRZRsyPMfIkQSIxDzSfBzxSSmxflB/lGiGLiOBJMpDo+S8QsmhRTMCy662yAOv70nTEDklHYLbYsC3MXzgiRfiUAJ+oMD7S10y/1mq+x9hWp7TxslFEZqUJWP7qa/0GAprJqU5jY1ufTWvm80FQmPbhRIMRluART3OYnxSnC1jPIEmcl71PStZ31vGbk0uAvUeVsDvnhJPdju0T696l6k76F3NYhCV4xNOcnT9XYSmlr8H7KrBEWa8xBnzHgCV7HP9/a9jhRujjga3/E0X8fxmzXFQEeagpedqcCNq8mKOqA0+Td9DrLx+g6jWST+qSWCl+moxKm4lOINZLDGH2NLJkAD7VZXZJsTIt7HUc3TuLlDE7TziLekLDk0wX0iE73fTNFpMhX/8mlH76ujnMNreotsyVRxDXLaRlEkkrEnFltHq63hdxe9mUqLGLXoDI9uznnDZRaWhasjFr+bSAkV48J+rUuYs/LZFObIdnxawvulhKBCVJSkiVYyWvZhSIK4YWfK2wFBVcPdXSQNBKwaJTJCDBO3bREypV1JTy4Rzq2HAOGK8vVtqJV0t3G5aYz6wcEivNT0MYuRRjjlpEsJxO1GMXZUtgwMnyZPR9q0jyn0YVsEim4CTyyegtqkxagfWIaaPtGfhgSJfcstFBYxiP1ZyTU4gQqZrt6fGo+ox8Orp2J1y1ilshYJx5OH9m3OyguKr7ZLB4dZgvTIp8+y6SHktNXtQ5YeTrMcvyMUZXhi5vntw5zy04Lwequ8DdSZKZqJucOThrFKquF1AynDgOeho88YR0AbPge0j+iI/EnhlQLUQSJO+lotmrEa4oxmRbaW+TJ/XHxEo6o/a8N610J7hHQ0zwYtE55EibAvlaRCeG+NYyWlBBKuRCQ0d1D8fT5XHMMlgOIGpBXABuamAjGIC5ezkmMV15GA3rAUgtkFtM2sqwAWiF8HADHh5izJF6CruK5JL7bkSi6SzUBZgU8RqEZepDnQvbwZV4pEhTTdSf3OjTWeoOuVYD4U4Gni8kbcLH9UiHJK9kOeicVtBCpqZ0hF0feYp6A/KQ5dCwuzEwrUDhJ9AAiBW3i5OrOc74AXlGT0E1UKx8/cAaLmUaT979XcHKdJhcnj4nj8foQwTxSRxw6D7M8HDp1XzA17LtXv8sSD/E54XNm5zeeWrkm4aPeXZBCvtFui9JdgD+oWLsKPNmz9wKmtQi5v1oUQ974226diJbDFaowyGWCwtUraEC/6yFjcgckyVhvB7FTkJ3GZG3IMHOsxZVNL0YeF5zOy6L2ECbSOwk2xMOI9e/79C6jYf/rY4qvLKPmM1EhR37tYTZGTAUWRy2WQR22ZJhdXyx5CzdQWPERben71C07TvDyprqalzHkGWYyZOfx9BdRChzGXpR1Kj1AAkoM7sWGXMZT4i9XMXJ8zcn8szSnKNTNVRaxsR5IIpmoh1S35Jnsas1zLnpPH2cexpWvt6nwl/yt+mi5JcM/E24tkDuhdxNhQd8iU6+1/wH/ixHbDp/2AU852b7LKlTusZGcJerEXQIwgEsBes5RtWYe/Lt+3SRzNw+AFmE8ixmynhbBUpw2R2kLiNcUFFvtFsjIyva4I5tM6EB7RKKOEY/ZjtGBPYMriLZ8HBlwfKUJ7LyPogbN49rG9siEUlGnduyomTBtzIijs2YAtdljLN0I8QWjtjAzX7m0GHDkxQJKkwhy1k5sio90zQ8JVzM4tpjufAt2H5O1NlImbUOHAB3YoOO6AMe1mDqr0zcnKuTR9daFUHZ2gUQScpj59w5SW0Q8FJGJfJLJWwyc5UyWEOdhQ8YEwzjpei9xNl9D8PKp4fRa1/nWTKvmjt2JPWA5Qqrg65MoTenxIGeuf/Ts1VQO/Q6TAx/nxkJDQmjQQy6X8av1reI0Q2pA1sVJSmc0ygeiMho+YxpHdHNezKqZoIloyBWfizKAapFCysyw+taNM1I4i7TaYRIrqOoaHrm5O4Cpg8JcwLCih73O1envf3qJqhScxIvHMf51C1UV7fbQ8wqxVrXc7xK2MdDr9GDOszBkQKQ3+h6lh3GyhkSdrSACpGy9IlQYwSbFqsRrZht1lUwj3aGmsSzPwYDmtey1p3Ok2JGY4PLtozImHP2DfD/Is52MfDM+gKHUXLcRyZJ21xCHdMGKx0dy9CwlMFpEP8gvD1sC+IQo4hkPKJnLIsWpdPUYXHANYwKCETvVBVoxyxGU2v4ADWYCxHrcKeO1xOcGXQ36uVajVc2BDRoC6nT6CGdtn2qOT0H7OBG2VerPvNyPKGOWR8Zr+JTRNH7CcwPxflpcCEfJnZ5VK+p4Gl0VT/Fy3axo1C0UOuGYB+YcCjoLZp4NLDCkT031054Fj2cnNCekq2rI++MS318UPZuEvVrjXwSOmC73R/RplQaAzrgDh76imAfrHdpnzKYVVmjUewwG9TYZDyKBNU9hPn1kTyej+L4QeoF1ZZOhidIhFtI4J2ssfVdWZvpkoi7xjLaypnq6DkTwRd2gQiyN8lgu5EDmA+Ggm/wSe6lSAxKFI1TnGMlXefjaYBoNcvAZ+5oUtjVnfoLYqV3hDYazr+tjTK5se0yqo1Co0cAnlbUhQTWkMENYgGSbOrCA9Y4DHu+wzQLYOcQZFYhjWMNq5AdDc/mnmVCor4LlRacu1PsHtYaGYVtXSFRnHDba8VKWF4Y6Ny9+oy/fV8o0jMVyOOFff3hj0xFSWsk5DwKSlXRkgT2tIwaw+VVslxqWu2kJJMysDhdyQtqzc6KWEdI7kID15eqoB8JUYSgNN9cSlJ4sD2QZtW4izQPsQ6GnPhBY6PtUKrKoWh3MCEFK2jq5yUYbmxTBhQg+9yDfdIXR+jlMAIVM/ZY18bBrnrTuG+uLS1iihaQbqBLk9YScToJpyR8hqczbzmxZ3GrWL7U1bD8KMtfBYpuoLXgEVjlw6EdDg3jMqESumrd570xtoZso7i/qjH/p3HOPQUrdejoxPVhoBLcn8MFHdiSXldSMUNbe7p0VeWXl9Ys1tqte1K9LBmQWUCQUQfqVNgDTlNkDoUV/kDkBvBIkMevyAXgWnkX1G9oe8TUeIlihR0pFPT2rSwoVtzbMLppZmlAEl/Ky9YjPurHXdQfedmxrxOZLU9z9WvfDTTBrfFLEjJoDLKFtAmMj3FwbfJcNox7xuCJ8rjjEfICp1arn62xzTTQ0MAEg4Whqz/nBwmJ1b/RSl6FOfhR/v/fbg38YEYeY0GM+ft5E1zR+ybdK3pIe93SST9KNtbkgFKcgtyofxfSPbvagEUNIwHn0mdLVndfb4GWLI87zdeJhCZ75YJ1wwynbfDMXpUA5nqE+v5/5ggjTPEMGBPLSaWErZVyaTYCfl4jMPj+hBgd79EpBKNZYSZ3P/V4GeYPj3a5ka8uJUHpbwNVEea9vmu3QiKFgSA4WO7RSRwPYC7GwsargJ8l85QhwTwau9qccd/2AbFIFYzuJbIvmiaB1Yj9u1W7nJMDx+yeF2euKM2s/rg2lOkzoLG1vGtnuqZNpC6WrP8sUBva9j83WJN2+h/T7cPgtzSAKNEJ2qWoYh/vohkR2ktMJjuxv0YDkNeKi0kTo08v/neOZg/87DNDmBAFgue5Cdwzv58YxPAfCN4SXEq3ogrCv0laEmFOTqk/W7SAlyeRwe5mndi6nD86k0ALYufDodrSDqAM/TWi0q7zhuZunEcC09YR7pPJLnkrHy8waasHUVqIS+fazac2+t6gy1dWpmuACVfETmj91oJCUv5VMxjlBITKJFiYJNiXr0CJ6ulgbr+tn9EaNFuN2r/Pl5NkbvAzz2njri62Itlo1NiAqsaZmOtKx/54lsWh0kaDOfKsGFSiMutwnaSpsnLn8qiVWwo2KRj/Ip7YIx8+8axynzZ+qv5WWPmAHurF84Tbz0HfvOnrZ/38e/nkG7zYwtJxKaMGEUQp0n42sNSRNuAFi7w//aNK53RMCq8xkdgoZxAX4Z30HgltwC4oXYmVh/aqDC/kaNxFpg5JlMWpZacAvJKaHvbrRbC6LdHzii6u+cHKTE16bjjK52zVNdyrlknrsW3VqShRa5NZ605CHrBh5U+o/nDwqjRffsFAT1egimkO9/EiF4V0WfR4rHdSkOsPrx+kgv32BIwkck2IaFOQsLSLsVPht8g5RgoLswlOHf2yJ2QBEU5B76h0iO6OVfXJb6WGOAa9I252+vnk2GMUZyEtRASBhB4yIQRGubbL/+cmywQIQgfEW/2uNmvQcw3Ss6C8Y0i5c8nP0EAt+6jZ/GZaLnL0kSrrTH3D6nhob7K80bm7LscbZc+KPW2OYPomBpl9ibo7Rzr0apqiBDSk17BRydMNRZe/Z54xFlK3JHOqyitKaOkxqwZHeSj5IJXjjKu3y3BFYbizCCWsEl8ZaS++CcpcVpblOFm9l0uSXosSd4+rTqZHijTDDQy/btKGZE6oK2hFh1YUvW+RTJifpfY2F+BOpWkC9GdwM7q1AFVTmjr3tFjZLwNCtfnMMiJs4pJEOFAZWdYWFyud405QL6y9uxfaJ8nimBBWiyX8J+/DiyjGvNGKbNcoH0y5meFinQbNh8IB1/IWJM9h75IcuEvXkjEvBh7q3NHU5/NNEpHRXuM9PhQcvPjRSehc5MHp2sTrxqjMlQsA2GJnZaODeB5napiyPXhiP1bemka1cKnYXTEMos1jqOnSWobcTYOC2kfK1ms3tIGtpkyWDVpU2B+skeHY3U1G4QjZllN+zMbV3xoax0MfsGJsOCyGypLxDc+0DNw3lN2xkC8oIRcT/vQ8IrDAwAoTjfwp0qk7aBW3uUOpoe4UZFnoJ7P3Ikz7emrWMD6rh4fo/q8djUdjH5TIte+foKJLEosCNUILhCMb7qHN4xesjP+39suN9S8f+bfbuO//4vD5//88E99Dh9UcRmwO6+CQtAfEDh0Yeco6MUiPFk09UqXIFHFGdRO9hayVBUXGZo6rUmlzoQE8jfYhsyrnnGvMUPLb9rwGbuUAz2MwuEKcKrIDbUztRa6KissNqGTA0d0fYcOw5nFNHF0R2v7gRRRKkxYvHvFzgVJs+UZW3V1fV9VSHr+UOdGlIHLe0MlT7IG4ZAC7UTRK6ihdcoeVMV4Yj6Iu9o9ILrvoXPWzEMCOI4ncjTKwmRMLSYLxLTwdsHnVIow6JR92JyDMcxBHQzpdkFRDdXsjlsmSTE528V0oaTCqQTwlaTtq69PV3RYqVJJt5izSpCI3FxU/48WwUW9rMVeHCIJ0eKKSnd1wWhfaokRqqxOiOd88+GE4chgOTiYO2p6Q8TRreEXFr3TFQp6sCn8t/cHTmLzDk+j9brz/tZNZpAUM6GH6icNer3qyQQ2RftXEbQE1sBXhYpIF9O4JxyJrX5Ikc/jOUTLqAPdDA1r5HP8gOjIy6u53zeUWCWx+F94EicM7v38XGsiZME/rJp//dNbOM3m2ft0VS54UvmAqs1hgmZmOt77uLCke6nqBB2notiNdh/HKdZAmtF1ht1NiTHSDgtL4SLi74bNZ0sGmmafYx8iT7oeNzM5CB14PKpOeYku1KG28lJunZWkGJrguX4+fGhmpOOXvEfP38JdtyRMhzZtqLOBrg0vUwSjG5PbSF9TNVZGnuUCqBjognSMuZOeht7yFW1TDHm1gbc/IEwz137/ntBYGakVl2c8oJ+IFi81aqzSGrAeMzP5AXZnNv5wfunM+SBKUQaufpHEbc0DF8BcoGmOhohGQptDJvN32/Wv3p3NfIhNE0wtPwfIoNOL5VvHKCLxJrcMe25R7xpC+yoAQxTpaw8w64rFBEQNpAI0I5yFrNZX5yK+7semiFRKElcAv4CEDSMJE4knFF9ZEBiDjLvn7kn/z/sr9F+4BlHLpCf/NGWQxFeJL4YcGHpAnhNLdyk7vnySz6FB3zkeLoyjf4vfL/D/tlreyATKpVNiSUHOGWZyFmdNq2bzaoB+/p+YXfeoTzCAKb4Av+CVF9c6mwN2ML0BccG5By0Z4l3iXTo7nSbY9t5hF8IX87eBtSsPYHK6WU89NpVOoQ4kZ7bv2LJ5tsXEQLuBqPDrpZ8DZUwbMyROUy3tKij3XZ8wzObsMz+P3J/fDs9wrzidn6zmBoWMrSyj+lhhIebqo9OlzW5fG9YYAwpo/j11FzruUSv8zFP0cgG8vlb+RrgcV/r6wL+rb3vshQA5EJW72t2xEko0hibh6C7j3XH5iEnj4KAu30/ikn9ZnhuT2bDDOlS6MNH4ctYZjx5hwzQN2Oc6QRfRhs1ZnA/pg7W7jMnt+bzVHUns8ieYWlxwf5HsWU7t4xPaXOOZPEeF8eKeu5wDB6ontwf0HxBp5PNSDZrz1u96ZxqmI+jSXE7Z7Ubwvhj8QtT+pZ02EbU/XK1leOecDq4RAWk49PMMdDjZilKpN6Z7i898mMSVZxzNdHyJLpFh4ajNONYx29HxHp42bhEkTohlM5XM6vgDRHjoISKkqODFkFBS6DavHpYv7257105hPmibCHvmtTNVzekoRDygzjD6ylYeH8qeMd7D8sFMolTl3VDoVaTjSKow1X7i8ooFMsBmAIAEGlAP5olNmkWnlaTUv1QFQOqiH90OUGWfY82cxpuujN9Zic6g1k8lHe1OLtFOBBkBtmSyeeUqejUHLwmmPBWUF6a6H4cAGIqCsORKgIW+FIO3z8L/Eupc3wZ6adRFbA6tgrbFFTyfIiBpLx2MaFOs8M7e24DCZKevV00vkZRd7+vzJXW0iMAIiaMAZ3RAGFdXzSlzxtBKJUcMjsM1kAat62LCsHRaolvwlNiWNMiUwzaTk7ieo2aff4h+ADeHkLUyTiNuS02FUCIAScqEcuoB43oF9z2ByQHvakSvOcczoI4b0K8QQJhZSgMkqB4iFAVA/sPZI4sVrUcSizev56rXSt6t4Eiz/rOVHPd3H/fVQ20qSAZ7F9iLikBAbzmgDysDCUx9ju8McZloFpwf9ENcPEDQYlT4yrjTwf16CV7ABXsMOPBWWiYMSrLaeRs1Lz+oFHITL8BL88DY4KR4DzkHYm6w44wpav2w25vjW8AQ1w6kCfKA33DvaKJpNkS3UNFJj/EF9FoECqBrrLRq7WZEvirhg2FrtR1h8/AQaPz+DAol+Fqo8P4e1Jr84i+C3XwJ5/7y2JGqTAmjTiezhioHBh5gsxkdQDHwfZfUe+jicDt3Ho3l8fSlszgVfmqPngE9wYaP4cqg/Sb48j8/2/Oc3v56fiJaLy5t/MlsourCMpVHU4XcIuGQV/elz4cKu+U9PR9eXy/x1LWFk4g+PyhGwtBnsrG8dxf8zPPrYDW0e04WHIKWwTWEbZS9gMC9e2X6G+GixRAhMInOUo1jTryC7KMBzG9s4JW2wvvA5V2xV2oBAPFGgpUEJymxs5FF6uOtpz/azT26UW94mjboeJjpFaj5In+DXlU6moJnBp7GHrQeUaPpauRVp0XX+jNE0L6iHbyj+9Rc4Pa7rgEQ21PV+/OxsAk3/inNXqp5qLCsLfjgquWm96juG6ArJOgn6KzsE18IlTb4KInnJjCQFrfVCypSDzY1QFxKEPqp988D1JUjyLilB6xQjNX6NAljDZKyQy8mk3kTvO9ZtOZLF74kf4ebttN3+7naeM6Vgz9/80k2MK3W/e89LlzQnOHKCkchLMbemCZFJkBrAUmKIow/oBVbFSNGdHt0gKiOp3KEr6zAcosKjOBvKmHU77IuY+cQ7djoli39ZTKKSaMIxFoi+inCpnTvpueMIeeSiUGXn6GZxnO5i/lMjbrLTAaFCoZJ1ZXXKk1CJfnS12FWgOuzkYYJFviXllbRJOXcjAZEa1Z0TKh6mQKgevY5uy41o7JSMGUl00b4dc0gRlno/2QyRMCrW6d2Y21nFx7OFVwJi3jIYBepaiakHRECbjyHxfHxLD7qu5aS6Dtb+Zuo5Hfn8EWGzXgQEdfQJ1PHZHjN/FnLj8aXllur9FDLeh7me1hCIgmZ7Wwzyw0MpsM9hwZhY/rMIPhcNZYC+L8lCAjBwoHgoD1q0pQBepwiVgGHKGaXSL4lIyCgZp5qJdh0E/tCZGvVM04idZmZRadFunLmA0y5lBxXo0u2Qh+lgFKJQESvfcViHonbZs4nVe3/VZ5Bthoyy05cxk/odNl8Qa3+XZ88hC5Y5cvItq15xjtPHrPPUFINtxzTH7GgsDp3ktc0SIm8EYHYlnFrmu5xBsFxLZZ0VqLwzcXCTkvlbD3wCwuSJUnjifOKCOpPUkZQsZXKKVClTp6Km6XPradPS0ddFJ6RHr+4MjG13wzGb/GQzYyYVzJmy9KV/+rA1YVt2laoy66+6QbfdqoZDrbosrGzsfmh/p+zI2dcd1MilqQvqJEgUh4SMQpUadRo0UWl1lEczLx9/MG8kxDfRsf/tG9KtR68+/QYMuu2Ou+6574GHHnnsiaf8BQgUJFiIUGHCRYgUJVqMWHFVmmWOeVQooY0mD440DKkaPKSAFESuxUtIDnl2qlHGTUqJlSgtSXIebZcqrUZ8ZcpVeCZHrmo18BBMlyFTluxQofS89r/3/O6pIk2m+yIrUKhIsRKlylJEYpLnMEF00EUIFybLHru4Wym+chXFipHRs6LJ0NRzL7zsRa/SJcsjDzz1hL+7dvnGHfVVqlKtRq069Ro04mvSrEWrNq+1NyoQ13IiQmNGvDFk2FviOgiC7juPQ4aNGPXGWyJiY776cbn3l85+Ac8Rrst6+NlU87gYlqZfIkOl/7D6oHVVLCKtKNeZ5hVXNkRygkivXOcs7BuVHGAmDzGVRKWjm2H7ei9EtYfEWHhjM2a85e0UKXZpRdpYm4mqLULr0rppF/dvkcd+e7eWlrzDyFjSA3PCVozUiNo4rOhJ/tSDx/1cOSqZfu1MMme95/hKrCKPWyIpWR1bK9H9miqdUoWXTKWM5Jd+7M60iYwcexZdzrKb6NJ6R3/txjtHUUC7Lq3PxtjKlx1dml/DUcQGE+/hOBhm8lyW23lQDJ9MYGEX8ZVyuDyXtayVsiq2ghaaDQyCJJ6Sxvce9m1HZvPLNlzfwzgMJN3ksEXkRt55K6zs2k0PAxnPxmuQFSZPFbn7073jVthhh5xsGl+ZDVj5rGmhKBa/dSxR2Spei2ItZq3gTUVi02DHjbydHIa6N1p5Y/jXo3GkNsLghObKoZ1p8hvaeQQh8YZ5khaG4e9oDWEEeJPRijcYFVBGuxNGgTJWRxm7gDAKjJFIignQGgIUGNCKAhVQoECAnhjQigEFClRAxmj8JndmWLBiw44DJwbu9lEB3myda2BVcTEwMDAwMFK2W2be1B+1z/XmM0ai5e7x2pyZqlOCJ2XFp9f3ZUvVRyTRdXOd8HFsEGwamGoQLBaDtxfP5rZe2Ost5bFrtCakOimCneROVGa02mkddlFIpZGM1U/vAamLcju6OZ1wzR5XNjMUajIuSotSRNKHQpnQePuodGuKub07ch6klNZaDTfu3XEuIWWxKGgkbzypSKV2EbXGihfOtzJPi5Ir2nzT3u4y4jRdYcT6+TIwJfj8bNOdsa//tw4QajtFKv91TmtL1clUtmQJU7RtzcMCpxYH9iyVx4IVG3YcODFwX8tYZLg8XMrCTb9iqiucYRULgNysRc26Crb1fs/HXkWp9P+qjbvnUNF7ffhk+DKCxm4dn8lnloUsMbyV4NfslrLBsnufzBWsCwxQXXoNTMqx6uNyv3q4tUt0eutzxoH+hI26c5RugTdqUhe/Y0BxD8iHA93+5w0jn+AetpsScEwkXB8vsd9TJiuU65hSCpbyjqwOg77UguXSizK+NbDa3B5/eX/bgSXKXRIo8fgO2Ju9+j7Kqt5afRFeRBbR6qjO6qruE8eJ84Jc0Et/GW78TWh+sbYLAAAA) format(\"woff2\"), url(../fonts/dbscreensans-regular.woff) format(\"woff\")\n        }\n\n        @font-face {\n            font-family: DBScreenSansBold;\n            font-weight: 700;\n            src: url(data:application/x-font-woff2;charset=utf-8;base64,d09GMgABAAAAAF1EABEAAAAA5jAAAFzfAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGoEOG5xMHLEMBmAAiiQIKAmFKhEQCoKrDIH9aQuHNAABNgIkA45iBCAFjWoHlzwMgnwbssoXmG46vhelOwFSqq3VX6HIgLBxwBjanjELgY0DyBi9qOD//7OSyhCXhpm2AGyMoypEZAQXpEBGqKbJ2oQwHS0wlCOn7qx4ItFqjSZTE+tlM1sYIeBM29m64LngxtLAYH7Phg/TZOFM4hJvtptYxE/sZP5NJSpR6bL+7J8omLcSIU3IuY7oDjIQtGHh021yfdmDUJEbh1PJbHjpNprFK80yx1kPL5U7c3cWEAn7nGp/7WuX6d4Cx8af+X+1q5s2xKbp7BTdpcvsMkmluuwMbBv5mpwkL/w/+ked+/IHK7ECiBZwR1XrEeoFk/+fn9P7/vtRgscdEUldUlOnbkDRBPGKIVrMzkrdl2XCOgDbLKdzmxWogAmCIAgiYRMpEilgUUajINYsTIyei3LT6cw5N52LytNFX/Ru/7vrBf/Pd/i8+9x5v/RUjWGWx6toA41QBGLdrFn0D0Ru+xE6YzD2Oy9QLFYNFs3RUJO5P/t2/zm1GckqzEjxMl8JbgSnwpe+7J9Gcd1WbVRgd1neZev1togucZICsMApkhfhSqftTbrb+S6IhleIJAcABHX1XIUlE7Dsp8Bt9zByYNicRVNwHrr5rbeuq4G+JpEf4uDN7ad5iXhiw955fjX2urf49gKAElUKdO1NowsaWAGOr5CRNTIyUapGEbl/aKtSUAKuRjUN9fDuHqLehEGGoZ05zi68/52avmXvV0D1eONbC2WMiapYiv3vZMlPIwsVF5eQ8/vW9CgAJBQLl32TlFEFWNVOhaqTf/ZQ1s/N111Tmiq73P+B5Cgzfpmd3aKutBPJGLCU3N0zRmUehoX38rB1dYGdAQALfr+9+eQtsKWRTmpVpLVfuhLfKA5Iz9ysMCOQoyTQm/c0Bx88ggU85UwfenbTBICNBQVP3QEPPPAbHQCStjx8v3xn8/bMS9lN2/mTpqMy15hNFxqj8KW+pKt0z5cfF4X7GBXhMA6FqqoVoT0WhzFAlSulWk1eXb71IQPErrRMnX9RzsgOQj/AYTwwnMbnf+1bfZflrTr4LOeh0vFBbFANCZ//V2fmzKIuScxCGfx/RD25nA6NBpGQRDuh0brlDS1yukesb6/TeZOl9IUu0VXYG+HWyZC7pI9QNItD8fx3ew7v+f9N9bO99z2MNEN+ncOhuA4x9CBEp1yUPr1dDu57M8C8i/kEZgASwIAJVADwEwT9JEpaYwiuzpAKh9J3SLF0VtgQU1G7cxdb17GMTWM33Xb91lu0LrrGryVWENSkrd2oICDpzL0Owvn1mpEbb68tWYxQFWGMWVT3yvlyfLeDnPb/qN783mipIEtkTISEf77s1byH7za5DkJsQhSZUpnO8StG2mcRQG4+/v8YHBgnEK5iIOINhRhuOMQYiyCWWAaxwm6IfRIgjjsPcVEiRDILRJZCiBJlICqoAFFLK4h2XoB4w2cQX/iB8ZNvSKkVwiqvAQYB5KRcrxDtPu/WD6dp386bgRgJQAgMIBfhGJrt7zqyamcyQ9bgqs+RtbrLG2Rtn2EPWewd9pG1/yYVZP0V5Rmy/olJF1n/e11QAmApcwSOcxinORLnOQouc1Rc52i4zdFxn2PAfsqEg/uDOGZvI8EJ51yRLEOOIncWS6dPna5aky7PvPOtsjeysYH77ekHEPBnGQhiG8TQccFf7WNRUadyJn9IE5Qr49UDGBYrCRDDHaF73DUmWz5HsecEk+blKZIQ6vHBVwYzAIG7I0a5Nj1W3PjhEo3SpkiYOt0rY7M02Leu5j0cyG44/VhLtkzkK127WqN2vSVzQBmmnbR5q7Yd5vP9W1f7xF6VD8Rv9s8NAOF3SVFjxB5BgJdwwVbcZXvKrpn0me5aa8WR5M5X8FWkxxuDqZ7thV6O2m6zTv1G47QvEr5u9+zYL0n35RneXH3yX5z+i0gbD/RxEMoZedDSZw7OgCBMcm15qrQZgqJ52BLhnD2Tv1DROTGly1WsMtZHa3THoHGzay/btO/UoOv4KF4Q8c6Xq1/AqH5dAwDigsSgBP3arLjx74rG+tIEFKHe1aXYGsOSfXSFNwIRLlZyN1O+UtWxEe0E6G2HMdmbx2radrh7rpVb0hOvfLj8hn/GtYSjQBQ+ihTUXUbseAlG8ZQlUpnmmX6akqyLI9zPfDOYe5rIFL+bKt3s5cIsz1rNOjv9x+CnjDI8HRtczHUid3GcL9O9Z9749Nof6WuERqMJK3mlJf2/oz3694Ol//FoC4wUPmyRKsEzVoC3wcv3WH68hRdKn/tK8+wnPcasljDZ87IzrB9sv0cC37PuNe3c1c7PbQ+6ZrapG1Y61gUmTWBCwTSFhjAYlnbykecwg73M7EFQWRQbY2qAqeJLAceEfC9He+jYbszFalbqhwCHGIdcSTtjzRQTbYXatSVFY6V36YYlrqmAtu4Y49MBS3rQbyQxXuXTMRcau+5q2j0pld2dWOBaJCtgfyp6qP3KZH+AGXKXYVgiJ8LsHqDJ2qbJdWFic0mm+CpLvi6pOiffZ2EgGqh+L+oLwfbpJNYOZbE9b+1gIiQ1846TaPbNn9DsScBkQ/M5FGO+rUEao3Uaw5gVVuXBArG0+PV97rsxO8U+G9ia0vvEv3aX2pMngPJ1KwKA8B42pWvDFos8RnhJeQ9zDEz5aQx+Y278D55El6cLLi6yANKJJIPXtQYeKFlZc35ucHWWIRnTuNoofeZKj8bVJO00dX3jRHLDGJdGnnGpNzHM6QCu3S++rLxeaZxqFCe7FyxfBszLonMQAlwXA3IiKAN5KkhmBeGkMR4FjaBw43ryPlZYvXQO7LtYYrwIaSrxzIvsk0Zvfd1oSermwmciBctHo/BOWj6MRD74LPtWknGIxXbNbINiTxIoUgIE6d78kN1WXTH9p10HGWtjrBLcXOrSr7DgIgDyA+WHG/7dbTRz9o8tylctryzqc3HvNh3vdrTH+97AEb4t8l9w9TPEKGZT9dPPbAstt9b81ANB7Nia0rv3GcgOSATfrCM+Jw6I6evfPQiwUssFulohh0s5nNKJi6q4mCwVlgj9DTDdLOtssdcRZ12VyaKolF9GvvoFCEL5FXQk2bKd6s48O06XlLcOz/8ci0Nf5yMEGoVEhjwm9TpsMmLakrMXnLINOFV9V3OvJdTya0ONU/hjfUFEiEYllSlfuQadhu0x44hzWxkuSD/fDxRGDJpkMmoFzBp12WyvWcvOR+6kvBIoFFbsh/LIaRSqYNFti1FzjrowyZuv5QYEJlIchhRaRSo16eFszIGk7wV+hz13YHA4THwKOsWqNOu1zT7zjrs0x+9Zx4O/MFHisQgo6ZWo1qLPduMOOuHy/nvW8xQAAS8Bm5BKFoMarfrtMGHBSVf237GBl0BIBIk4UmUrtVGbATvtd8gpV8vvcOAtSDiiJCJpcpSp1W7QLpMOO+1a+bmOAIKhkJBxiaXLZVTHashuA1LmElWgZ48w09ezjVW7Tt165p1v1b/mBqjxnZCjxYwTRJgkeaq0o+GTJC9uzNly5slfqGiJ0uXG4qdc5DeV6rXqNmjcrGWb9odP/6em5ubaMx+qX42NDR8lZrxEo/wLSLGtSZ85e+78hcf4F9zkdrpcxSrVa9Vt0LjZuPxCJMzetO/UtUdePH53uzNpf6H61TgwAFzEKNFjxX3I//r62BGFNEXqdBmzZM+Vdwx8LQl3wsVKlilfqWqN2vUeDb/pVyYxb9W2Q+duPfHKhyffXv2unT+NCwfCR4oaI3a8BKP4e+A7V5YyTfpMWXPkzldwjHyv7gTxUmUrVK5Ws079RtN0T7Fo3a5jl+4988YnP1789+9TNR42NELkaDHjBBEmOSI/UlClzZA5W848+QsVHRM/cJN76XIVq1SvVbdB42b/bcvJCDAAbTcrlGyvbDvJv4ODAhXafiLoJNtllMzMDpmVHbNTcr5Z4QJXbtyxcXDx9vPL51fAr5BfEb8KfsX8qvlV8SvnV8Kf9MLVGcFsuvmWWy/RI9p4zCs+8Yt/WotYiJ04dZ4FFlmf+MnLKDtTG2vuYCe6VHKWirpXZQ0QgOKrYYLmcINstJbecbiHenwKdqemXmU3Z4DAGVmY1dma/TmZy7mb5/mYX/AfKRjQ7fufX1hFXLTFXoIlXaqlX5blXN4oTEmVU6XV8I5MBO9Ke+m1yQ+XgiClitSf1jptk+gL+ow+oY/oPb2l1/SSnjucUmznivjjeQFGFzbLAJJQc9qqfAk1ZiRxsBplkJCovA4XKFSpoWKMb+rPEChCMhQ+bNsPu8Ppcnu8PqMqAq/fhXQHLwd9SRgpOrv0M5xaZQur8TvEoHAWh6gVdmITmcJSLGJSmIhSOKbdF61CSxRCV6gKV7ALBREKUyE9HKEoRIPcBJ0l8huKAi54BHwL5Lsx74K4h3Ay/ulad2Qr4D3ueCPlNz1Y8Jei8aERI93D2iZmcONQZ3eXD2G2By9rO2Xos7hjIymJ9Q744KlM69f+h8Gz9WClw6QN8YKnafwJ17jLE55u5yZf/3SB7/jsp62c5iOe7i1PfePYc08j+z1oGHDt0527O/+LYjfCsAg3GwkTNiltJ5HyZ+OHApMx7Q7BRbVgUqFL3QgpC3CkdhGE/9EtE5jU++MbTgpyRUQzVSzzqVCHAqtMiCnp/ak9dkGSb+3n5vkCEX6vbpIfozwopi3sv0t8FDcQeL+pObc/YYrbPy78zS7/7o8+3GJBBjvRmRvWuBdQ5SnrCBJyP282zFr+ibrH9zdEtB67xppqrqXW2mqvo8669gbcIxxzjGb/wrEzML7YPCSiIY/IbXmsG/oQW/7Ez2Tkcjf972VBSyqtuLKMmRARmz5psuQpUqZKnSZtOvk3GMK10afPkDGPPPPKO59887v6KCHcKS4BEiIQRiSiICqiITpioDWVZ66yqqrvDC9xuyGXUKMqRnslQm2djTVESqgvk1sR6tdEbjvWtCb70c1lB6AqHWQlFWebElF4cavfEDl/Uj3sI7/jFOlaTzA7v5/Sr6ivmeVQf8cGfeIab5iJ5lppq4POSJTllnIa6OIFn7DJBuVE7KRp8y646PolTJG6XBQ1Jk0foMIoakqWIYQ4KGpOnjECcVHUkiKPMOKhqDVlnpGIj6K2VHlFQQIUtafOOyoSoqgjTT7RkAhFnWnzjY7EKOpKl18MJEGqkU2B6ZFq8peCMiDVzK7gjEi1+FsheSDV6h9B8kSqzb+C5oVUu/8UmjdSHXoFywepTv8Lni9SXX5Llx88KMI1wjXCNcI1wjXCNcI1wjXCdYg0Amp4/Svtk6QAxQOku4Mhvf81udVYJxEEwQZ3Ix0TVBnla5ocLflbTOTMzRqT2XIrTIHbYCrcDuNVcAtML9wJ0zLnDhhWGjbC+E/bK6EkvYB4RyXtAjonTdqdpNnuYdOlco1QlF+ycUOEzmOCnfOC4dyqMfUIBxeq56fiean5/ZRN5xAeNq0STC3LhDXNYhKrfveA5p9QXgUVWjqosktDOz8NhnYYTDq4wFEX0dwlJF16XaHwKXiZEvxxKBhUE3Ue3ioapIXuDgpgW2YGdG33aoTBmQDfEwjHjfc/v9L+Xwwsb3ON/P0A//B2YLK1IWav50uYIzpBC/nKDbqwsDDaXDLG5dIDtqPCfc/g4/8aG2zNO00e+RVSdAMSlJO5hoZqqLW3/TLwdAvZnVWt55CYjllYf7Ye63nwaP8sML9JhvyV/FMGiSwOLm5etJRRQ+ekZUq5LYvyqfKd8iOrw3T3MUmtOV7WzM/V2i7usfRz+C8oz1e4tTa6FjdjXgUWVlz8xBVW2VD1tfamX+Y37XzdynU9HvqlmIm1IO3Lf0Bjwsnz+5qx4IfF/WT2iyJR+OiI08+IHb46fjc0Lm9PLvTV94fn7fDb/3/3Pn+JTpLB53/bQNKI+iqSCr+ZlQR/Q3v23xvHZ78c/irWJs6/rk/MSehPSE2IBRJWAglTEzQJsoTEVzIb+Hrt06tntx2/vrwKbBrEGcAVoKp5j7vABS96fSZcxtTr2CVgZ7bmckb/8XZuRbu3Ut8adkv+zO+sfLVrQNOuUdHz5zR57P9cWZVbBB26UkN20ONIQrNRNAEShhixmjSwSLQ9O+48+AKDCYMRKUacBDR0HBIycipqOsVKlDGqiIeJr4PMsWq0s+o1aIedRu1zwILDjjrmtKuuu+GOrzzxU1yjkrXLk6CEkYHJmF2O2t0HmayERpyzV6twKMcN2IniPGS/UyPAIyLnaK31XG3gwo03CH9BghHhRMHzw8aThEskubqE8ujlyGUi9YjFRvVaNWjRpstWQ4ZtNmPCpCl9TjnvjLMuO1d9l7z01HMvfO+aHzlpYq+Ws2aeOgB089HDSyegfiADoLYJEGKLUNsF2gRlBNIuEfZC2wNrDMms/aLNIRgX66B4hyRaRHEE2RKqZQzHsZzEdILARXwXiF2R4ial2xRuSXVXhgfS3ZfmHq1VGisKvJblmSJv5Xul0BsG5X5gVuln1X5V5Rfr1Am3W6aHtB5z0Nhpy8644KwTps2Ys+CQeVMmHTTrgBy58qVQkBIRk5BLl0EpVRqVfcZR9am1Wb8Wzb3zv6Z67wNImX8LyJ9XtzC7YQya4L//Ymg/t15YHwnRGyMb6oR2VN48Rjyn81OZyeREsaPMnCP7+XJDs7ObniKGR5jsy6Mqx+X0S0N7ZPFGYlEgBu642SQMp/oC00d0jMb6o9xeZ6I/s+M4ev5m16J099bqoSfjBnbSv7W7lYXJnkxOdkuUucEja2/ByxbkjowN177xAF1K9mJ16mKHXq1YLo9N9y3G7xg49lp2T8pOIBQVgvsP628aqKP0BcrM5RC841VAzTC8oRnGX2+uakf2Ban0RFLMilloPxL06hw1rOfV/szaPdr9pEP78rSgrvBdgk3r3ZgPITuqUnIn48KstSIJK4wkmA4Uzt8ES+HQ1HDUtiiQVRxRYCEP0B2NZt585aaKGuPubnWkXmY74C2C9YDXqPLXk15KhAmhymZgiCGi3EvUFv5mEW8O6A7LkvQNvG8eWS8YT4JE5Q0GXBc8/NLNZVMzn9LqOKy5OTTLZpSw7rK4RGG09pbpMG426FD43zST6ZzDFzkB0AcA7grQc1Dqy4DKPwHEHwMxzUCtHwMAsPCXipkYSSiR9IioMyKs48ENXbUEOKDK2GyE3e4fgtjMZuaowDU1cIZkjF+Wgziz2o8kQpS3r3EkyprR/fqe2XJnRBlz5j7rxFuCOAaK/qr3j3EMYelGFS2S0EiUaWeT9QZxiwia7A3t80dLtG/nw3gLtu+NwFp5EYWDLSLuqZvDmm+lzKjZtcw+9+wOsxf3LoIjT8YMs7Ehervz3joZg01+sGZW35loe9+Y+5OuVxW8sUf70j5XrgnTpm8vHvL95tCrs+oefQS80BthrUeMtj60PvRar0GRV6qV9KG6PbyZ2pMKXtuLf3rw83i03vs6uvGYhi6owYcuxE9L55RFbg4Xlx0wrNnvVg86pA6tyt437ipcKZhtcNDf7bTu+sr7awAbNh7sYL1A/eG8j/F81hogNRAlSQr1ZYDfunRd9OKPSnVz3piDUqduyUj7HqCtQb0RMI6DVEOM8wrce9fUw6dC9JHIdcGP1fO+pAdv4/tY9mbExuiAvqq2epj+UepZVypGY/ZrPgrf+zG6LDDwb15IXUieaOSQoIBdR0wAS7Tg7zcnDyYwDHP5d1XYpqZhRQ2vkk+jlICjGHGjGqlWX8+vpLTWbkOoqtvda4hhu0OqXaoLY7bOCZJpfQh6t4IIenUEWydV6yYl7dVTOiHrryeAgUBRlxgWZWGllYXnamT4lhZjPa9ewjZM5bx3C2mCzjnSB7xHrAVAOQYT2SAUm2PE4FzY5v2hVATbVuzl0pthGnkTBUqdNQkCLF9BqrreXZc8RmqGVXFTna5PgZc1a4ruDSrXUTVkJYq1dqou4wQNZhZprbovQ8klq0OUAh7nD41p7iKDTAqortjlDCXX0PvcGa+daWScbhVSQW5JJ8AWQ8/72PGAKkB6i0QsWnJ8gk4N+8Xz5MwNUtJIqe2lh4ML1yClcqva1DRWvyrcHStDaClcVp+x5Opn9f4aOzscjrzaywPlyCDFrVRnDVWZMZX3Af/RbwhTqgW3WGv7IDWtflBZ8XDq4DGKW6XRbuOCEPuF+0AV2Zb5Syh2NdLjyhAeTvimzP88gHCtOi4nI83wsVqbx+1CeX0Q/sF4H+O0GUIFf8T/s31etjrwS0QD8L7+2TqmCB570fzaUTB6s+V+96M1cEQWL6x+uh84aZLW4pNxiHkLOWry9LK9u6iRMaz5aw1ZXe7eBsWDS3peP7c3oJhVTF4jxgsY+a6hO/fL3flZ67ohAfxNlRw5O2zjIhYz5pxq6DP6TK8RRIEsdb9/qEc/90ig3MfxDFbCIeMbVCSLwb84iuEeanz8tBUgojuEjOE74FT/w2N4psdUeDMF9EKL1w0ie+s2w+AssUaegkAGDHU6gdLZj/8wZzbRaN1XdVuqW6mXMiyDN37KDRupWus9zRBG0K1ppkNYWFdL8EM9SAMWVJpoqqCRbgg997amYFj/OUcrEMYnkqRaw1YmrolyWs55OWrjoz3iKNLbiJpC1A52xYgv57WpMWctpx9gGEkWBc/BNNov0AVKVH6sqf0/pTLldM+E4BrIMKqsZEj1VMXQVTGTO+JwgCvMrd8+ToU5j931I3/mm6ruPizs45HFFdM2cfyHmL49+2x8ktMkrec5KAnT/bB3Sc0E/noa5zN3Gz5Gr3uxPeZvaM9qa4DPS8LEWyEPQp8U3LxDnoJ/U/GcVp/KneT555aKOG73+CYuBf2cv8bvu5JnXcfzbF5hF3Kkj3wYhPGH6TKEAXYnmdHJLy346VcS7IcmbkVNpzDxeCBz5HiXkS610OJWU0Frf5BQ31N2ZMo+8+i2wHnKESqwVuXrZfmuBSYqQsuzqeoHsBEGaJR1bXXq32P/R3T5UPu4btTVKqEy4AiEy8H8B0KOjM4Flm8KRhz6m5AGmVlrujXsZfXDZxcA0QIrpK0u+PF5BtzglrP6Pl2RrkR5WmtqIfWyv+j3OqT87dccbCyU+43GCBOz1Rub3QtcPp7emvzZR4N9PKJn0g0F7FcxX1b8KyA00echjHIk3avVfNWFsoQpurBb096RILY+tryLjRTSh7tnQzWCnrRgOAUD/MrsetLk0os0vDS/5uU2UqWHa6RqLV512yFsiMQnvCZ1c6feiJyJT+tqvTgoaBr9AYVxoryiqO7zo0+v18sDv1oZX5h1wvpNbVsMsLNK97T4Le/Lp1eZZKLFhaRD8JO2azksZt7K9APd4HZdUEsUKxW4B+ft5Ysx99K+6XAx861LvyisxqjQFbzi35elWJ4rCLWqYUxq6t6rK7rjs8r8Wbail2NSkVx3O5HJ61+dOfgW509AIWD1fJPMMt3vhjawovnTLehrJxFsbHSEWlf5heb6zUkLcWP7BDeXiD9BdXFKnv1cQsUiOlnpcQPJgm768En2fJPo88sxAXroe29oQSUtcEkRo56xTRvVBCRM6he7G9P+0WeSZS4++26dyiHHw4k3N8NlVTkNw+JPlcHzDKty3h6AbeqP9E/EKlVR03wW324WKuGfobn5hU2FZopQhwWvqFlq5pkCK2gWtI9ThSeq2Q1ZY3B5bdyKyU0et1f7Au/DUO4s+zMV/oLfWwbXkyZUW05opHWaOcckdqUmqDO6ZOYPAuUbbZnuI5PBxcnNROXvRlKRD0G+dhApVtXU/mq3Xd32dn8m9ZtuGYASCOaQ3B7aul9uIsgQxndWxNLdqGuIG/PZgNWTO1nt4AMlhSO7L2k7LKQtLnbsCpDgOk9yHnmORTn/zSLxIk8ZRS/wC2gBt7hErCZtBZrCi+LS+/C66HPxxVZT7yeQ4RNwENzErtBLb1IoBHx9P7QENsDtN9NmzqR6xdfbhnHyRU+FF3MQo94eWr0yEVXVF+DzLChiXrVFosD2oG8va8Ax4NkTKanG8NEGjrqPkM1Xe4vDo0siEIbN+G6S/X07PCSzR12lWNjkYPnxSmWDIOkw3yP1UrcOPZeKVk83Pihuron+ALpp0rfdkxIsXkyMuD0s92tZN3Nk6soOIZ1PGljOM+X600tXbkgUl8OnxtkP73Hof1cSMWDHIaXtDFwH/8DjAbL/boxuB9r91kJ8BNG5jGfVixpMBJTYN/l9pg86ZyKFsfeMhZXpMBQ2LwwJV4mOnUnRdUlp3dOzLpYtYU58HquNzmw28NEJ2J0icGkNvF1ku5w5t6N/gZqGGZNWgxe9oid95XK3TVdU3rmErU74uycl4GNQza5uNZhHom7cVxzPyDbnAxnWZQ5cVNtsvrmxD11PPU7IVjhS+h5NsOZVx5K9ZzwPlq4pqzK0l2Bw67mCiVZHOJTLB5MzI0Bol9n3zH3/sWkz9i6p69V0xkM/GpECEOpGp9XLJpZGqEhxgZwsUmgdrvdzfsrnoiy0f2V/9DRhP1abGsvtLe9c1hcJ4N2e1bBqxBUFMXiXSM5tUn4Lx8i7/Ju5WTGnk37vySnkWzxutYqjWlAV0QKz4FovAvWi3v+6yMVL7BctoCk7xWetaK8DNap9kzw/ORV79jiZvc9vba3wRG/1zh/vddjucZ3G56e2HW7vfbhc05qa0aYDSvE1EgtKw/yh7dIRQc40Rm31MoJUyQa/akwsUkcF/Z0odsSKeZ0XHn/tWyQVP/iU+vLgR22QbdPIzx/IXzvHtQ6XnbpDmktgjLevlSiC9hlzatEvz/zEjcb271rHb4aSQdp3LH9Jq1ewLEtrjymBy+/noPQuZjh4ohOlGOpr6sWr+8b1TKfDtd0vk9CNXj23DdlS2L/n5WeX1Z3umqHNwndpBRtWu6pxgMTdDM3hpfbEdhRf7H3/R59NnQ9+0spbdX+RatMDlE7SAtJYZQj+hBqhIEccnY7SdRldbvfmXkpnze1D+5GUkQ/hFyQytnoI4mODcIzK9luPaheWKo52TLflj/idPW3kcIdk8W+Nn9s2OQQOtcYfK+iZJ3Zc/M94zXyZlD20uWt3zKtR+2NuyfCP9cX0N5dp7VNT/6S1d10HsUCQ5DB3M0ep2xOQw55k8S/zs6Ko4C33VvL/ijz0CF5Uyg5FnEglrP/rhXV98weVffPBqhK2H0ObryK+yieH5SA90aRZWd2mUQI5MN+PTnbL2rfywS//dCPuaUWEravOA/M1DCgPiD4H3NI5bepAb0WGdgT8ihiz/d/o7UOg1Va7G7Ifu9sWWYeb1Ti12+34Rrp9fNsK0coY+RJmee2PmSTElglSBDlD+f2+qwFVtep0MpFF88HNV6L142rMVpTKyuiPwQviCq/D2FQVJIUuxEFL0ptlRm2E2I1hkYflLyyePXr8xJWDWmkAINlPAtOvCdo+IRivBtce3dY98E4ITxVdvDI9d+Tw4sLJGeCqpzxDWNyQEpLNjaBkPQT8mT0qwZIAA2t93xbLlgXEZ7ZKrX5g6MzPo6xYacvOFmfQwmpubzNIxwDW+DAuHj92+uy186djta6RXQy1B0GaHg0rUaWFFagik7E1nZUwn+XghdWFKL+o6QgFwxpX9DIvmV6pl3vJ9UEAcc5d4umFJUu7ocfefY8l3HLvvyTuxmkWfOnlh39eEUU7W5+uuhGfvuUEGzjB1gXSqs6wqp+Nht2PXhq5vrrwenFYPdXh+HDIc+UKAoqb2LRq1t69B5qbQ/74fleaZKaiSjJdz1Dp1NKNIxXSqV2qEkUdv7qzRVilUAiqrO2CKiXAkvEVvCFtcenaRKIefCo6KT+rYQJer1pcXBx/DfAUTZ7/kzF3IkwrbmzH1o/8U51S06zaANBVloeJPVy3pQunys2SuZ2ZRTE8MC2CZ8pv8Z1pPEMYEK+pE1a3WQVVKoVgY3uboFIpMK3Ut5lLjF2VrXi298IqSyqNi/4ck307JQpYmbGxtaLY1FnRitm/43wRN26WSuJi3sXk3AZEh/8dhOW40W1NVWv6oDyhG6vDe+DyzkrJzK40w9SR64v9Naeqg1y/m+FHZkp+dWfQpbPNz3emQ4NhC6uAzrb8omSWQuhjQYZv1cQ6E4g/xGtiIJO7VD4E8l9hQPU5BjgdJtCK8juNdViF25ouNt8jgqSHgP7P/ZcBFsSHCKJLBkxd8Vne0Vj3Sm2x2j14dCJpxxsZ4GEXtPPLDlvhWh+IF8QPAX94pdCSBBxakvDGjgvDW/p37t7cO3xp0dtlZceFmuzuXMDQRtdwrHdedmwElUPA4p/ZAfpfHP4d8qv8MPd2s+fjVpfHx30u/1n9auj64511dzvvbjvy+EjB687X7bEvqt5V3Rh32uO0/+eaxxnXBt+1vduPLB3fgtvz8yXPBZfP18+E5uj0Twsc2snmrGdix3ZoELzgQi4lCjf1KSGzgCuWcJPY7Hrf8rUBmApsmNCV5lVHV7vh64q1hkuANx6/uJzIodsePxcafDuIFFow5elOuL83Ds69OF3IfRH53jcc++Yyup9rYgnnvhe6t1biUCzX8epsuTteZkBT32Sg4gViiYCTxGr0KbUNxFTg4AJXmmctC8BzJlH5AYfXJAfiK6s72keRtjQCErMf+/3bw1tyGbYf64NgByCJPwfpeq3W4k1ZUTLIfm71o8w1L2Dht0VhOO8LaL5aHs4kgOYBnwfP+MP7wUDPMKbTi2YmHxKJ8mZQqQBGPA7603LlZaZbhO8TgMTyJmj7BH/0RNhPI24oDOnD7xt8GUJJKEGj77V2Fg3moJPBgneZa17Q+OFsvP+rh7b3usHR6OR0zNl2tiJ2rHSwY1erpWtze11NvyFontbYsT1ckBfgw9835DyAEO5LDEtVKdAcUjxSKVVhBMSoMmzw1f2iq5J9DPUS60gukzEuVVTVuJwmGdCwaFg+jEU2BlHup6F7QQn+ThScVUVAJrm2VkNTPXCbOtoHOzuGGqvETcIXA0VFLJNje0+mrhnu1t+xE647Df7xTmJY8yTK31hqnBidYJYyPbPzC/XyCk8vJPy0B7jKmOmbWq4tJM7c8w6PbczXsvkZXam9zS0USlIKfMQMgoJ44YE0TGqFriQGO/Vu7T/4qO/CEH9H4RzCgB6I1lNQ/zwq/e9QfxZG5vuhGr19In8n8nUrXwXxVOKqURXEMwR4AFo7qlcnIuqeCk2A3/3oBoO9h8Hfw0PdQoUfd9CM6NiZCGwo8iM0dLS1ok+7BEz0y18+S+SxV4ZwAYU1OeUbTJV85G66Mbz1+FtCOVsDD9auULbi3MdjE6vTc1dP8Uh/fvh1vZBeFhE7G+Gj9OXiSrmR3zKadwe7NjnSkIxrSog0hSSniqvGUpnRfrvuN4wq2bN5z5stscu0fQHTSjPSMLs9sjWqiFfBPHtnowoOA3jGsxZMS5+izglahnYOdHb2R725pWOgp71roAlZetwlKTYlTJqQCJcplHBpol8u9fcALaOzc7BJ/ddVtSzvEkhNGXojKt6K1KbLszgyUiaP4I/pkRJ5CGbm7mZ0UczAD2LPjg48iu262YRXeOB4GsRHtApBrW0dsHa0D9bR0sM/uajCKeXl7W3Ykxe8hMxMDC8uDiPSa7CCOJL6hPCYLYOFEf0crOtrbyrckYvhgsl/jN6e/lamHZAhIj0uIlKUMiSDAJ4HfBob8YeGgu5HKCOF+QHpSDwuFOcIds6r8uWo3bIwJFKd1WftKBzMIQogN9TG3y7a7nkOJkYkq1ThHAJ+stc2w/2pgyo3LpdOoCnrJRpsTrgq6kMMogPKc4/AmkEAyE2iCsjiceRFKYUIlhOm2pbuAkNlATwn0tFCLyafqShRFRNUruegpyBVkDWQqYnk3VJbPrgC0p0Zx95wt/R9JBwBchsav990DAXZt2/BwytgEBoVSWWu2ftTm7W1Oa9GyoGFuz9f7+IBOj6EZkZL81V6mrxkyWq+T81WyTUf2aXOYbWD/5iqLaWWd8hXCFi9w14Xvwag8IEURUgSpMsL97qII5dCQX0P0PAiSx9r4mu7nlLFEzcS/EiPWzg2Mvx5Jan7EaD8CWDaL/GlnNAyBqjJjSuMM48DJlMIuaQCUrPPMZ8lw7Jhefiw+6TtkmZvxt5hT9RPFYg+/Iv+sr8ffDMN+2bpI8um9LL6P/a3pbNIXy+mp1qbk8as+L8TxBbmPxdGkLVcb8wkyt9UapoYnZgLMM0opAufvtjlZsF2r2RrC9OZ5lFnmA8qYEsCdV3MWrT7Hxg2QCn8pxkaMJc/FWxsyhqMUTsz3Z6MNq71J84iwZpSzXc9jSY7nZ5RVYEfiRZ/84NNXwdlVLxdTzd7odi5GF8vpnNZU/ZAdKYT2+3JaMPXAcRpIm8sZsRt/WCGCxIFuRYlUSQw2JTE7nxvjZ0v9BwysJDuXvqlx0KWKZXpY+4HXa87uck9VpP9wUogrGS1vM5sLq8vKSmvqyo31xZHZPszkrj+dGyEP5OTFMBAQ3j7o0sppdH7R6f6p6CIw5mULjNPKDTzKF2ZfY3Nq7dlouSRkX34mePqcBkOFyCh9t3+dGOn7qVuYrUnpvJBDgDY5NL0VFtTUm6mmOkkKAklBO5p+TXPn1xVay5LIplzS7Qp4HsDfA4ru7F8Bb/LoXGXwxSVx82A8VzKea5c4BUI7H5UmASwrV6PrSgrV8gTSRwGOPzfP/uXcjr2dHAyQ/7e6vXd2MyIL2z/jaIsdb65+i5h29rG7HXNYF4cHvs3m38/asjq3LjOa+ssKujWZX1pviDBaEzkt1uOjd9+feZrl2b9ukpMdJot15UJjnBTxzEogRGgeo3ETZkNDcQIHa2/5XqUHSUKvf4qik1Jyu8y19V2FagpZBEbfBifQtFaiszG6sxUQhSvf+abyVCwh5tPAClUqSJ4iNAhk+mPZ8+hsGOksOnvG5dGBwoPP1Dsc7CY7JtJ0Wo7jgsDHJGeXZ5vamsyCzEBGHCdyC8TLsejwphBkJ1DLRMVFUf4Q+VDrRNmc3RDyY0auByFaqDpVcNTmACOFDVUcCW3Rjena7nYEVt1Owf6psm56aq2QFNSRq+m41/hEDw/Q+snLSjOXGk0UOBZerMuFbG/lsNh5tVVPiDucGzc6jROF8H3RQDgueVclyTQMgR2KBImBXQ2ZGFNJSalLJHIYfirnv7JLmV37OkgZ/rbb3X9sH1mxDfReKRAryk21d4kbLFvHHHs4XAwyywmww031OTUaON5ZgYef/SyxlAgiDcaEnntdSfG77y8+ty5Wb3OhCNpbHmf6SCUhxrEoHwOB2aKJK5KZkjs+lgH69Vc164FVH7Ut9mxKZwcq3FjjTU3PTFRxPAbw0nImob88tLKdCUex2mYfNoGAUI+PzhSHCJNwX3yRwUtx7az7iMwWgJn88P6o2PdqumsqLpasN7ekmtfH5Wgs+W/Y4DRqbrywvLmZhMX54ry44slrgoCBLmBFX/RbefB3erdu+aHhnbOH+YjO/+fSKyNSc1qz45RkSnRquz2rOhUik/6040m3R5dw1dt8VX3CoI/WFwsr9UbC+otsSVkYwlaABpooWhB5MZGczkTZyyu0EnBs4PJHK66yPw4ft6hvnhDO1hMiQ27FBkicTXynJOBG0JDz+GQEp/ChpM6QPw3U0jrTiI17GOqKbV7srtMw/xlmvTk+PH9oNi6W8VZ2qKKmjv4besatznuogiwDIQQspWLG7A6N9p5bd6JjPj3crEhv3LY2rx1cH5iqGzxsWJ8vaV4vQWXmG7H04r9ie7qGVbCHkLwZ4vAU7mCRPsJHa3/aT0rT2CFHrASmopdsLWio3NnQSaFIxaBWNBYGU3bX2ypt6qVxFjepzNvUqEg8Rmq75+7QtCZeLL7QSwIVw9U/y7ZwoBHMYjUsNvfbZqd3Fqx+FZ6cL3FbN8byVDb8cXSAGJusaGgclN7c0bkHlJgYJkN31OxgoyaZoUh9oSYAWs9jmmb6WAw6PYruSYXLUJdjsAdbUVBSSm5jEp4T0Dy/Rpa0mLMFdVGA4tQps3LkCHv1VFcWYlGiYvuAbPf6vvBgTh2xKPIXHeXWH19sz8vsgjMahKT5VbGL9754euL+cJFa2z5jpiIWCPQrkP0/Ji/9LEydm6X8TCSm5FAEbKA56OkZI0l/zi86Up8FKdv5ukEBOT+CRaID5GpiJ8SUMHj3O+nbyMjBqKp0w8bj+wbzF+8o9pzxJFnX49L0K4VuBeWtzVvLi4QA6rXgGx0YWIcCsFCG51TZDw6b6jI58sbiLxTP7EMyUTKgKC3f1kgnw1GlIDjz5GfU/rL2/HQNKWjMpItwIkS/gF4/T8AmFGSlkhzChPzY+JDRHQIKPHsWFCCiNziV7ROdtmFGIh328LcBvF27fUFxfcrub4sLhODAwdlEJI6kVwkLZv2iH5kTeX8v0pVlnOk9E12ooBm8c1Zq5SvyQ8BBXPRKsjzL+SMVXi5EfTvzDQpWzC1KGZk1iG1a5Vb17sKVDj7g6RIjGvl3+hOfzDYxSEjjn0ksf0yPJi31AGNk8VLp4qCTF+EJiBaGMPnc3F4UEBja86om+uf9c4PXTwuAQPfAzzdlS6FCnev6sBgJ5NMmSZmZrYg8+2VMlsVssMPH3crjiZhCDA7KoF+C+ht/n4F/gRwlPDERFKGu0f/9gPiaMEb7v1xjExbjiAZK04Ee7cNSlen0YC8yj48MXDL4gWUVmDxOvllZ5LrHqA3m0l1OOxVowRmNCjYfklupKQfOJvKg/+o0g8ipYZp8YvWC/KXIlWlVQzoBuy7AS2gO/z9wMVlZiE8T2ta/2j8zX0zbJw9rTkBDhin+/cvYapbkXl2CpmdErntV1DgQfT2+vj3dufz71X9+GoBtc9HCTiv1HbnC8DLyAzn0+SCQM8PAZEsUNoTgUQQe84eEZmSLhwZ+NkT9ulEcBG0bNoz+vKayoV/Naos59LmUXEusUcl87gNoGr071jQj89RDcJTJ5dVW+JCQIQxwhB4xP3xO56djGXEiPIKFQ5xBR+y7e79CYO7hTmWh/UdPozYOIJnJcgI4Y1IrGxfp+nZ5DI479vWGvjou3Lo+5Mt33qGwUPgcMjfowaYK+rnORN/HPrOSCiGok58/WAKErYPA6d6/NmkkHngDeVaNR5MpeW83OmBbAH9MXoE6GdUxXczA5Fk4kFUSe46ElAnvr4/BUHsw8KpHt/BHCG2ZHLVndZcYL7LM1FIpToTjgzvRck9PBzONBBuM9IB78vPSShohjZBWv28HHhv4ynlLsQiNjGJwjbA+tZBHcx693yluSjwWFbQMdVTeYFZi6EV5sLAo+Sovij/8rkKOlClY0f9WsY7+4oOLqOfj1Kng+3XtOyObOfybjm07207mp+rftHbm8Q5equygL86MMBfnQYHRy9bgFPreouKYzy6GMWkptMexPkb/Hrq9GU6GPLRkmnpERKWWlan7/Ez+Mc9oEFwX71xurJafW/9+Au0dOov5ItogshoF+LNe2uNQPw+2Bp2X9ttiBv39t40SXFi695+brX/1joXHmRv0xMT/cq7o2TEbUZbxFnxA/j+1GEAm8G7Nn4og8DN1MpdYpJ3mVJt2ZCnMPeGJjUCaOQ/R7+q4L96Jqd5fxEq/wiuvCkpZrwdw2yRJshxUOtgbGLd9POSnNWcxyWWJXb6kaYKNoOHJsmy8Htcyz4raevfZtQoNqGPu+uXp96eeXcl9Ul1bK207vSU5BWEFgyuk/NV0K7h0bUIeGMS+te5KTzRmmoi3eCsosspdIqc7p7GKq6J0spoPm0cMJ15zIl2XH6SflJ+fAPrK45GW+ARSnO1reTBMvzfoxsV+MGUIEFdUc9AT19AS4BCCc260P5LhcSZ/MyXxY5G6Nho59KXNPrtj6lp/52aJ3tRKpO1k5dfyOsNZEZ8PJkZHU1mJsZSGCQff9k2bd8a/0Z5YMel80WtSTCWA+K0Hi7V8PVWQ5XrXg9BireSkfhdCx2EgB1KAspiYTyiHPWtNGiH9A2UP5pDgoI/tDDdzteM+WA+ip1zjKWN5Ldj5LeC0nSXPJcCY15uHLjJ1aXpXTNrim1kK4vbK2rTmQGWu8iwuIoYzgHjAd7i+W1L3F75GHlMPjY0NzRW+/X8XZInqn4XEQq8YUVtlZe47miP/0c0KfCbhP58S353X29PiG1AiipUf7H95P4B5xIAm0H8Kzgf5oj7L62vYJN/Y0pgxzSijQ1nOoSd1sLFWr6uzVDhwlgLVfdaaSAHurBBklhoMomPXowK2oY/C00eJdiHgh/IJBdMyQH1SRCVtXOjRzNVTqaT5TQPy0CNVUr1aUsCk2nHN1AX5UfoR+SL61lHmMZr52uGvDG/aJ1zDKV15LejiW+5pSoxkLLDkW7bZO/c9G0zY4ppZIqMzdW1EVwXjaWhMJT8N5k8ZZxSbc0xLnC75CPkEflIdLvlu8m75R0Hx2D8f7XBaRW3z5pmTzSfmDPNTYqv9TbndAKXohi4VeiXSAb3/pSU/hIDYmnUIHFJCqDEL6pI+Stx7xX6pQMwx2y4arhyYmjex/WtYSyUz7T3H65QGAJJMogOUP4V+wJh8LpYykONh6fKD083wrJsBO3PYtWtatsonzYAaIRm9VYsmhb9BPNszYbQ7NBeJQ7HKy8oqJgzOWua3d68fc40N4nmPDE9AdFnRUJ0pCdsdfKRmx/5TxJXzEfhPO1Xn/uBDN+SBqlC1JdlksQCcLVh5p/hdHJZLyTg6CUEXuVugtXf+Wi9TQ2g5innE+OWeZx1FmcxjK8fmtBkpqT04SnilOimprJxivbQKrTRqDIYlPUpujrP+3/+gelQSEaAtV330PRAfzvbvA74Z2CcieMZwCTSUkG6ZExy4F9ThdFeAUwCTQXS87DcuDcQX2MtBVcrLUubmcosM02pU6fLpLg6cq1RZqS5Mi16i86akaG1WvTs5l+M0X2XPq3c+pjh23UYwBoN6TxZOyfoeN9GnBEfa8oJDZPFttEU+xW7047R2kA380LI5XNJH1werk0oveUmI0GSYN0I6iUR/zs6ev/tNCYmfmjUVr0eGOzY29zQubm9rrq/OGgkUjBcm6uiI5TS1Ag+gYgSZSlQbALG+b5Cr1QpdCKRIlt5q6UV5t2PjzrHInAsMJiFgzwWPz5qD6SoLk7Rp7bmtALsJI5pqMjEQW8ThRUZg25gl9sHwkI/YgXkS+Vu3npiDYOdaEYauCnDNUMwCpG0qSNcq2MDAQPBRSurxauOl/i0oCawqH5RrtljqCu9fKWszjAlzRzWSUnVOTQmkQGF4ZOExDgmBe6ufBjMwmGDq4690sDehbghYZEJ+VIBy9xAkeu3pcn3FQKR3X3UJ7JrbBef9jqFM989PNRj9HdSS9sdHyfZ740aTCQT5IbRg8nNHWXFoqTMNPjfYDacQBTpUFSKFkFMxsUz5UJYZc+x+NY+9Q2372Av3waB6m/ZzYWEXAQPrGyO9/+4e/cZr4MIRm/+I7VqjU9NXXlZSYt5ox3V9SfyuV9D04nenRdsMDh+9OQYEpG+73gNMqNSVxYpcb+wEc72QGBPBHgn71gPzSpHFhAI1E3Hu5GpVToDkuZ4d/CblWkfXwuO/tdWH9+f/kcO/n5Op5krLtYemNUZyg7o1fOGQt3MAV1xOrFfKtqszZAMzcXT0tsZEA+rM8Wb+mVpDf8AdwbqsnP0WXmFOuL7tLthURJqohaHuO9V91s1i1ErEjLqqll8ocTVSQTMjdoXNdH4bAaFqFdHJyTCNUPIolEJ2ZnRiRsyMjnAhq3lc/0ooTiUnTbl6JCe/FduqcevHm6/uockgJuLwAX2omhxIXhkQ2FD8hnhmeaiom+lF2OEZ9a+Qv/5UIBC8TAYVLIAhY0UhKP4kRHoZEE4FiK5C4PegVBxWOi1fIhk7FjHMZ+kecQOxPZqM/yeZ30adrJ2LO9Z3tKx5ROcKYH+zr7wafq84y65688gCZFM++Q/bkGgN6GQU9OoJ6G/tY3g9yi7qw2YlW/UjO0HMORRY5PfTgHDctRYD22Mc9Pym1YUj1iLRoqYjFsJvwTWrxhFya9I2S1AxC8xVl/fdm7hWoZMxGbJRXYMgLMMT6fgcL05kWQoCscgE2t3gvx2+vrOAoHVKHR+64nNMLfxKp63164Qygw+4aUqwGZnz1vugO7istCy9Y/uTYimqr2yz8O5LM3H4ibEtyzlwZmBtf3BpOzVSTpwk3RbTo7j5fR29PyQYvZMS5+8Ck41U9QUMgWsvXqeoKRcGtT2zltXd8E5zNer5dMB/tIGILbv3TG3aWjX7Gjm6KA5tGnH/MiEMStGRSFT+FntWTGpZEqVLEBamjHSh61x1XcLANFpaotMZYwKRvgoCVjbitUd4S/FjCgprslOAR8Y5CYlpWeXP6UsOdTnr+sKEFNj4I+wUJGLMdlZAP47BHYuqnBFjTN6H+2EWDY3MBTxSVWu6p7K4WkZP8+QHkc3CUTX3y7O1kS/8TZ+xzrLFseRGDH0MFEiww3XfyGu9RyuReFPuA7Njw8bDq3Ip5yaitdbIhMz7JI10gBiTklpftVwe0tU5Qlmwjwx/g7dSfpVZIQUI8x3sH7UeVR4n3PbXZhBTpLwgQxoXApVN1CUWzRXEY7IZxGUpmQXbK1sT3q+KxitxmOSQkGmu5fcxQuYgLKvcGckw/gvIaxCZTCv7cEy1Gv5pJHXpHnrwIGJvOMh2pRb/XwvxSoyapqZMEJCRJ+hhAHiVLUFitWqwLFu8/taT18Dl3NFrNzk3MBLp8KjBT+PtlAhb/WbHpDrhF/bVAjXxpqtUYUYbzT6jYA/TqKe6NtKrNvgvtbT18DlsWJTYuWGpYbA9LSHeyRNHGbpZsJB0+GA6WaexlytvS/yt9B0rcg7gD1b30F/61FjTQ1czhWxstLUINOTHfanQnvjusInxGRFTgHrJtJzVaawBRAxjt/b1oVa1FbKbapfu/rH887CNVweK7cxVm93aqAOwi4bk8dJUVsnxHaZAxCYeS5NxKDFQdPUAGKbTDwefv9rRm/saRLrtjHWbhPXFOU1A6yyGdhiMwYBPRIsiTX7auVYEas2k2usXGvIw+Baq9hsyMczJp4TsybqrZ7eAqdyWkwfu8+lz+YiZ+7YFzMWyNbCUsciSMfj2UPYypYy9WGc0uaF2qaHwo5Dq4v5gG8Xs0AKS50Qbpvrg+4t5clGsmd0fi4xq3O9xRNTuxDTSorpHb/JLWFVKaBrdxs4s8kqZlEOIJHnGR2Z8crbrfuFymwalaSNeCuRX2lFnrTlIszuZh/YwqkxfbqYOb8+N6CcJak23/yysPUiv8tqKPk/2FpYahyv1Z7P7zQyBF1Wc+K5uk+bDWrMmr63ePpU2i/fnJg5jz43oGzwJmaMxxZL1QeyO2xF2oUpz2dMH753bkXpPzf5fNP+d9vAsp+i5NeW1Nn/55S+r38yln5Tj40+h93g0nwjigJ7cbKt5JVYjyqIwSn7QqfWZb27NoXxfhzvnKbUyc4Fwwnv68ZdknUSjiharMMrOXnUBWDMvhi/X9jKR+PCKXRr5RXfBkxr79B9w8cMDUCr4kM10Dodpaub7dXSogUS7QvtrPP+1Jrxc5672NXNEzUlbTq7bQVbN6ObsdViuKCE3/p0W+p2qbtWIhf0iR70tx5geagi9LB1W3wbMDt7RxyD2R7YFyqDJpzSWHkruV3qrpV4sZ1i99+5T8DQAbATaE7eRvWLpp3TgX7tBcr7YYTZsT6vxHZUbyn0nDoBC18ZGj31kXyvn2ZTtuhNFiIkK7Dd7WD/tT3oATHdPlPKBr1fA7Da5wZRQ/XiIXxu832+v31uz/0ZKuhPvgY+Brla/Pe3K69H/5QLJW2Epg2HyN5WF7vY/U5hX3LuyoK3vzzd8ZdpNbY1u+iYB5FaV3k4o2kp9Wepv60XXvxzhUCnNGBzLiZU437ptKbYhpivrSa4X/vl8L4Y08ElDCPvhwWhsT6XspWyF3ouOwEcAmm+tuakbVgJKBNNoF/e6/cG7NW9jwHlRwT4iwFz0wEvQStc8SShRCkia4yoVl7AP9w7wyVquR29dA+t5K/7De1KwSCIMccEo+qtOzU4AeiOwcMj20EhlZhUP6gGDmxxSrdWYsCtaDt0aDQMkpM8G6L3KgXLfiiJw69vI6bA5CmOyY0RKBhnSI5yonY0iGrPGImMOUw8ve0DcvUXk/Ci09QPBBTSWBUnNDYdvr/T396za4cP47PscAd/itNxCe7AHjyLf6Mf9Mj1Orvc+/CZt3AEj+e38T38DjfiPjyPf2Ec19lTTerjeTjRlsc4L+IXewEOwniI31R4je1NfjN/ialiJbHyWIv9O/sv9n8+/au+2Y4PydC6Wc1r84eYPNZm/9z+rf33z/iKbzP/f4V24q35dUwar9q/F4HNBsLPVHMM6q7bKFFOYmdS0GSIrnEChwwtLutIOuikJAUKB8z7hJU35P9Hj7N1TcID2DPCWplf94ehkLKKPu8tjNaomn6cI55GAAQakxyDn1cNSvy6zww4ZDEU0PgJNEwx29btAXJNoaiwD9FY6K7QkMC3lv2htrEaQ7DOIksAl4TVRolJtCLyRIupX4oHIWHe9bB6LZbdg+DS9JoB9vLjflLQ7OcXf74wzkYWZRvYDwjJ8GqsBMXkS6TPXGALBfvRuGw0iR0b3pjSHHv57GSB5QgrWK6KXV8qMXafB2vrHHCVmDlJiYB2QaJFEpJdaBJlu5uQnNXe6cD1AW26/IC14hCdhHJrNOdSmsuilRAYjSKBfDQe4QiRQQWjJHyNQ+4WOvMQeN/MzsWb+05ksF3D2gjrASwbGYzaeMEP3POWm3pXHCHAdQ2PjeYRmeYE8C6ydmwQ5SViA8VHni5fM83YjUR0hS11ASVTPAepQYOoc+QyNCL3damuZQIJpcI64VYFt0GAcj4OysvFJIYtsAz50QRVr0uMgAc2NuIDNHkUEQEG4hItNFTQyg67EEMPcA+Q2kKPjqthp/1EzeLM1m7JBv9KK0g4+Xl55SXuTBrHf9zWrmegwqH3gAjik9jhMPfYwuPpV+0OX8vWudz07cMuRPyN6VSaTat5aKm/Wvc+AHHf8b4FNbrwFaF07xofp2yio7UkYbMbHNXkxxPXslKrcYwPR1+IO7qpSQN+qaUergESUaAMeUhYd6TeYkWjEdKXrFOe3u/IIt1EUizzyCMU8KQSPUoDwqHp9c9D+qqU6Yf13AYs/YitGmnTygRSwiyONBWN2M+DAViyYEBrkZG2xRSHiJPTL3l/V/TToiWtGq7b09iGDcNZhYtwwGuxwThQ0ASnlPDEJseJ4IP6/cOCff0dCh39fj7YX5bJN4AL50fEQd7EzrezvXPyLPblEeoWVvpl6snZVRrD2UJWqQ8viQzmYV9tnfvrlb6k5vtrS//wDGn1/scl+4vv6s8XcNXphUjHr3MXfsd+7L279//rqvOfX2MupF+HEkz+66Zgk8o8wodn4i3ewiA/i1ZcmRNXcAV/LafFR/+R+He6pX9yjYM7UxhAa7QskpiUBnGp7oKTjAjgJ7JNj9UQf1NkP7/k9/JGyGz9CK8g1UWKAifndGYDUzukBwa0E3VtCo2M6LxfzLseHVgyHe8LQm1GdMAiM+/DB6KJLg3ghV1hGQUglyEkMI9TlJ1gAmJI57yKqEDuCpboAgDTpnqhJEMT+MKgZZp2Og/zGWiQk24x7WaXwo5JojL7FlYY2fO57HdC73G/KaRsA2aE69Sck6NJBxq7LVRKFx+WUpDsB524F9VPMuLXWTmrd4K+B0ndkH3W+sfCsbCiprAKOmw48r6iGQ620LY3tfWjR7H9nFZcc2/kF97R/sSjpNUrg0tTs4VST8LFSysETs/s7z1LUI2dPDlT+CT88G2BpyMmxcr0fw0SRdTRjg+wEo/VqJD8wAnWZMFGKmj4ElF+S6sN8/kIn7a6MVDUbXDBQ0OmpHUcSCqZrS0DscHaHkl95+QEjxBz323qzdC1i9MDLNBIjUAgnBhwt3hZGrfqzS2dvTjxmsFAogpTWm3dMlGvJKiaFny5SNfCE5B5UpOK7NGODDW6DSmPItvAKARCwQ2MTYxRZjXuI1aoGgYdpD6o1fIsoCYTQxPWkXDuTRznNDy3rC5mmqFdcmFGqAvr/8OgPyQIKzJbClOidmNJtx6sW7zRzkfIxAc+WyHrbWXBJkEZ8csHpiw1WCUgh5/SoLHSbMgtaDtcrQxIJHs7kgbYpOteOYljfZc/hogOD/Zpu0NUgzN1Zt+cbLYipBrytz61kvTegzsXt7Pm2dqcu8UTvLfztbE4L1x9ta97ruHeeY74OnzhsZN0wH6IX17qHTcXRs5Vg+1SF0ELmW/pZiA3ajN6pAj2ngiHmG/7FpcbUB9tbhn4SPWws02/7GSnnrsnOnTWPdvtdGrz9k1aTdHxFtYGZ1uXsaHK3ix7DqeqoPMEdL6XFT3aR0n0lOSRV1iZ4MFBt61Uo8Ou/UTCHJ8h1lJR1b08J1vkGCEZKgpbyCCV0bjYW5E2HCfSOasNoWWkMybE0kouFFt0CJCchXftWAvxUYj+UJq78aXFJq7Q8pEd6sLBl/AleGbpIXpHelC7rmYx2CtXiUusVTyqmb43Fk5GVbvb/otJRIbbwWa1IqjYz6BtvBjljEp34QFbnLrRUwKBoABlH0DORvJS0A/ifHzpHnnZfcDqssSDYLsbCiHQWAm/0yJuMReisDDwPXa1f375sqwNV8jRLL6g/6FxhzaFQtJdKuFqrKUz019uJFvpG2WVAleaphS+pyezDVq7J0HVRAGQsWWQQIlVoddh4kqDJZaDkrHzgudeN4Qj+jMaZJRRSAeqwLiuREcJ+ZODRiZEaFQ+BvuD0JmRXi2HVgiQTeJFgr038R4gtWqWVXfTHrKkpUZKxxTk02Ql3ljw2tuEY650IaMFHhHRxOGjzLuZLBQE6OQce9j33siHnFwiBulaWhJItex6Vud9PbT6+PiLEvZHruppq2kYi9E0D42A3I984VEcRA3Zx3l4ES/hETsY+p43rSYkn2i2FFJgXylfWccJQ+EdOLPkKyr3AgueO60JvvyzNqkdIh/YP3pVtbn2qPmdtdN+J/BO4nTbiFErQeWPclml1Iy14lt5sp7j8/m9e3JQ9cdTGrxmZZXXc51pM1YLYUqNEhCg0z7PS7Ps9AhvyVlTCDQ/EwhFPmoxQK7hkuvddnle8ZMquMmkxUIO2phHZNotm6skVybvz8RF7wbKMjMmn2uD5ktSznLJJAfOKslVXJOWpoimgWa65QFdkhR7M8ky+75kE5CdCydNbB+j7JaqyIpXjthmwnMuM1M6Dm0oK2WJm8xlfzNGS2XFCQY1t5qbqkO8omzd0vrWpXbvUH3W8r0QL0KVapofb4v7la1/dc8njU7CkvTQFhd42rqeWGSa3rppkDShIVuskMp1/FP7pvq22Tiak1Yz7ottZ0eqGo0Vgu5n2h/LNoZErF1wAQVu0UyKSpHlUyumUVCBtf4cg6m3lCM9vUzHP9PUMvuOE++4nm2HukaS3U/KdIE3/yyMTSrBbzGUfnBLBYTSrmBYDhktWtTSBDIVwxauJ0MqUjgylribKxT3y0xAruKMnZbYeZOdj1RuNJ2n9mM5gmK7gBT0StRaPb+VjWDMDxbZRZE1FEaqBOUuXCfIsDMLihVULs/zPSQNtsgOoMA0ppBKPa0YLneZxW6LFS88X1wQ3RuumVGSsc5Ns8/KS6zog/kMB14PqqviC9bJjcjdhhBTpdsALMQmCUvi17BM/uSJnFDvzYs3yr9OOAhaii6fzRW8o2SAh55eby1Dx5wA6DD3TphM7vBEWOmCvTsd3vBSLiWDbNCeVy85AWps7rYeaNtDQkL3U+pVOHL3NR2FHl0pLyT2AurJxi5+feCY+9ng3I7Ntdl5dSl5ftG1wHmnEV5g1SbPTe6KqzIzcNQHe1ia64QZjB/mzHHxdUSMKzxEMSEX6WGm1AwKaJV0bo2K+tjmL2Sr1oim+KxGjhgClFa2HGabzA3y1lpuhLHrki6X5s4iqX/hoCDVghVw8qh+k0fwYPdIvgD7XM+XUsk6QzO9ZsgZdrFujk0wu3prWrWlveTpTDsmdVn6IwGuNWQYnDw488LZccw2y4uHCNG6MECR+csUEpoQVJjzzfGerMvuOiQMSjLK5q7Ooya6POcc3zyLfnNSd/d1sf+Gyenu6HAxd3uGR38vhjyeIARW1hCEFBRVZpL/09swsuFrLKZ21IKrtRPrdKI4ziS7qlCqpBZqQWa/XdWGn2kx3OipwlmCjxN20xowc81eG2kD/sov1P6POW1xfOX4wRH+4R7fYJnzPAP2Edn1tWry3a5vXD+7wk5GTKQdlIfSSS3Kb3W7riT9oZ+4pNQSEVNmapreNqvLkJPMx6a4HDVW5b/FobGrgFLJb5TDUKfPmixdyKl5mMsW2xm7BC8fr/K0OXA13Whx1W3bnRABG1nYH0nIqOS4LKHCG7XzMSTFTRdJSJvHZYsgOTU491m5Pmyh4QkPSDv7vkNLQpoZLMXWXufhZ2Cn/G5fP47FQpTUMcWWZCeTLDsPMJzUgq6DSO+lfhyjhoa4joOFM62qDGPcdycd1f1Ih2HA3nEYDASmLuzGbtywR0TXiT5lh96NIMwdTqvPOD25z/c6kyN+90id8TwzoK05iOgzaLjf04OOdzFDmocbadceu/ruNbFrq7ZEivE6bAITb9c5BlYnQ8wcbpxp2Qmd7WMQYHOk1WsWX0mF6ZD8Ga91OyLphIC4phI+O7akFZj2U7enA7UBlXrF3HA4N5Gru3EztbTGJSnPNg9oDyb93iLt3TwBa65w2Q3XpynrZJS3OgNK4dUsaEGibwNFnLppnegd354yzX6eweYkjLeJNZOenH0CkwDJVh8pWlEnnE1nztHVYzuovi6JscjO/uWc9DwTRAIpEg9RRNCJSUZ0aHuj5PyaaJ9rEkbkWtbMZoJBSrp4MmmqSYyZb4DWiemGIQtlyDXgOQiteriRpuriSeiO9AGIMntleX+UB0klZcYWXPg5C7qfbFEfSuyq2ty1n17hmbPrQ2W/2Z/cHRlZ2omx/bh5Xh3z+cNParE6Zmt9zkmjIv3/XKY3KoZoJe6ZJW2d2oUtP4ejYxCmnsxf1Di+DrIVAFs128UrZRsLEwMpWv2gpWsM1TMbXNnLWv3kRXQiB83msMwXZN3hQl+vKNmm9IQl2I09+UBnSAPSHnOF1VxsGkafZ9iJH4FqDSQFBdlP3oYbQe+Ac4GeJUG6uqFEN/rkbZluSlMu5vxca044YKPcXdGzSN1MUZ4eFry4QQ0liOX9bnknpGJ6QW7s7/IvJ25wPh3bf3g4dkCQGiiQ/awOp5sZDY68cVKV6BrgUlmhCEaVrqzAX+BrDDp8RO4VPOB3RY5fv8Lfi4E8h/34rMd5+4LdzEYC7zzBiV58FBpYX9fNRGtffxfOhRfyqGO5dQfRE742XE8xw7Zvtbjd9pKC+KlpIfMkXRlauPZrXWWDECe8npgoZIsyP8ioPAYS7i74qldc0PnnHq1xB0rn00pP+ynj19cN54zV1zp40/kI2UNaY1basR+QaqsQUWVxIqECULnaHQGsKulf0L8VGpB7S5uoKdOKTb8j/TjXs13jTWizccjINeljOVu9W5ymzyDmCy6di9qkVIhnXUYHL6GSugSVagXkeAH4t9h0T5XQyYDWryATGESApkpt/Fa36IqMl0s4eNZN0pXVPoeVlF6JgOmdOTc0ZrtWHCFQb5BEeTTVoEO3FMmQfQG1nLAa5aCc1mfYeDqCqTFDoul4bqCZc1CpCoQMnJ7KGMgKfWmuu4vg1MdhUgZFpjg6hWazMqqIHah76gaSDMU2ByZI7olOKyw7Xi4VD3mFEKHSPz+L6kJmxsVL2UGrZ2Wfq1YLnY/1Xmae2JuVQJenY4sqiLL5WdVBz0qa4xKxhBMBmgNlxytnJOdMBjPZNItof0Wgs8JuNO0FTDxLatfyj5Qc4g7DT7H0/680G0hO9vim+bg4C37ao+C02CPnBMRZEwbSfIcTOO/lwjhVy+TA/YmyEYCt+mt74BbDy5fwP+zwOwBfctz5rnB3GV0/e3EIfKw5f0cIzUfdrJeajhLRdhdx15UeX2pL7/MEDznNknEf+oP8/f8tGb5qxivpS6r2H4Vc7O1jQ6vS6y1j0MMxPEQzDFBDGq/Bcej9Kdi6DY9fSvup3M9VA4596jnSzw2MFVnAhvljZs1dMhwi6CTU9WDSHUPldpw443xkivo29nmPl9+9wl8xB+Ep6oxmonzoZzXV1ondWjBcYR1ZWOZoMYQDUNDtwZ8/usM8sbnTFUVEwOK+V1/5iUMpYBpGclaIiei+2WCxOk1hQ/3gNozg6A7T98Loc+hdKI45muSqscjT0C3CdL5myM82iSmZIMc3VaR2KAen5mwjcRcu9QghE1RcK/5pI39YbB85bKRXhCNAvnnYM6MI6At/GMFBELzhA42sf58sUaPnTNPAyZhAmur+64tNrAWQVX//XiLJAohmpe8PuvFRTQ7bCa7jYtkh+oURzBVUu4C9wU/9TL1rtJkYEAw5BHCFVBWFgDdU+OEdSLjuZ7eBCYM5U2jhCEWsFJ8aDIspGri4nlHI7NAOZnamO+Rzg8B67r3U6FPoexhfYVwEQAgKXDFW4oAsgPvMYizveb3Py5S6u2H6KXcEmj6BICjIuAycpgiG8DU9FOhv79QbxfsHgCcYRyit2m4pGyQ14ikbK+C14w7GAOnEBBNg6i6/SXFmvL/yVWOm/gZMnoC5/2FAjGoCZqw74gwQkBX/xOLNfG+Usso2zJLKkam1dnj4j8Pl8OYl0Ubu1y0GbirFYYDsgLvxgDNb8KbTnrmEHSMFaVTvNHAquW+cXq4awPdKuIQluIepdAAmYTt6Y17cG7iL+sUxtMMMXMJI2gXDsBrtMQlLFtjRfG3hnrLNM3xsxId3yqggQB+MQmM0EgICKSrAOJtgMEDRnL5Co4WXjwknoplBMoQ5xEawCHeLWQyObGOxuEpgcQS5zHLym3csFyw1N8oNrx6FU20yAFjW72AI8ZYzArolMEzoTjES7R4xCsKJ6xOT1onLlP/NmNk+KWfOsEpn8Z6vXq3e8k+zCyVLaLSl3krE26CogjP+f6DTBfzVv/m0dK0y+q/a708xV23UTTzEz3ePn+qCqp8mfU3XpoR9ogy68TsWUMfP2umIKlw53PKAalmOuhHLrtcjbmo511WMU3sG05c4Z11nQwzwphtSsigeNpmugtxvBHe6wdmgz+TMYOV1e6jTDaFSS0aVRgmOC9k2QbZXT7UeozOgltKnBqtIl1en0gUAKTvf/5oqXf8SRh6KIiafVrUeVMpulKb0N9GqEgonEkhlNOSn7zy4K+GzEJW8NHkQbiNfGqmhTEdJokg7FVjocHEdljEMp6hZeUM6Iw33JSSBvTUVyFQSUi7MvSGeQ5U6AnOHD/U1P7vz6NPcxBLySZC5DW5XSzgwxyq640VaHqZABFZYrxdTQM3gRDhjTv2seSjrDjITEA+pHK7hd/pZCztR1W2naYaaJU0Yci+OOe+Sp8L1DnCYYmXMH5HAUGKk6TvU0cuMjKEcjHy3haakyhwNA08DQg55OQ2mNFODSJsqv6VhwhlKB0NEyqU2TIvLJUxjtIRhMX2ugGQ6SS0w89wikRVLTjbpkgAkDRfBEURqCRjiKWsXkBRjQZHiYUbO/G5KlEhLXxFbE5JV/pB/thL6PSg9gFjyRKLIugg6gxInmtT8Syg8H14J4xbK+bFCIZ4q8ypzXfhMQfR7eBQLlOBO8NIPFq7z19IHlXd/zdVqRCAMVcxsLVijICrMkuUYDa1eAuNaj+ig814MxAS9OTkhFlRTK0eokxNyBkMujLmyyzP32HF0QaDyCe2W2+74N5EvvyIChgkUNjB/Ab0VSSPae1muKPfcl+dhISANOmgB3q8IiOrR3u9IwfvGf8Igig4pvBiPQkH3lXwrutM+IS9WXDhRxUvwc/hOSozQdxFjKogkuiLFxVRYrLgMSuzFwvaZjc1fvIQ4firRGkhSFjmT8igZo6LFlewfdAxMrHix41tljlOlqpKqiCs5QTz8hAkSJSQi7mtikiSkZFWTqlGrzsbkUhpV7xCZd+RSUlBSpSi1b32UJr1OyjJkUqfSkCaLJo1p6ehllSpNugy/lN0JmeX0fbny5CvonPN2G7GTF28APnz5AQIB869QkWIlDEr1t5Eqt6ji7uNvjY1q1anXoJFFk2YtWrVpZ9WhU5duPXr16Tdg0JBNhm22xVbbbLfDzk75vbUtmZsAgWattQ/EmIusXKzjidIuu3PiTE2LjMq9kQ5bbI+90Rs1Zl+XXLbkiGVHTZtxxln2HEs2Yb9JU+qewtn6/+8HanXaevu12dK8gxYcctiipVz95n2aYP1CBNls2CaTdMbRDNnVEcvtsN1ER9tmgysdc9yJjncyKAcd2nXr0qOFxg+aXeiU084465zzLrjoksuuuOqa62646VbP9WHo9cpjbzzzwhNPvfS62+7o5Hsbn3jqmedeeOmV1954+7nT3F6Y+iscw+FO1uM+QzWPcj74feBGNNfwU7+D6iiGgpFXD/wqEdpFHTfs2LUEu8ujR1Uscp3SQ3Vw3a8vbzl10kKd2Or3u9Psu2+nZuSxoHk2veSCamuSHQtay5pum3jjy2mv9MgOxcCSelipazoqFn92qWhQPLiHxz3MDE+xfH8Fho12hk17ElM82Y2kqblbMD33b1bpNIv4xak0F/mXPnbPzxbNxSnM45t57xDHgiX5b/WWBOh46o4F69nE3qzjmL/ZjkN4M639IhzYwsVJUVIgNbp9RdSiBdq00+0qnX4va2lRltiwwq4Hsa7hJ2aTrgOnLoBe8y9vuL62cQnElrGlRXwZ/755C0sU5DK5BFKl1fcZpCM7nBaZN+fOyBjLWEaaolPTPm/YyfP25W53dQ8hxywYDYsnvZjWlPiC0+s1fZjlsPUK/84EXVlUpnXYx32SgqPqRCN4Uq1lBE+fxIGzx09NVxj3Vu0hS2Dfqh17VnnI6nCyCsrqfcrqI8gqaEu1DxP0HgJBQ+00yKNBIOhwDYKGeiJoUInOPXBn1xJLLbPcCistWL0wGLTn7rgGLPVhwYIFCxYspLZb39sqH/+Uj8ynJ9E64/itBKssGnCTFynzrS1b6OcoJb6z1MltYiNibmR1hoj90XALxTk/atQbjesucU3wDum/U9Si1kl8a4JlQcBX2jEhgZtfPzBXGR+lN+v+6R2u7xCh+y5RnE1RWbwcpXwyPEPgFsa823bM7fxi6q2Uai3zIuN+J84LNHmYjguSvY8q2vkhUU2WWsvKP2KeGhiJFP4ZjZdllLQyFpJ+fh54Iv78tJ/Oxuv/3YdYDZOiXeXF1OJc7SvSolWUOKNwrRkqdLXi6qvku5ZYapnlVlhpweoPGNuCAk6vBzH++5lvLMVhy5GKka9x+WGI0VfnHyWieKO/GzNs3YUauPs+fTPyFEkD6+s38pXlwE8ptekiz2BdGQWnw0PsroEQnMbmxpnXBxnmIcFhi9uE6X1+sofuWcfULXYj0+pqq95jO7rmL16lZHb4oyNFg/JVK7bBqbTNc9g7Xm/PjxS2PeNc52av1krlfRrr4xCuuFo99l25icZpvY0ufnoYLdAKdYuEan/+BC1Z352vnqpNh6/lmtXs5rTYLeuWfcyOeX0vSt3e/E9Vmky28mN5Uf4vN5WflX8T3n9hZBEAAAA=) format(\"woff2\"), url(../fonts/dbscreensans-bold.woff) format(\"woff\")\n        }\n\n\n        body{\n          display: flex;\n          justify-content:center;\n          font-family: DBScreenSansDigitalRegular, helvetica;\n          font-size: 14px; color: #282D37;\n        }\n\n        h1{\n          font-family: DBScreenHeadBlack, helvetica;\n          font-size:48px;\n          margin: 64px 0 0 0;\n        }\n\n        h1::after{\n          content: \"\";\n          width: 56px;\n          height: 6px;\n          background: #ec0016;\n          display: block;\n          margin: 9px 0 0 0;\n          border-radius: 3px;\n          overflow: hidden;\n        }\n\n        .subline{\n          font-family: DBScreenHeadLight, helvetica;\n          padding-bottom: 0;\n          padding: 0;\n          margin: 33px 0 120px 0;\n          font-size: 24px;\n          font-weight: 100;\n        }\n\n        .smallText{\n          font-size:12px\n        }\n\n        .block{\n          display:block;\n        }\n\n        .table-wrapper{\n          min-width:1088px; max-width: 1288px; margin:120px 64px;\n        }\n\n        table{\n          border-spacing:0;\n          width: 100%;\n        }\n\n        th{\n          font-family: DBScreenSansBold, helvetica;\n        }\n\n        th, td {\n          padding: 10px 20px;\n          text-align: left;\n          border-bottom: 1px solid #D7DCE1;\n          min-width:50px;\n        } \n\n        td td {\n          border: none; line-height:16px\n        } \n\n        tr .no-padding {\n          padding:0\n        } \n\n        tr:hover{\n          background: #E0EFFB\n        }\n\n        .ffamily {\n          width: 110px;\n        }\n\n        .colorWidth{\n          width:150px\n        }\n\n        .warning{\n          background:#F75F00;\n          color:#fff\n        }\n\n        .error{\n          background:#EC0016;\n          color:#fff\n        }\n        .error-type{\n          background:#EC0016;\n          color:#fff;\n          padding: 1px 4px;\n          margin: 0 2px;\n          border-radius: 2px;\n        }\n      </style>\n    </head>\n  <body>\n    <div class='table-wrapper'>\n      <img src=\"data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iNThweCIgaGVpZ2h0PSI0MHB4IiB2aWV3Qm94PSIwIDAgNTggNDAiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8dGl0bGU+REIgTG9nbyBmaWxlPC90aXRsZT4KICAgIDxnIGlkPSJEQi1Mb2dvLWZpbGUiIHN0cm9rZT0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIxIiBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPgogICAgICAgIDxwYXRoIGQ9Ik01MS4zNjc0MDA5LDAuMDAwNTkyOTQzNDY4IEM1Mi44ODQ1NDc3LC0wLjAyMTE5ODM4MDMgNTQuMzQ3NjQxOCwwLjU2MzQ1MzExNCA1NS40MzE5NzAzLDEuNjI0NzkyMzQgQzU2LjUxNjI5ODksMi42ODYxMzE1NyA1Ny4xMzIxNjQ2LDQuMTM2MzYzMDIgNTcuMTQyODg0OCw1LjY1MzYyODQ1IEw1Ny4xNDI4ODQ4LDUuNjUzNjI4NDUgTDU3LjE0Mjg4NDgsMzQuMjI0OTI3MSBDNTcuMTMxNjg5NCwzNy40MDk5OSA1NC41NTI0NjM3LDM5Ljk4OTIxNTYgNTEuMzY3NDAwOSw0MC4wMDA0MTEgTDUxLjM2NzQwMDksNDAuMDAwNDExIEw1LjcxNDU0NzI5LDQwLjAwMDQxMSBDNC4xOTAwNjA2NCwzOS45OTUwMjQ0IDIuNzMwNDU5ODksMzkuMzgyODQ3IDEuNjU4MjM3NjcsMzguMjk5MTM2NiBDMC41ODYwMTU0MzcsMzcuMjE1NDI2MyAtMC4wMTA1NzI0NTA0LDM1Ljc0OTM4NDYgMC4wMDAxNDE4NjA2OTYsMzQuMjI0OTI3MSBMMC4wMDAxNDE4NjA2OTYsMzQuMjI0OTI3MSBMMC4wMDAxNDE4NjA2OTYsNS42NTM2Mjg0NSBDLTAuMDA1MzQ4MzgzNzgsNC4xNDE5NzU2OSAwLjU5Njg2NzA4NywyLjY5MTUwMDM1IDEuNjcxNTE1OTgsMS42MjgzNjU1NSBDMi43NDYxNjQ4OCwwLjU2NTIzMDc0OSA0LjIwMzA0Mjk0LC0wLjAyMTMyNTcyNjIgNS43MTQ1NDcyOSwwLjAwMDU5Mjk0MzQ2OCBMNS43MTQ1NDcyOSwwLjAwMDU5Mjk0MzQ2OCBaIE01LjcxNDU0NzI5LDQuMDgyMjA3MDMgQzUuMjgyMzg3ODMsNC4wNDY2MzAyNyA0Ljg1NTc4NjMxLDQuMTk4NTMyNjcgNC41NDMzNjc4LDQuNDk5MjM1NDggQzQuMjMwOTQ5MjksNC43OTk5MzgzIDQuMDYyODYwNDksNS4yMjA0MjUzNCA0LjA4MTkwMTY2LDUuNjUzNjI4NDUgTDQuMDgxOTAxNjYsNS42NTM2Mjg0NSBMNC4wODE1MzIwOCwzNC4zODg1NTc4IEM0LjEwMDk5NDA3LDM0Ljc2ODIxMzUgNC4yNjEzOTAzMSwzNS4xMjkzNTcxIDQuNTM0NjYwNzUsMzUuMzk5MjExNiBDNC44NDY5Njk4MywzNS43MDc2MTY5IDUuMjc2NjQ5NzksMzUuODY3MTA2NSA1LjcxNDU0NzI5LDM1LjgzNzE2NDYgTDUuNzE0NTQ3MjksMzUuODM3MTY0NiBMNTEuNDQ5MDMzMSwzNS44MzcxNjQ2IEM1MS44ODAwMDM3LDM1Ljg0ODUxMTkgNTIuMjk2NzA4NywzNS42ODIyOTgxIDUyLjYwMTU1NjQsMzUuMzc3NDUwNCBDNTIuOTA2NDA0MiwzNS4wNzI2MDI2IDUzLjA3MjYxOCwzNC42NTU4OTc2IDUzLjA2MTI3MDcsMzQuMjI0OTI3MSBMNTMuMDYxMjcwNywzNC4yMjQ5MjcxIEw1Mi45Nzk2Mzg0LDUuNjc0MDM2NTIgQzUyLjk5MTI3ODgsNS4yNDQ4MTQxMSA1Mi44MjQ0NjQ5LDQuODI5OTcxMzcgNTIuNTE4OTE5NSw0LjUyODI5MzY5IEM1Mi4yMTMzNzQyLDQuMjI2NjE2MDEgNTEuNzk2NDQwMiw0LjA2NTEgNTEuMzY3NDAwOSw0LjA4MjIwNzAzIEw1MS4zNjc0MDA5LDQuMDgyMjA3MDMgWiBNNDEuNzE0MzgzNSw2Ljg5ODUyMDc1IEM0Ni4zMjY2MDc1LDYuODk4NTIwNzUgNDkuMTQyOTIxMiw5LjQwODcxMzQxIDQ5LjE0MjkyMTIsMTMuMjQ1NDMwNyBDNDkuMDk2NTYyNywxNi4wNTc3MzUgNDcuMjU0NzY1NCwxOC41MjQ0Mjc5IDQ0LjU3MTUxMzQsMTkuMzY3ODUxOCBDNDcuNzU3MjcxMiwxOS43NjQ1MzggNTAuMTI3NzE1NiwyMi41MDUwODg5IDUwLjA2MTI4NDQsMjUuNzE0NzYxNyBDNTAuMDYxMjg0NCwzMC45MTg4MTk3IDQ2LjUxMDI4MDEsMzMuMDgyMDc1MSA0MC4wMDAxMDU2LDMzLjA4MjA3NTEgTDQwLjAwMDEwNTYsMzMuMDgyMDc1MSBMMzAuNzM0ODQxNywzMy4wODIwNzUxIEwzMC43MzQ4NDE3LDYuODk4NTIwNzUgWiBNMTcuNDkwMDAzOSw2Ljg1NzcwNDYxIEMyNC4yMjQ2NjcyLDYuODU3NzA0NjEgMjguMDAwMTYwMiwxMS4xNDMzOTk0IDI4LjAwMDE2MDIsMTkuODM3MjM3NCBDMjguMDAwMTYwMiwyNy40MjkwMzk2IDI1LjQyODc0MzMsMzMuMDIwODUwOSAxNy40OTAwMDM5LDMzLjA4MjA3NTEgTDcuODM2OTg2NjIsMzMuMDgyMDc1MSBMNy44MzY5ODY2Miw2Ljg1NzcwNDYxIEwxNy40OTAwMDM5LDYuODU3NzA0NjEgWiBNMzkuNzE0MzkyNiwyMi4xMjI5NDEzIEwzNi45Nzk3MTEyLDIyLjEyMjk0MTMgTDM2Ljk3OTcxMTIsMjguNzk2MzgwMyBMMzkuNzAzMjQyMSwyOC43OTYwMTY3IEM0MC44MTM5Mjk1LDI4Ljc4ODc0NDcgNDMuNzc2NTcwNSwyOC42MzYwMzEyIDQzLjc5NjAwNjcsMjUuNDI5MDQ4NyBDNDMuNzk2MDA2NywyNC4wMDA0ODM4IDQyLjk3OTY4MzksMjIuMTIyOTQxMyAzOS43MTQzOTI2LDIyLjEyMjk0MTMgTDM5LjcxNDM5MjYsMjIuMTIyOTQxMyBaIE0xNS41MzA4MjkyLDExLjAyMDk1MSBMMTQuMTIyNjcyMywxMS4wMjA5NTEgTDE0LjEyMjY3MjMsMjguNzk2MzgwMyBMMTYuMzI2NzQzOSwyOC43OTYzODAzIEMxOS43MTQ0ODM2LDI4Ljc5NjM4MDMgMjEuNjUzMjUwMywyNi4xNjM3MzkyIDIxLjY1MzI1MDMsMjAuNDA4NjYzNCBDMjEuNjUzMjUwMywxNS4xNDMzODEyIDIxLjA4MTgyNDMsMTEuMDIwOTUxIDE1LjUzMDgyOTIsMTEuMDIwOTUxIFogTTM4LjkxODQ3NzksMTAuOTE4OTEwNiBMMzYuOTc5NzExMiwxMC45MTg5MTA2IEwzNi45Nzk3MTEyLDE3LjI2NTgyMDUgTDM5LjQyODY3OTcsMTcuMjY1ODIwNSBDNDAuMzIyODI2NywxNy4zNTQzNDI2IDQxLjIxMTc3MSwxNy4wNTMzODY0IDQxLjg2ODI0NzUsMTYuNDM5ODkzNCBDNDIuNTI0NzI0MSwxNS44MjY0MDA1IDQyLjg4NTA5NzQsMTQuOTU5ODM5NyA0Mi44NTcyMzU1LDE0LjA2MTc1MzUgQzQyLjg1NzIzNTUsMTEuODc4MDg5OSA0MS43NzU2MDc4LDEwLjkxODkxMDYgMzguOTE4NDc3OSwxMC45MTg5MTA2IEwzOC45MTg0Nzc5LDEwLjkxODkxMDYgWiIgaWQ9IvCfjqgtQ29sb3IiIGZpbGw9IiNFQzAwMTYiPjwvcGF0aD4KICAgIDwvZz4KPC9zdmc+\">\n    ";
var htmlFooter = "\n      </tbody>\n      </table>\n    </div>\n  </body>\n</html>";

function getSystemFonts() {
  var fontManager = NSFontManager.sharedFontManager();
  var fonts = [];
  var sys_fonts = fontManager.availableFonts(); //has to convert them to normal array, as {sys_fonts} is array-like object, and is persistent, so when modified, changes stay between runs of script

  for (var i = 0; i < sys_fonts.length; ++i) {
    fonts.push(sys_fonts[i]);
  }

  return fonts;
} //import sketch from 'sketch'


var sketch = __webpack_require__(/*! sketch/dom */ "sketch/dom");

var document = sketch.getSelectedDocument();

var sharedStyle = __webpack_require__(/*! sketch/dom */ "sketch/dom").SharedStyle;

var UI = __webpack_require__(/*! sketch/ui */ "sketch/ui");

var documentSwatches = document.swatches;

function createLink(cmd, uri) {
  // encodeURIComponent(URI)
  return LINKINPUT + cmd + "?msg=" + encodeURIComponent(uri);
}

function createNiceHTMLLink(niceName, link) {
  return '<a href="' + link + '">' + niceName + '</a>';
}

function createNiceHTMLName(name) {
  var lastName = name.split("/");
  lastName = lastName[lastName.length - 1];
  return "<td><span class='block'>" + lastName + "</span><span class='block smallText'>" + name + "</span></td>";
}

var checkSwatches = function checkSwatches(context) {
  var docName = _global_functions_js__WEBPACK_IMPORTED_MODULE_0__["documentName"](context);
  var docHeader = "<h1>Document Color Variables</h1><p class='subline'>" + docName + "</p>";
  var tableHeader = "<table>\n                      <thead>\n                        <tr>\n                          <th width=\"400px\">Variable</th>\n                          <th>Color</th>\n                        </tr>\n                      </thead>\n                    <tbody>";
  var tempOutputArray = new Array();
  var output = htmlheader + docHeader + tableHeader;
  getAllSwatches();
  output += htmlFooter;

  function getAllSwatches() {
    documentSwatches.forEach(function (object) {
      var objName = object.name;
      var objColor = object.color;
      var tempData = "<tr>";
      tempData += createNiceHTMLName(objName);
      tempData += _global_functions_js__WEBPACK_IMPORTED_MODULE_0__["niceColorHexAlpha"](objColor);
      tempData += "</tr>";
      tempOutputArray.push({
        "name": objName,
        "data": tempData
      });
    });

    function compare(a, b) {
      // Use toUpperCase() to ignore character casing
      var bandA = a.name.toUpperCase();
      var bandB = b.name.toUpperCase();
      var comparison = 0;

      if (bandA > bandB) {
        comparison = 1;
      } else if (bandA < bandB) {
        comparison = -1;
      }

      return comparison;
    }

    tempOutputArray.sort(compare);
    tempOutputArray.forEach(function (data) {
      output += data.data;
    });
  }

  _global_functions_js__WEBPACK_IMPORTED_MODULE_0__["saveToFile"]({
    filenamePrefix: docName + "ColorVariables.html",
    content: NSString.stringWithString(output)
  });
};
var regExPattern = [/[0-9][.]/g, /[A-Z][.]/g, /[a-z][.]/g];
var checkSymbolPatern = function checkSymbolPatern(context) {
  var docName = _global_functions_js__WEBPACK_IMPORTED_MODULE_0__["documentName"](context);
  var docHeader = "<h1>Document Symbol Structure Test</h1><p class='subline'>" + docName + "</p>";
  var tableHeader = "<table>\n                      <thead>\n                        <tr>\n                          <th width=\"200px\">Symbol</th>\n                          <th>Symbol Name Structure</th>\n                        </tr>\n                      </thead> \n                      <tbody>";
  var exportToFile = "";

  function getAllLayer(object) {
    if (object.type == "SymbolMaster") {
      var objName = object.name;
      var objNameArray = objName.split("/");
      var objLastName = objNameArray[objNameArray.length - 1];
      var objArtboard = object.getParentArtboard();
      var objArtboardName = "No Artboard";

      if (objArtboard) {
        objArtboardName = objArtboard.name;
      }

      var link = createLink(LAYERSHOWFUNCTION, object.id);
      objName = "<td><span class='block'>" + createNiceHTMLLink(objLastName, link) + "</span><span class='block smallText'>" + objArtboardName + "</span></td>";
      var objChecktName = "";
      var objNameChecktArray = new Array();
      var count = 0;
      var m = 1;
      var iniI = 0;
      var pattenlength = regExPattern.length;
      objNameArray.forEach(function (name, i) {
        var xc = regExPattern[i - iniI + 1 - m];

        if (name == "x" || name == "x.") {
          iniI = i + 1;
          count = 0;
          m = 1;

          if (name == "x.") {
            objNameChecktArray.push("<span class='error-type'>" + name + "</span>");
          } else {
            objNameChecktArray.push(name);
          }
        } else {
          var regEx = name.match(xc);

          if (regEx == null) {
            objNameChecktArray.push("<span class='error-type'>" + name + "</span>");
          } else {
            objNameChecktArray.push(name);
          }

          if (count < 2) {
            count++;
          } else {
            m += 3;
            count = 0;
          }
        }
      });
      objChecktName = "<td>" + objNameChecktArray.join("/") + "</td>";
      exportToFile += "<tr>";
      exportToFile += objName;
      exportToFile += objChecktName;
      exportToFile += "</tr>";
    }

    if (object.layers && object.layers.length) {
      object.layers.forEach(getAllLayer);
    }
  }

  var exportToFile = htmlheader + docHeader + tableHeader;
  document.pages.forEach(getAllLayer);
  exportToFile += htmlFooter;
  _global_functions_js__WEBPACK_IMPORTED_MODULE_0__["saveToFile"]({
    filenamePrefix: docName + "-Symbol-Structure-Test.html",
    content: NSString.stringWithString(exportToFile)
  });
};
var exportSketchLayer = function exportSketchLayer(context) {
  var docName = _global_functions_js__WEBPACK_IMPORTED_MODULE_0__["documentName"](context);
  var docHeader = "<h1>Document Design Language</h1><p class='subline'>" + docName + "</p>";
  var tableHeader = "<table>\n                      <thead>\n                        <tr>\n                          <th width=\"200px\">Element</th>\n                          <th width=\"100px\">Geometry</th>\n                          <th width=\"150px\">Border Radius</th>\n                          <th width=\"150px\">Fill</th>\n                          <th width=\"150px\">Border Color</th>\n                          <th class='fWeight'></th>\n                          <th>Shared Style</th>\n                        </tr>\n                      </thead>\n                      <tbody>";

  function getAllLayer(object) {
    if (object.type == "ShapePath" && object.parent.type != "Shape") {
      var objName = object.name;
      var objLastName = objName.split("/");
      objLastName = objLastName[objLastName.length - 1];
      var objArtboard = object.getParentArtboard();
      var objArtboardName = "No Artboard";

      if (objArtboard) {
        objArtboardName = objArtboard.name;
      }

      var link = createLink(LAYERSHOWFUNCTION, object.id);
      objName = "<td><span class='block'>" + createNiceHTMLLink(objLastName, link) + "</span><span class='block smallText'>" + objArtboardName + "</span></td>";
      var objFrame = object.frame;
      var objFrameWidth = objFrame.width;
      var objFrameHeight = objFrame.height;
      var objGeometry = "<td>" + objFrameWidth + " × " + objFrameHeight + " dp</td>";

      if (objFrameWidth && objFrameWidth % 4 === 0) {} else {}

      var objRadius = new Array();
      object.points.forEach(function (obj) {
        if (obj.pointType == "Straight") {
          objRadius.push(obj.cornerRadius);
        } else {
          objRadius.push(null);
        }
      });
      var objCornerRadiusCheck = true;

      if (!objLastName.match("Accessibility")) {
        objRadius.some(function (obj) {
          if (obj && obj % 4 === 0) {} else if (obj != 0 && obj != null) {
            objCornerRadiusCheck = false;
            return false;
          }
        });
      }

      var objCornerRadius = "";

      if (objRadius.length == 4 && objCornerRadiusCheck) {
        objCornerRadius = "<td>" + objRadius.join(", ") + " dp<td'>";
      } else if (objRadius.length == 4 && !objCornerRadiusCheck) {
        objCornerRadius = "<td class='error'>" + objRadius.join(", ") + " dp<td'>";
      } else if (objRadius.length == 3) {
        objCornerRadius = "<td>Triangle" + "<td'>";
      } else if (objRadius.length == 2) {
        objCornerRadius = "<td>Line!" + "<td'>";
      } else if (objRadius.length > 4) {
        objCornerRadius = "<td>Complex Shape</td>";
      }

      var objFill = new Array();
      object.style.fills.forEach(function (obj) {
        var tempObj = _global_functions_js__WEBPACK_IMPORTED_MODULE_0__["hexAtoRgba"](obj.color);
        tempObj.enabled = obj.enabled;
        objFill.push(tempObj);
      });
      var objFillColor = "";
      var objFillArray = new Array();
      objFill.forEach(function (obj) {
        var objVisible = "<td>";

        if (obj.color == null) {
          if (obj.enabled == 0) {
            objVisible = "<td class='error'>🙈 ";
          } else {
            objVisible = "<td class='error'>";
          }

          objFillArray.push(objVisible + "Hex: " + obj.hex + ",</br>Alpha: " + obj.a + "</td>");
        } else {
          if (obj.enabled == 0) {
            objVisible = "<td class='error'>🙈 ";
          }

          objFillArray.push(objVisible + obj.color.name + ",</br>Hex: " + obj.hex + ",</br>Alpha: " + obj.a + "</td>");
        }
      });

      if (objFill.length > 1) {
        objFillColor += "<td class='no-padding'><table><tr>";
        objFillColor += objFillArray.join("</tr><tr>");
        objFillColor += "</tr></table></td>";
      } else if (objFill.length == 1) {
        objFillColor += objFillArray.join();
      } else {
        objFillColor = "<td>No Fill!</td>";
      }

      var objBorder = new Array();
      object.style.borders.forEach(function (obj) {
        var borderObj = new Object();
        borderObj.color = _global_functions_js__WEBPACK_IMPORTED_MODULE_0__["hexAtoRgba"](obj.color);
        borderObj.thickness = obj.thickness;
        borderObj.enabled = obj.enabled;
        objBorder.push(borderObj);
      });
      var objBorderColor = "";
      var objBorderArray = new Array();
      objBorder.forEach(function (obj) {
        var objVisible = "<td>";

        if (obj.color.color == null) {
          if (obj.enabled == 0) {
            objVisible = "<td class='error'>🙈 ";
          } else {
            objVisible = "<td class='error'>";
          }

          objBorderArray.push(objVisible + "Hex: " + obj.color.hex + ",</br>Alpha: " + obj.color.a + "</td>");
        } else {
          if (obj.enabled == 0) {
            objVisible = "<td class='error'>🙈 ";
          }

          objBorderArray.push(objVisible + obj.color.color.name + ",</br>Hex: " + obj.color.hex + ",</br>Alpha: " + obj.color.a + "</td>");
        }
      });

      if (objBorder.length > 1) {
        objBorderColor += "<td class='no-padding'><table><tr>";
        objBorderColor += objBorderArray.join("</tr><tr>");
        objBorderColor += "</tr></table></td>";
      } else if (objBorder.length == 1) {
        objBorderColor += objBorderArray.join();
      } else {
        objBorderColor = "<td>No Border</td>";
      }

      var objBorderThickness = "";
      objBorderArray = new Array();
      objBorder.forEach(function (obj) {
        if (obj.thickness == 1) {
          objBorderArray.push("<td >" + obj.thickness + " dp</td>");
        } else if (obj.thickness > 1 && objLastName.match("Accessibility")) {
          objBorderArray.push("<td>" + obj.thickness + " dp</td>");
        } else if (obj.thickness != 1 && !objLastName.match("Accessibility")) {
          objBorderArray.push("<td class='error'>" + obj.thickness + " dp</td>");
        }
      });

      if (objBorder.length > 1) {
        objBorderThickness += "<td class='no-padding'><table><tr>";
        objBorderThickness += objBorderArray.join("</tr><tr>");
        objBorderThickness += "</tr></table></td>";
      } else if (objBorder.length == 1) {
        objBorderThickness += objBorderArray.join();
      } else {
        objBorderThickness = "<td></<td>";
      }

      var objsharedStyleId = object.sharedStyleId;

      if (objsharedStyleId == null || objsharedStyleId == undefined) {
        objsharedStyleId = "<td class='warning'>none</td>";
      } else {
        var tempsharedStyle = document.getSharedLayerStyleWithID(objsharedStyleId);

        if (!tempsharedStyle) {
          objsharedStyleId = "<td class='error'>broken</td>";
        } else {
          objsharedStyleId = "<td class='smallText'>" + document.getSharedLayerStyleWithID(objsharedStyleId).name + "</td>";
        }
      }

      exportToFile += "<tr>";
      exportToFile += objName;
      exportToFile += objGeometry;
      exportToFile += objCornerRadius;
      exportToFile += objFillColor;
      exportToFile += objBorderColor;
      exportToFile += objBorderThickness;
      exportToFile += objsharedStyleId;
      exportToFile += "</tr>";
    }

    if (object.layers && object.layers.length) {
      object.layers.forEach(getAllLayer);
    }
  }

  var exportToFile = htmlheader + docHeader + tableHeader;
  document.pages.forEach(getAllLayer);
  exportToFile += htmlFooter;
  _global_functions_js__WEBPACK_IMPORTED_MODULE_0__["saveToFile"]({
    filenamePrefix: docName + " Layer.html",
    content: NSString.stringWithString(exportToFile)
  });
};
var exportLayerStyles = function exportLayerStyles(context) {
  var layerStyles = document.sharedLayerStyles;
  var textStyles = document.sharedTextStyles;
  var docName = _global_functions_js__WEBPACK_IMPORTED_MODULE_0__["documentName"](context);
  var docHeader = "<h1>Document Textstyles</h1><p class='subline'>" + docName + "</p>";
  var tableHeader = "<table>\n                        <thead>\n                          <tr>\n                            <th width=\"200px\">Element</th>\n                            <th width=\"100px\">Used</th>\n                            <th width=\"120px\">Family</th>\n                            <th width=\"100px\">Weight</th>\n                            <th>Size</th><th>Line</th>\n                            <th width=\"150px\">Color</th>\n                            <th>Color Variable</th>\n                            <th>Opacity</th>\n                          </tr>\n                        </thead> \n                        <tbody>";

  function getAllTextStyles() {
    textStyles.forEach(function (object) {
      var objName = object.name;
      var objfamily = object.style.fontFamily;
      var objFontVariant = object.style.sketchObject.textStyle().fontPostscriptName().split("-")[1];
      var objLineheigt = object.style.lineHeight;
      var objFontSize = object.style.fontSize;
      var objFontColor = object.style.textColor;
      var objAlpha = Math.round(100 * object.style.opacity);
      var objUsed = "<td class='warning'>No</td>";
      var objLastName = objName.split("/");
      objLastName = objLastName[objLastName.length - 1];
      objName = "<span class='block'>" + objLastName + "</span><span class='block smallText'>" + objName + "</span>";

      if (objfamily == "DB Screen Sans" || objfamily == "DB Screen Head") {
        objfamily = "<td>" + objfamily + "</td>";
      } else {
        objfamily = "<td class='error'>" + objfamily + "</td>";
      }

      var regexp = /DB Foundation/i;
      var matchesStandardStyle = objName.match(regexp);

      if (!matchesStandardStyle) {
        var textAdapter = object.getAllInstancesLayers()[0];

        if (textAdapter) {
          objUsed = "<td>Yes</td>";
        }
      } else {
        objUsed = "<td>DB Foundation</td>";
      }

      var colorVariable = "<td class='warning'>Not assigned</td>";
      var attributes = object.sketchObject.style().primitiveTextStyle().attributes();
      var swatchID = attributes.MSAttributedStringColorAttribute.swatchID();

      if (swatchID) {
        var referenceSwatch = documentSwatches.find(function (x) {
          return x.id == swatchID;
        });

        if (!referenceSwatch) {
          colorVariable = "<td class='error'>Broken</td>";
        } else {
          colorVariable = "<td class='smallText'>" + referenceSwatch.name + "</td>";
        }
      }

      if (objLineheigt == null) {
        objLineheigt = Math.abs(objFontSize) * 1.25;
      }

      exportToFile += "<tr>";
      exportToFile += "<td>" + objName + "</td>";
      exportToFile += objUsed;
      exportToFile += objfamily;
      exportToFile += "<td>" + objFontVariant + "</td>";
      exportToFile += "<td>" + objFontSize + " dp</td>";
      exportToFile += "<td>" + objLineheigt + " dp</td>";
      exportToFile += _global_functions_js__WEBPACK_IMPORTED_MODULE_0__["niceColorHexAlpha"](objFontColor);
      exportToFile += colorVariable;
      exportToFile += "<td>" + objAlpha + "</td>";
      exportToFile += "<tr>";
    });
  }

  var exportToFile = htmlheader + docHeader + tableHeader;
  getAllTextStyles();
  exportToFile += htmlFooter;
  _global_functions_js__WEBPACK_IMPORTED_MODULE_0__["saveToFile"]({
    filenamePrefix: docName + " TextStyle.html",
    content: NSString.stringWithString(exportToFile)
  });
};
var exportTextLayer = function exportTextLayer(context) {
  var docName = _global_functions_js__WEBPACK_IMPORTED_MODULE_0__["documentName"](context);
  var wrapperDivStart = "<div class='table-wrapper'>";
  var docHeader = "<h1>Document Textlayer Styles</h1><p class='subline'>" + docName + "</p>";
  var tableHeader = "<table>\n                      <thead>\n                        <tr>\n                          <th width=\"300px\">Element</th>\n                          <th width=\"120px\">Family</th>\n                          <th width=\"60px\">Weight</th>\n                          <th width=\"60px\">Size</th><th>Line</th>\n                          <th width=\"150px\">Color</th>\n                          <th>Shared Style</th>\n                        </tr>\n                      </thead>\n                      <tbody>";

  function doSomething(object) {
    if (object.type == "Text") {
      var objfamily = object.style.fontFamily;
      var objFontVariant = object.sketchObject.font().fontName().split("-")[1];
      var objLineheigt = object.style.lineHeight;
      var objFontSize = object.style.fontSize;
      var objName = object.name;
      var objLastName = objName.split("/");
      objLastName = objLastName[objLastName.length - 1];
      var objArtboard = object.getParentArtboard();
      var objArtboardName = "No Artboard";

      if (objArtboard) {
        objArtboardName = objArtboard.name;
      }

      var link = createLink(LAYERSHOWFUNCTION, object.id);
      objName = "<td><span class='block'>" + createNiceHTMLLink(objLastName, link) + "</span><span class='block smallText'>" + objArtboardName + "</span></td>";
      var objFontColor = _global_functions_js__WEBPACK_IMPORTED_MODULE_0__["niceColorHexAlpha"](object.style.textColor);

      if (objfamily == "DB Screen Sans" || objfamily == "DB Screen Head") {
        objfamily = "<td>" + objfamily + "</td>";
      } else {
        objfamily = "<td class='error'>" + objfamily + "</td>";
      }

      var objsharedStyleId = object.sharedStyleId;

      if (objsharedStyleId == null || objsharedStyleId == undefined) {
        objsharedStyleId = "<td class='warning'>none</td>";
      } else {
        var tempsharedStyle = document.getSharedTextStyleWithID(objsharedStyleId);

        if (!tempsharedStyle) {
          objsharedStyleId = "<td class='error'>broken</td>";
        } else {
          objsharedStyleId = "<td class='smallText'>" + document.getSharedTextStyleWithID(objsharedStyleId).name + "</td>";
        }
      }

      if (objLineheigt == null) {
        objLineheigt = Math.abs(objFontSize) * 1.25;
      }

      exportToFile += "<tr>";
      exportToFile += objName;
      exportToFile += objfamily;
      exportToFile += "<td>" + objFontVariant + "</td>";
      exportToFile += "<td>" + objFontSize + " dp</td>";
      exportToFile += "<td>" + objLineheigt + " dp</td>";
      exportToFile += objFontColor;
      exportToFile += objsharedStyleId;
      exportToFile += "</tr>";
    }

    if (object.layers && object.layers.length) {
      // iterate through the children
      object.layers.forEach(doSomething);
    }
  }

  var exportToFile = htmlheader + docHeader + tableHeader;
  document.pages.forEach(doSomething);
  exportToFile += htmlFooter;
  _global_functions_js__WEBPACK_IMPORTED_MODULE_0__["saveToFile"]({
    filenamePrefix: docName + " Textlayer Style.html",
    content: NSString.stringWithString(exportToFile)
  });
};

/***/ }),

/***/ "./src/global-functions.js":
/*!*********************************!*\
  !*** ./src/global-functions.js ***!
  \*********************************/
/*! exports provided: colorCheckBrandConformity, hexAtoRgba, niceColorHexAlphaA, niceColorHexAlpha, getPluginFolderPath, documentName, saveToFile */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "colorCheckBrandConformity", function() { return colorCheckBrandConformity; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "hexAtoRgba", function() { return hexAtoRgba; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "niceColorHexAlphaA", function() { return niceColorHexAlphaA; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "niceColorHexAlpha", function() { return niceColorHexAlpha; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPluginFolderPath", function() { return getPluginFolderPath; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "documentName", function() { return documentName; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "saveToFile", function() { return saveToFile; });
/* harmony import */ var _brandColors_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./brandColors.js */ "./src/brandColors.js");

var foundationColors = _brandColors_js__WEBPACK_IMPORTED_MODULE_0__["colors"];

var sketch = __webpack_require__(/*! sketch/dom */ "sketch/dom");

var document = sketch.getSelectedDocument();
var FILETYPE = 'html';
function colorCheckBrandConformity(colorInput) {
  var result = foundationColors.find(function (color) {
    return color.color === colorInput.toLowerCase();
  });
  return result ? result : null;
}
function hexAtoRgba(colorInput) {
  var result = colorInput.match(/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})/i);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16),
    a: Math.round(1 / 255 * parseInt(result[4], 16) * 100) / 100,
    hex: '#' + result[1] + result[2] + result[3],
    color: colorCheckBrandConformity('#' + result[1] + result[2] + result[3])
  } : null;
}
function niceColorHexAlphaA(color) {
  return "Juri";
}
function niceColorHexAlpha(color) {
  var objFontColor = "";
  var obFontColorObj = hexAtoRgba(color);

  if (obFontColorObj.color) {
    objFontColor = "<td>" + obFontColorObj.color.name + ",</br>Hex: " + obFontColorObj.hex + ",</br>Alpha: " + obFontColorObj.a + "</td>";
  } else {
    objFontColor = "<td class='error'>Hex: " + obFontColorObj.hex + ",</br>Alpha:" + obFontColorObj.a + "</td>";
  }

  return objFontColor;
}
function getPluginFolderPath(context) {
  // Get absolute folder path of plugin
  var split = context.scriptPath.split('/');
  split.splice(-3, 3);
  return split.join('/');
}
function documentName(context) {
  if (context.document.fileURL() == null) {
    return "unsaved_Doument";
  } else {
    return context.document.fileURL().path().replace(/\.sketch$/, '');
  }
}
function saveToFile(_ref) {
  var filenamePrefix = _ref.filenamePrefix,
      string = _ref.content,
      fileType = _ref.fileType;
  // Configuring save panel
  var savePanel = NSSavePanel.savePanel();
  savePanel.allowedFileTypes = [FILETYPE];
  savePanel.nameFieldStringValue = "".concat(filenamePrefix); // Launching alert

  var result = savePanel.runModal();

  if (result == NSFileHandlingPanelOKButton) {
    var path = savePanel.URL().path();
    var success = string.writeToFile_atomically_encoding_error(path, true, NSUTF8StringEncoding, null);
    var alert;

    if (success) {
      /* alert = createAlert({
         text: 'The ' + FILETYPE.toUpperCase() + '-file is successfully saved to:\n `' + path + '`',
         buttons: ['OK'],
       });*/
      //alert("Shared Color Palette JSON Exported!", "Styls Exprtet");
    } else {
      /* alert = createAlert({
         text: `The file could not be saved.`,
         buttons: ['OK'],
       });*/
    } //alert("Shared Color Palette JSON Exported!", "Styls Not Exprtet");
    //alert.runModal();

  }
}

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),

/***/ "sketch/ui":
/*!****************************!*\
  !*** external "sketch/ui" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/ui");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['exportTextLayer'] = __skpm_run.bind(this, 'exportTextLayer');
globalThis['onRun'] = __skpm_run.bind(this, 'default');
globalThis['exportSketchLayer'] = __skpm_run.bind(this, 'exportSketchLayer');
globalThis['exportLayerStyles'] = __skpm_run.bind(this, 'exportLayerStyles');
globalThis['checkSwatches'] = __skpm_run.bind(this, 'checkSwatches');
globalThis['checkSymbolPatern'] = __skpm_run.bind(this, 'checkSymbolPatern')

//# sourceMappingURL=exportStyles.js.map